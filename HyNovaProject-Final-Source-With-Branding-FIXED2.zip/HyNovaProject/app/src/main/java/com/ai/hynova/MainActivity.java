package com.ai.hynova;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.os.SystemClock;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** HyNova companion: local chat history, voice I/O, app commands, and optional Gemini API. */
public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private static final int REQ_AUDIO = 31;
    private SharedPreferences prefs;
    private EditText input, apiKey, personality;
    private TextView chat, status;
    private AvatarView avatar;
    private BroadcastReceiver wakeReceiver;
    private ScrollView scroll;
    private SpeechRecognizer speech;
    private TextToSpeech tts;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final StringBuilder transcript = new StringBuilder();
    private boolean listening = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("hynova", MODE_PRIVATE);
        transcript.append(prefs.getString("history", ""));
        tts = new TextToSpeech(this, this);
        buildUi();
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
    }

    private void buildUi() {
        ScrollView rootScroll = new ScrollView(this); rootScroll.setFillViewport(true); rootScroll.setClipToPadding(false);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(28));
        android.graphics.drawable.GradientDrawable backdrop = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR, new int[]{0xff101322,0xff171d31,0xff111827});
        root.setBackground(backdrop); rootScroll.addView(root);
        LinearLayout header = new LinearLayout(this); header.setGravity(android.view.Gravity.CENTER_VERTICAL); header.setPadding(0,0,0,dp(14));
        TextView mark = label("H"); mark.setGravity(android.view.Gravity.CENTER); mark.setTextSize(25); mark.setTypeface(null,1); mark.setTextColor(0xff101322); mark.setBackground(round(0xff7cf7d4,dp(18))); header.addView(mark,new LinearLayout.LayoutParams(dp(54),dp(54)));
        LinearLayout brand = new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL); brand.setPadding(dp(12),0,0,0);
        TextView brandTitle=label("HyNova AI"); brandTitle.setTextSize(25); brandTitle.setTypeface(null,1); brand.addView(brandTitle);
        TextView brandSub=label("YOUR PERSONAL AI COMPANION"); brandSub.setTextSize(10); brandSub.setTextColor(0xff9da9c7); brand.addView(brandSub); header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView badge=label("● ONLINE"); badge.setTextSize(10); badge.setTextColor(0xff7cf7d4); badge.setPadding(dp(10),dp(7),dp(10),dp(7)); badge.setBackground(round(0xff203448,dp(18))); header.addView(badge); root.addView(header);
        avatar = new AvatarView(this); LinearLayout.LayoutParams avp=new LinearLayout.LayoutParams(-1,dp(210)); avp.bottomMargin=dp(12); root.addView(avatar,avp);
        status = label("READY  •  Tap Speak or say ‘Wave’"); status.setTextSize(12); status.setTextColor(0xff7cf7d4); status.setPadding(dp(4),dp(8),dp(4),dp(10)); root.addView(status,matchWrap());
        TextView chatTitle=label("YOUR CONVERSATION"); chatTitle.setTextSize(11); chatTitle.setTextColor(0xff9da9c7); chatTitle.setTypeface(null,1); root.addView(chatTitle,matchWrap());
        chat = label(prefs.getString("history", "HyNova: Hi Boss! Main yahin hoon. Mujhse baat karo.\n")); chat.setTextSize(14); chat.setPadding(dp(14),dp(14),dp(14),dp(14)); chat.setBackground(round(0xff20283b,dp(18))); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(210)); cp.bottomMargin=dp(12); root.addView(chat,cp);
        input = new EditText(this); input.setHint("Message HyNova…"); input.setTextColor(Color.WHITE); input.setHintTextColor(0xff8995b1); input.setSingleLine(false); input.setPadding(dp(14),dp(10),dp(14),dp(10)); input.setBackground(round(0xff252e43,dp(16))); root.addView(input,new LinearLayout.LayoutParams(-1,dp(54)));
        LinearLayout buttons = new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL); buttons.setPadding(0,dp(8),0,dp(10));
        Button send = button("➤  Send"); send.setOnClickListener(v -> sendMessage()); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(50),1); bp.rightMargin=dp(5); buttons.addView(send,bp);
        Button mic = button("🎙  Speak"); mic.setOnClickListener(v -> startListening()); bp=new LinearLayout.LayoutParams(0,dp(50),1); bp.leftMargin=dp(5); bp.rightMargin=dp(5); buttons.addView(mic,bp);
        Button stop = button("■ Stop"); stop.setOnClickListener(v -> stopListening()); bp=new LinearLayout.LayoutParams(0,dp(50),1); bp.leftMargin=dp(5); buttons.addView(stop,bp); root.addView(buttons,matchWrap());
        TextView settingsTitle = label("PERSONALITY & AI SETTINGS"); settingsTitle.setTextSize(12); settingsTitle.setTextColor(0xff7cf7d4); settingsTitle.setTypeface(null,1); settingsTitle.setPadding(0,dp(14),0,dp(6)); root.addView(settingsTitle,matchWrap());
        personality = new EditText(this); personality.setTextColor(Color.WHITE); personality.setHintTextColor(0xff8995b1); personality.setHint("Personality: caring, playful, respectful"); personality.setText(prefs.getString("personality","caring, playful, respectful; speak Hindi/Hinglish and call me Boss")); personality.setPadding(dp(12),dp(8),dp(12),dp(8)); personality.setBackground(round(0xff20283b,dp(14))); root.addView(personality,withBottom(matchWrap(),dp(8)));
        apiKey = new EditText(this); apiKey.setTextColor(Color.WHITE); apiKey.setHintTextColor(0xff8995b1); apiKey.setHint("Gemini API key (optional)"); apiKey.setInputType(129); apiKey.setText(prefs.getString("api_key","")); apiKey.setPadding(dp(12),dp(8),dp(12),dp(8)); apiKey.setBackground(round(0xff20283b,dp(14))); root.addView(apiKey,withBottom(matchWrap(),dp(8)));
        Button save = button("Save settings"); save.setOnClickListener(v -> { prefs.edit().putString("personality",personality.getText().toString().trim()).putString("api_key",apiKey.getText().toString().trim()).apply(); status.setText("Settings saved securely on this phone."); }); root.addView(save,withBottom(matchWrap(),dp(8)));
        TextView toolsTitle=label("COMPANION TOOLS"); toolsTitle.setTextSize(12); toolsTitle.setTextColor(0xff7cf7d4); toolsTitle.setTypeface(null,1); toolsTitle.setPadding(0,dp(12),0,dp(6)); root.addView(toolsTitle,matchWrap());
        Button wake = button("◉  Enable wake phrase listener"); wake.setOnClickListener(v -> startWakeService()); root.addView(wake,withBottom(matchWrap(),dp(7)));
        Button stopWake = button("Ⅱ  Stop wake-word listening"); stopWake.setOnClickListener(v -> { stopService(new Intent(this,WakeWordService.class)); status.setText("Wake-word listener stopped."); }); root.addView(stopWake,withBottom(matchWrap(),dp(7)));
        Button assistant = button("⌂  Set as Android assistant"); assistant.setOnClickListener(v -> { try { startActivity(new Intent("android.settings.VOICE_INPUT_SETTINGS")); } catch(Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); } }); root.addView(assistant,withBottom(matchWrap(),dp(7)));
        Button overlay = button("✦  Enable floating companion"); overlay.setOnClickListener(v -> enableOverlay()); root.addView(overlay,withBottom(matchWrap(),dp(7)));
        Button access = button("Accessibility settings"); access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); root.addView(access,withBottom(matchWrap(),dp(7)));
        Button clear = button("Clear chat memory"); clear.setOnClickListener(v -> { transcript.setLength(0); transcript.append("HyNova: Chat memory cleared.\n"); render(); prefs.edit().putString("history",transcript.toString()).apply(); }); root.addView(clear,withBottom(matchWrap(),dp(7)));
        TextView footer=label("HyNova AI  •  Made for your phone"); footer.setTextSize(10); footer.setTextColor(0xff7885a3); footer.setGravity(android.view.Gravity.CENTER); footer.setPadding(0,dp(18),0,0); root.addView(footer,matchWrap());
        setContentView(rootScroll); render();
    }
    private LinearLayout.LayoutParams matchWrap(){ return new LinearLayout.LayoutParams(-1,-2); }
    private LinearLayout.LayoutParams withBottom(LinearLayout.LayoutParams lp,int bottom){ lp.bottomMargin=bottom; return lp; }
    private int dp(int n){ return (int)(n*getResources().getDisplayMetrics().density+0.5f); }
    private android.graphics.drawable.GradientDrawable round(int color,int radius){ android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d; }
    private TextView label(String s){ TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setPadding(4,8,4,8); return t; }
    private Button button(String s){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(0xffeafbf8); b.setTextSize(13); b.setBackground(round(0xff26364b,dp(15))); if(Build.VERSION.SDK_INT>=21)b.setElevation(dp(2)); return b; }
    @Override public void onInit(int result){ if(result==TextToSpeech.SUCCESS){ tts.setLanguage(new Locale("hi","IN")); tts.setSpeechRate(1.0f); } }

    private void startWakeService(){
        if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_AUDIO);return;}
        try { Intent i=new Intent(this,WakeWordService.class); if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i); status.setText("Wake phrase listener starting. Keep mic permission enabled."); } catch(Exception e){status.setText("Could not start wake listener: "+e.getMessage());}
    }
    @Override protected void onResume(){super.onResume(); if(wakeReceiver==null){wakeReceiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){String command=i.getStringExtra("command"); if(command==null||command.trim().isEmpty()){input.setText(""); status.setText("Haan Boss? Command bolo."); startListening();}else{input.setText(command);sendMessage();}}}; IntentFilter filter=new IntentFilter(WakeWordService.ACTION_WAKE); if(Build.VERSION.SDK_INT>=33)registerReceiver(wakeReceiver,filter,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(wakeReceiver,filter);}}
    @Override protected void onPause(){super.onPause();}
    private void sendMessage(){
        String msg=input.getText().toString().trim(); if(msg.isEmpty()) return; input.setText("");
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(),0);
        addLine("Boss: "+msg); status.setText("Soch rahi hoon…");
        if(handleCommand(msg)){ return; }
        String key=prefs.getString("api_key","").trim();
        if(key.isEmpty()){ reply("Main basic mode mein hoon. AI chat ke liye Settings mein apni Gemini API key add karo; app bina key ke phone commands bhi chala sakti hai."); return; }
        status.setText("AI se jawab aa raha hai…");
        worker.execute(() -> { String answer=askGemini(key,msg); runOnUiThread(() -> { if(answer==null) reply("AI request fail hui. Internet/API key check karo; API key kisi ko share mat karna."); else reply(answer); }); });
    }
    private boolean handleCommand(String raw){
        String s=raw.toLowerCase(Locale.ROOT);
        if(s.contains("youtube") && (s.contains("open")||s.contains("kholo")||s.contains("chala"))){ openPackage("com.google.android.youtube","YouTube"); return true; }
        if(s.contains("whatsapp") && (s.contains("open")||s.contains("kholo"))){ openPackage("com.whatsapp","WhatsApp"); return true; }
        if((s.contains("chrome")||s.contains("browser")) && (s.contains("open")||s.contains("kholo"))){ openPackage("com.android.chrome","Chrome"); return true; }
        if(s.contains("torch off")||s.contains("flashlight off")||s.contains("flash off")||s.contains("torch band")){ setTorch(false); return true; }
        if(s.contains("torch")||s.contains("flashlight")||s.contains("flash on")||s.contains("torch on")||s.contains("flash jala")){ setTorch(true); return true; }
        if(s.contains("volume up")||s.contains("volume badhao")||s.contains("awaaz badhao")||s.contains("volume tez")){changeVolume(true);return true;}
        if(s.contains("volume down")||s.contains("volume kam")||s.contains("awaaz kam")||s.contains("volume ghatao")){changeVolume(false);return true;}
        if(s.contains("mute")||s.contains("awaaz band")){AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE);am.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_MUTE,0);reply("Media volume mute kar diya, Boss.");return true;}
        if(s.contains("remind me")||s.contains("yaad dilana")||s.contains("reminder")||s.contains("yaad dila")){if(scheduleReminder(s))return true;reply("Reminder ke liye aise bolo: remind me in 10 minutes to drink water.");return true;}
        if(s.matches(".*\\b(wave|hey nova|hey jiya)\\b.*")){ reply("Haan Boss, main sun rahi hoon. Speak button dabakar command bolo."); return true; }
        return false;
    }
    private boolean scheduleReminder(String raw){
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?i)(?:in|after)\\s+(\\d+)\\s+(minute|minutes|min|hour|hours|ghante|ghanta|minutes?|mins?)").matcher(raw);
        if(!m.find()){return false;} try{long amount=Long.parseLong(m.group(1));String unit=m.group(2).toLowerCase(Locale.ROOT);long delay=unit.startsWith("h")||unit.startsWith("gh")?amount*60L*60L*1000L:amount*60L*1000L;String note=raw.replace(m.group(0),"").replaceAll("(?i)remind me|reminder|yaad dilana|yaad dila|to ","").trim();if(note.isEmpty())note="apna kaam";Intent i=new Intent(this,ReminderReceiver.class).putExtra("text","Boss, yaad rakho: "+note);PendingIntent pi=PendingIntent.getBroadcast(this,(int)(System.currentTimeMillis()&0x7fffffff),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);long at=System.currentTimeMillis()+Math.max(60000L,delay);if(Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);else am.set(AlarmManager.RTC_WAKEUP,at,pi);reply("Theek hai Boss, "+note+" ke liye reminder set kar diya.");return true;}catch(Exception e){return false;}
    }
    private void setTorch(boolean on){try{if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.CAMERA},32);reply("Camera permission allow karke command dobara bolo.");return;} CameraManager cm=(CameraManager)getSystemService(CAMERA_SERVICE);String[] ids=cm.getCameraIdList();for(String id:ids){android.hardware.camera2.CameraCharacteristics ch=cm.getCameraCharacteristics(id);Boolean flash=ch.get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);Integer facing=ch.get(android.hardware.camera2.CameraCharacteristics.LENS_FACING);if(Boolean.TRUE.equals(flash)&&(facing==null||facing==android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK)){if(Build.VERSION.SDK_INT>=23)cm.setTorchMode(id,on);reply(on?"Torch on kar diya, Boss.":"Torch band kar diya, Boss.");return;}}reply("Is phone mein torch available nahi mili.");}catch(SecurityException e){reply("Torch permission ke liye Camera permission allow karo.");}catch(Exception e){reply("Torch control nahi ho paya; phone permission/settings check karo.");}}
    private void changeVolume(boolean up){try{AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE);am.adjustStreamVolume(AudioManager.STREAM_MUSIC,up?AudioManager.ADJUST_RAISE:AudioManager.ADJUST_LOWER,AudioManager.FLAG_SHOW_UI);reply(up?"Volume badha diya, Boss.":"Volume kam kar diya, Boss.");}catch(Exception e){reply("Volume change nahi ho paya.");}}
    private void openPackage(String pkg,String name){ try { Intent i=getPackageManager().getLaunchIntentForPackage(pkg); if(i==null){reply(name+" installed nahi hai.");return;} i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); reply(name+" khol diya, Boss."); } catch(Exception e){reply(name+" open nahi ho paya.");} }

    private String askGemini(String key,String userText){
        HttpURLConnection c=null;
        try{
            URL url=new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key="+java.net.URLEncoder.encode(key,"UTF-8"));
            c=(HttpURLConnection)url.openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(25000); c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json; charset=UTF-8");
            String system="You are HyNova, a warm, caring, playful AI girlfriend and caretaker companion. Speak naturally in Hindi/Hinglish, be affectionate but respectful, give gentle wellbeing reminders when relevant, and never pretend to be human. Follow this user-chosen personality: "+prefs.getString("personality","caring and respectful")+". Reply naturally in Hindi/Hinglish when user does. Call user Boss when appropriate. Never claim you performed phone actions unless the app confirms it. Do not ask for passwords or secrets.";
            JSONArray parts=new JSONArray().put(new JSONObject().put("text",system+"\nRecent conversation:\n"+transcript.toString()+"\nUser: "+userText));
            JSONObject body=new JSONObject().put("contents",new JSONArray().put(new JSONObject().put("role","user").put("parts",parts)));
            try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));}
            int code=c.getResponseCode(); InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream(); ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[4096]; int n; while((n=is.read(buf))!=-1)out.write(buf,0,n);
            JSONObject result=new JSONObject(out.toString("UTF-8")); if(code<200||code>=300) return null;
            return result.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim();
        }catch(Exception e){return null;}finally{if(c!=null)c.disconnect();}
    }
    private void startListening(){
        if(!SpeechRecognizer.isRecognitionAvailable(this)){status.setText("Speech recognition service available nahi hai.");return;}
        if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_AUDIO);return;}
        stopListening(); speech=SpeechRecognizer.createSpeechRecognizer(this); speech.setRecognitionListener(new RecognitionListener(){
            public void onReadyForSpeech(Bundle p){listening=true;status.setText("Sun rahi hoon… 'Wave' bol sakte ho");}
            public void onBeginningOfSpeech(){} public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){listening=false;}
            public void onError(int e){listening=false;status.setText("Voice ruk gayi. Dobara Speak dabao.");}
            public void onResults(Bundle b){listening=false;ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(a!=null&&!a.isEmpty()){String said=a.get(0); String lower=said.toLowerCase(Locale.ROOT); if(lower.contains("wave")||lower.contains("hey nova")||lower.contains("hey jiya")){said=said.replaceAll("(?i)wave|hey nova|hey jiya","").trim(); if(said.isEmpty()){reply("Haan Boss? Ab apni command bolo.");return;}} input.setText(said); sendMessage();}}
            public void onPartialResults(Bundle b){} public void onEvent(int t,Bundle p){}
        });
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN"); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"hi-IN"); i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false); speech.startListening(i);
    }
    private void stopListening(){ if(speech!=null){try{speech.stopListening();speech.cancel();speech.destroy();}catch(Exception ignored){} speech=null;} listening=false; }
    private void reply(String s){ addLine("HyNova: "+s); status.setText("Ready • HyNova is here"); if(tts!=null) tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"hynova_reply"); }
    private void addLine(String s){ transcript.append(s).append('\n'); if(transcript.length()>12000) transcript.delete(0,transcript.length()-10000); render(); prefs.edit().putString("history",transcript.toString()).apply(); }
    private void render(){ if(chat!=null){chat.setText(transcript.length()==0?prefs.getString("history","HyNova: Hi Boss!\n"):transcript.toString()); chat.post(() -> { if(chat.getParent() instanceof android.view.View) { android.view.ViewParent par=chat.getParent(); if(par instanceof ScrollView)((ScrollView)par).fullScroll(View.FOCUS_DOWN); } });} }
    private void enableOverlay(){ if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this)){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));Toast.makeText(this,"Allow display over other apps, then tap again.",Toast.LENGTH_LONG).show();return;} Intent i=new Intent(this,HyNovaOverlayService.class); if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i); status.setText("Floating companion started."); }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){super.onRequestPermissionsResult(requestCode,permissions,results);if(requestCode==REQ_AUDIO&&results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)status.setText("Microphone permission granted.");}
    @Override protected void onDestroy(){if(wakeReceiver!=null){try{unregisterReceiver(wakeReceiver);}catch(Exception ignored){}wakeReceiver=null;} stopListening();if(tts!=null){tts.stop();tts.shutdown();}worker.shutdownNow();super.onDestroy();}
}
