package com.ai.hynova;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** Lightweight animated 2D companion avatar drawn locally; no external assets required. */
public class AvatarView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float phase = 0f, mouth = 0f;
    public AvatarView(Context c) {
        super(c);
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f); a.setDuration(1800); a.setRepeatCount(ValueAnimator.INFINITE); a.setInterpolator(new LinearInterpolator());
        a.addUpdateListener(v -> { phase=(float)v.getAnimatedValue(); mouth=(phase>.42f && phase<.68f)?1f:0f; invalidate(); }); a.start();
        setMinimumHeight((int)(190*getResources().getDisplayMetrics().density));
    }
    @Override protected void onDraw(Canvas c) {
        super.onDraw(c); float w=getWidth(), h=getHeight(), cx=w/2f, cy=h*.48f, r=Math.min(w*.30f,h*.36f);
        p.setColor(0xff171c2a); c.drawRoundRect(new RectF(0,0,w,h),28,28,p);
        p.setColor(0xff8d79ff); c.drawCircle(cx,cy,r*1.10f,p);
        p.setColor(0xffffdfcf); c.drawOval(new RectF(cx-r*.77f,cy-r*.83f,cx+r*.77f,cy+r*.91f),p);
        p.setColor(0xff3b2d54); c.drawArc(new RectF(cx-r*.82f,cy-r*1.03f,cx+r*.82f,cy+r*.25f),180,180,false,p); c.drawRoundRect(new RectF(cx-r*.82f,cy-r*.62f,cx-r*.53f,cy+r*.05f),r*.15f,r*.15f,p); c.drawRoundRect(new RectF(cx+r*.53f,cy-r*.62f,cx+r*.82f,cy+r*.05f),r*.15f,r*.15f,p);
        p.setColor(0xff34263d); float eyeY=cy-r*.12f; if(phase>.94f){p.setStrokeWidth(3); c.drawLine(cx-r*.42f,eyeY,cx-r*.17f,eyeY,p);c.drawLine(cx+r*.17f,eyeY,cx+r*.42f,eyeY,p);}else{c.drawCircle(cx-r*.29f,eyeY,r*.075f,p);c.drawCircle(cx+r*.29f,eyeY,r*.075f,p);}
        p.setColor(0xffff9da9); c.drawCircle(cx-r*.48f,cy+r*.18f,r*.11f,p); c.drawCircle(cx+r*.48f,cy+r*.18f,r*.11f,p);
        p.setColor(0xffa83f64); if(mouth>0)c.drawOval(new RectF(cx-r*.14f,cy+r*.39f,cx+r*.14f,cy+r*.59f),p); else c.drawArc(new RectF(cx-r*.22f,cy+r*.30f,cx+r*.22f,cy+r*.60f),15,150,false,p);
        p.setColor(0xff7fffd4); p.setTextSize(Math.max(14,r*.18f)); p.setTextAlign(Paint.Align.CENTER); c.drawText("HYNOVA • YOUR COMPANION",cx,h-14,p);
    }
}
