package com.ai.hynova;
import android.service.voice.VoiceInteractionSessionService; import android.service.voice.VoiceInteractionSession; import android.os.Bundle;
public class HyNovaVoiceInteractionSessionService extends VoiceInteractionSessionService {
 @Override public VoiceInteractionSession onNewSession(Bundle args){return new HyNovaVoiceInteractionSession(this);}
}
