HyNova AI Branding Assets

HyNova-App-Logo.png       Source logo, 1024 x 1024
HyNova-App-Thumbnail.png  Source app thumbnail, 1280 x 720

Integration: the logo is resized into app/src/main/res/mipmap-* as ic_launcher.png and ic_launcher_round.png. The thumbnail is copied to app/src/main/res/drawable-nodpi/hynova_thumbnail.png and displayed by activity_main.xml.
