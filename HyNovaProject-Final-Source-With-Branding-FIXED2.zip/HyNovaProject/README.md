# HyNova AI — Android companion project

Java 17 Android app for an opt-in AI companion with Gemini chat, Hindi/Hinglish speech input and TTS, a locally drawn animated 2D avatar, local chat history/personality settings, floating overlay, app launching, volume controls, flashlight controls, an experimental foreground wake-phrase listener, and an Android VoiceInteractionService declaration.

## GitHub Actions build (phone-friendly)
1. Extract this ZIP. Upload the **contents** of `HyNovaProject/` into the repository root, keeping `.github/workflows/android-build.yml` at that exact path. Do not upload only the ZIP file.
2. Open GitHub repository → Actions → Android Debug Build → Run workflow.
3. After success, download artifact `HyNovaProject-debug-apk` and extract `app-debug.apk`.

## Setup
- Open app, add a Gemini API key under Settings, then save. The key is stored in app-private preferences on this phone; do not commit it or share it. Internet/API access is required for generative chat and may incur provider charges.
- Allow microphone permission for voice input/wake listener. Use the button to explicitly start the foreground wake listener; stop it when not needed.
- Allow “display over other apps” to use the floating companion.
- Enable HyNova in Android Accessibility settings only if you need the declared integration. It does not read screen text, tap arbitrary UI, unlock the phone, or bypass security.
- To try the system assistant integration, use the in-app button to open voice input settings and select HyNova if Android exposes it on the device. OEM/Android versions may not list third-party assistant services.

## Voice commands currently implemented
- “Open YouTube”, “WhatsApp kholo”, “Chrome kholo”
- “Torch on/torch off”, “flashlight on/off”
- “Volume up/awaaz badhao”, “volume down/awaaz kam”, “mute”
- “Remind me in 10 minutes to drink water” (notification reminder)
- Wake phrases: “Hey Jiya”, “Hey Nova”, “Wave” (experimental; command can follow the phrase)

## Important implementation details
- The avatar is an animated custom-drawn 2D character. It is not a Live2D/VRM model; no proprietary model assets or weights are bundled.
- The wake-word listener uses Android's standard speech recognition service in a foreground service and repeatedly restarts recognition. Android/OEM microphone restrictions, battery optimisation, network availability and speech-recognition implementation can interrupt it; this is not a dedicated offline hotword engine.
- Gemini is the only generative AI backend currently wired in. There is no bundled offline LLM or model weights.
- Chat history and personality are stored locally. API key storage uses app-private preferences, not a dedicated encrypted vault.
- The default-assistant integration is experimental and must be explicitly selected by the user; support varies by Android/OEM.
- This is source code, not a prebuilt APK. A successful GitHub Actions run is required to verify the build.

## Visual design and branding
- Updated dark navy/teal companion UI with branded header, online state, conversation panel, message composer, voice controls, settings, and companion tools.
- Android launcher icon and round icon are included for legacy and adaptive-icon Android launchers.
- `branding/HyNova-App-Logo.png` is the transparent logo export.
- `branding/HyNova-App-Thumbnail.png` is a 1280×720 project/app thumbnail for GitHub, social previews, and project presentation.
