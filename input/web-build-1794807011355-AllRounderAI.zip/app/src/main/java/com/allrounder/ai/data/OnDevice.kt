
package com.allrounder.ai.data

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withTimeoutOrNull
import java.lang.reflect.Proxy
import kotlinx.coroutines.withContext
import java.io.File

/** Fully offline inference with a MediaPipe-compatible .task model (Gemma family). */
object OnDeviceLlm {
    /** MediaPipe .task files are zip archives ("PK"); older .bin files are TFLite ("TFL3"). Anything else (e.g. .gguf) can crash the native loader. */
    fun looksValid(path: String): Boolean = try {
        java.io.FileInputStream(path).use { f ->
            val b = ByteArray(8)
            val n = f.read(b)
            n >= 8 && ((b[0] == 'P'.code.toByte() && b[1] == 'K'.code.toByte()) || String(b, 4, 4, Charsets.US_ASCII) == "TFL3")
        }
    } catch (e: Throwable) {
        false
    }

    /** Returns a message when the model is too large for the memory that is free right now, else null. */
    fun memoryProblem(ctx: Context, path: String): String? {
        val am = ctx.getSystemService(android.app.ActivityManager::class.java)
        val mi = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val size = File(path).length()
        return if (size > mi.availMem * 0.85) {
            "This model needs about " + (size / 1048576) + " MB of free memory but only " + (mi.availMem / 1048576) +
                " MB is free. Close other apps or use a smaller model (for example a 1B model)."
        } else null
    }

    private var engine: LlmInference? = null
    private var loadedPath: String? = null

    suspend fun generate(
        ctx: Context, path: String, system: String, history: List<Turn>, onDelta: ((String) -> Unit)? = null
    ): String =
        withContext(Dispatchers.Default) {
            if (path.isBlank() || !File(path).exists()) {
                throw LlmException("On-device model missing - import a .task model in Settings")
            }
            val e = synchronized(this@OnDeviceLlm) {
                if (engine == null || loadedPath != path) {
                    if (!looksValid(path)) throw LlmException("This file is not a MediaPipe .task model (wrong format). .gguf files do not work here.")
                    memoryProblem(ctx, path)?.let { throw LlmException(it) }
                    engine?.close()
                    engine = try {
                        LlmInference.createFromOptions(
                            ctx.applicationContext,
                            LlmInference.LlmInferenceOptions.builder().setModelPath(path).setMaxTokens(2048).build()
                        )
                    } catch (ex: Throwable) {
                        throw LlmException("Could not load on-device model: ${ex.message}")
                    }
                    loadedPath = path
                }
                engine!!
            }
            val turns = history.takeLast(6)
            val prompt = buildString {
                turns.forEachIndexed { i, t ->
                    val text = if (i == 0 && t.role == "user" && system.isNotBlank()) system + "\n\n" + t.content else t.content
                    append(if (t.role == "user") "<start_of_turn>user\n" else "<start_of_turn>model\n")
                    append(text.take(4000)).append("<end_of_turn>\n")
                }
                append("<start_of_turn>model\n")
            }
            val streamed = if (onDelta != null) streamViaReflection(e, prompt, onDelta) else null
            if (streamed != null) return@withContext streamed.trim()
            try {
                e.generateResponse(prompt).trim()
            } catch (ex: Throwable) {
                throw LlmException("On-device error: ${ex.message}")
            }
        }
}

/**
 * Streams tokens when this MediaPipe version has generateResponseAsync(prompt, listener). Looked up by reflection so the
 * app still builds and falls back to the normal (non-streaming) call on versions where it does not exist.
 */
private suspend fun streamViaReflection(e: LlmInference, prompt: String, onDelta: (String) -> Unit): String? {
    val m = e.javaClass.methods.firstOrNull {
        it.name == "generateResponseAsync" && it.parameterTypes.size == 2 && it.parameterTypes[0] == String::class.java
    } ?: return null
    val listenerType = m.parameterTypes[1]
    val sb = StringBuilder()
    val done = CompletableDeferred<Unit>()
    val proxy = Proxy.newProxyInstance(listenerType.classLoader, arrayOf(listenerType)) { _, method, args ->
        when (method.name) {
            "hashCode" -> 0
            "equals" -> false
            "toString" -> "listener"
            else -> {
                if (args != null && args.size >= 2) {
                    sb.append(args[0] as? String ?: "")
                    onDelta(sb.toString())
                    if (args[1] as? Boolean == true) done.complete(Unit)
                }
                null
            }
        }
    }
    return try {
        m.invoke(e, prompt, proxy)
        withTimeoutOrNull(300_000) { done.await() }
        sb.toString().ifBlank { null }
    } catch (ex: Throwable) {
        if (ex is kotlinx.coroutines.CancellationException) throw ex
        sb.toString().ifBlank { null }
    }
}

suspend fun runProvider(
    ctx: Context, spec: ProviderSpec, s: SettingsState, system: String, history: List<Turn>,
    onDelta: ((String) -> Unit)? = null
): String =
    if (spec.type == ProviderType.ONDEVICE) OnDeviceLlm.generate(ctx, s.modelPath, system, history, onDelta)
    else LlmClient.complete(spec, s.keys[spec.id].orEmpty(), s.modelFor(spec), system, history, s.urls[spec.id], s.temperature, onDelta)
