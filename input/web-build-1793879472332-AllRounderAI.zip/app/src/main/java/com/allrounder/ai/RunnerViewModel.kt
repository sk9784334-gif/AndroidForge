
package com.allrounder.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.allrounder.ai.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject

enum class Lang(val label: String, val file: String) {
    PYTHON("Python", "main.py"),
    JS("JavaScript", "main.js"),
    SHELL("Shell", "main.sh"),
    JAVA("Java", "Main.java")
}

/** Runs code in a private repo of the user's own GitHub account (GitHub Actions sandbox), never on the phone. */
class RunnerViewModel(app: Application) : AndroidViewModel(app) {
    private val settings = SettingsRepo.get(app)
    val busy = MutableStateFlow(false)
    val status = MutableStateFlow("")
    val output = MutableStateFlow("")
    val error = MutableStateFlow<String?>(null)
    private var job: Job? = null

    fun run(lang: Lang, code: String) {
        val token = settings.state.value.githubToken
        if (token.isBlank()) { error.value = "Add your GitHub token in Settings first."; return }
        if (busy.value || code.isBlank()) return
        job = viewModelScope.launch {
            busy.value = true; error.value = null; output.value = ""
            try {
                val api = GitHubApi(token)
                val repo = "allrounder-runner"
                status.value = "Connecting to GitHub..."
                val owner = api.login()
                status.value = "Preparing private runner repo..."
                api.createRepo(repo, private = true)
                val yml = getApplication<Application>().assets.open("run.yml").bufferedReader().readText()
                api.putFile(owner, repo, GenFile(".github/workflows/run.yml", yml))
                api.putFile(owner, repo, GenFile(lang.file, code))
                val before = api.latestRun(owner, repo)?.id
                status.value = "Starting run..."
                delay(3000)
                var started = false
                var tries = 0
                while (!started) {
                    try {
                        api.dispatchWorkflow(owner, repo, "run.yml", JSONObject().put("file", lang.file))
                        started = true
                    } catch (e: GitHubException) {
                        if (++tries >= 4) throw e
                        delay(3000)
                    }
                }
                status.value = "Running on GitHub..."
                var found: RunInfo? = null
                repeat(45) {
                    if (found == null) {
                        delay(4000)
                        val r = api.latestRun(owner, repo)
                        if (r != null && r.id != before && r.status == "completed") found = r
                    }
                }
                val run = found ?: throw GitHubException("Timed out waiting for the run. Check GitHub Actions.")
                val raw = api.runLog(owner, repo, run.id)
                val out = raw.substringAfter("AF_2BEGIN", "").substringBefore("AF_2END").trim()
                output.value = when {
                    out.isNotEmpty() -> out.takeLast(8000)
                    raw.contains("AF_2BEGIN") -> "(no output)"
                    else -> raw.takeLast(1500).ifBlank { "(no log available)" }
                }
            } catch (e: GitHubException) {
                error.value = e.message
            } finally {
                busy.value = false; status.value = ""
            }
        }
    }
}
