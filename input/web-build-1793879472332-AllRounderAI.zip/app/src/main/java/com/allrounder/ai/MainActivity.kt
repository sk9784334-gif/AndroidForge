
package com.allrounder.ai

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import com.allrounder.ai.ui.AllRounderTheme
import com.allrounder.ai.ui.BuilderScreen
import com.allrounder.ai.ui.ChatScreen
import com.allrounder.ai.ui.LogoMark
import com.allrounder.ai.ui.RunnerScreen
import com.allrounder.ai.ui.SettingsScreen

const val LOCK_AUTH = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AllRounderTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppRoot()
                }
            }
        }
    }
}

@Composable
private fun AppRoot() {
    val vm: ChatViewModel = viewModel()
    val st by vm.settings.state.collectAsState()
    val ctx = LocalContext.current
    var unlocked by rememberSaveable { mutableStateOf(false) }
    var screen by rememberSaveable { mutableStateOf("chat") }

    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { unlocked = false }
    SideEffect {
        (ctx as? Activity)?.window?.let {
            if (st.appLock) it.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
            else it.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }
    BackHandler(enabled = screen != "chat") { screen = "chat" }

    if (st.appLock && !unlocked) {
        LockScreen(onUnlock = { unlocked = true })
        return
    }
    when (screen) {
        "settings" -> SettingsScreen(vm, onBack = { screen = "chat" })
        "web" -> BuilderScreen(BuildMode.WEB, onBack = { screen = "chat" }, onSettings = { screen = "settings" })
        "run" -> RunnerScreen(onBack = { screen = "chat" }, onSettings = { screen = "settings" })
        "app" -> BuilderScreen(BuildMode.APP, onBack = { screen = "chat" }, onSettings = { screen = "settings" })
        else -> ChatScreen(vm, onOpenSettings = { screen = "settings" }, onNavigate = { screen = it })
    }
}

@Composable
private fun LockScreen(onUnlock: () -> Unit) {
    val ctx = LocalContext.current
    val attempt = {
        val act = ctx as? FragmentActivity
        if (act == null || BiometricManager.from(ctx).canAuthenticate(LOCK_AUTH) != BiometricManager.BIOMETRIC_SUCCESS) {
            onUnlock() // device lock was removed: don't trap the user out
        } else {
            val prompt = BiometricPrompt(act, ContextCompat.getMainExecutor(act),
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = onUnlock()
                })
            prompt.authenticate(
                BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Unlock AllRounder AI")
                    .setAllowedAuthenticators(LOCK_AUTH)
                    .build()
            )
        }
    }
    LaunchedEffect(Unit) { attempt() }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        LogoMark(72.dp)
        Spacer(Modifier.height(16.dp))
        Text("AllRounder AI is locked", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(16.dp))
        Button(onClick = { attempt() }) { Text("Unlock") }
    }
}
