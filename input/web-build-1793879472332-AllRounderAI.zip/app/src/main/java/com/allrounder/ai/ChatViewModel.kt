
package com.allrounder.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.allrounder.ai.data.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    val settings = SettingsRepo.get(app)

    val currentChatId = MutableStateFlow<Long?>(null)
    val loading = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)
    /** Text of the reply while it is still being streamed in. */
    val streaming = MutableStateFlow<String?>(null)

    val chats: StateFlow<List<ChatEntity>> = dao.chats()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val messages: StateFlow<List<MessageEntity>> = currentChatId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.messages(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var job: Job? = null

    fun send(text: String, image: String? = null) {
        val t = text.trim()
        if ((t.isEmpty() && image == null) || loading.value) return
        job = viewModelScope.launch {
            val now = System.currentTimeMillis()
            var id = currentChatId.value
            if (id == null) {
                id = dao.insertChat(ChatEntity(title = t.ifBlank { "Image" }.take(48), updatedAt = now))
                currentChatId.value = id
            }
            dao.insertMessage(
                MessageEntity(chatId = id, role = "user", content = t, provider = null, createdAt = now, image = image)
            )
            dao.touch(id, now)
            generate(id)
        }
    }

    fun retry() {
        val id = currentChatId.value ?: return
        if (loading.value) return
        job = viewModelScope.launch { generate(id) }
    }

    /** Stops generation but keeps whatever was already streamed. */
    fun stop() {
        val partial = streaming.value
        val id = currentChatId.value
        job?.cancel()
        if (!partial.isNullOrBlank() && id != null) {
            viewModelScope.launch {
                dao.insertMessage(
                    MessageEntity(
                        chatId = id, role = "assistant", content = partial,
                        provider = "Stopped", createdAt = System.currentTimeMillis()
                    )
                )
            }
        }
    }

    private suspend fun withWebSearch(s: SettingsState, history: List<Turn>, base: String): String {
        if (!s.webSearch || s.tavilyKey.isBlank()) return base
        val q = history.lastOrNull { it.role == "user" }?.content?.takeIf { it.isNotBlank() } ?: return base
        return try {
            val r = SearchClient.search(s.tavilyKey, q)
            if (r.isBlank()) base
            else base + "\n\nLive web search results for the user's latest message " +
                "(use them when relevant and mention the source URLs):\n" + r
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            base
        }
    }

    private suspend fun generate(chatId: Long) {
        error.value = null
        streaming.value = null
        loading.value = true
        try {
            val s = settings.state.value
            val order = s.providerOrder()
            if (order.isEmpty()) {
                error.value = "Add an API key in Settings to start chatting."
                return
            }
            val history = dao.messagesOnce(chatId).map { Turn(it.role, it.content, it.image) }
            val base = dao.chat(chatId)?.systemPrompt?.takeIf { it.isNotBlank() } ?: s.systemPrompt
            val system = withWebSearch(s, history, base)
            var last = "Request failed"
            for (spec in order) {
                streaming.value = null
                try {
                    val reply = runProvider(getApplication<Application>(), spec, s, system, history) { streaming.value = it }
                    val now = System.currentTimeMillis()
                    dao.insertMessage(
                        MessageEntity(chatId = chatId, role = "assistant", content = reply, provider = spec.name, createdAt = now)
                    )
                    dao.touch(chatId, now)
                    return
                } catch (e: LlmException) {
                    last = e.message ?: last
                    if (!s.fallback) break
                }
            }
            error.value = last
        } finally {
            loading.value = false
            streaming.value = null
        }
    }

    fun renameChat(id: Long, title: String) {
        viewModelScope.launch { dao.rename(id, title.trim().take(60)) }
    }

    fun togglePin(chat: ChatEntity) {
        viewModelScope.launch { dao.setPinned(chat.id, !chat.pinned) }
    }

    fun setChatPrompt(id: Long, prompt: String) {
        viewModelScope.launch { dao.setSystemPrompt(id, prompt.trim().ifBlank { null }) }
    }

    fun newChat() {
        job?.cancel()
        currentChatId.value = null
        error.value = null
    }

    fun openChat(id: Long) {
        job?.cancel()
        currentChatId.value = id
        error.value = null
    }

    fun deleteChat(id: Long) {
        viewModelScope.launch {
            if (currentChatId.value == id) newChat()
            dao.deleteChat(id)
        }
    }

    fun deleteAll() {
        viewModelScope.launch {
            newChat()
            dao.deleteAll()
        }
    }
}
