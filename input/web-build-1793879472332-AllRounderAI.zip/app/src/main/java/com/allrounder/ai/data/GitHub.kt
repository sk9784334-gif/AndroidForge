
package com.allrounder.ai.data

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class GenFile(val path: String, val content: String)
class GitHubException(message: String) : Exception(message)
data class RunInfo(val id: Long, val status: String, val conclusion: String)

/** Only ever talks to api.github.com (hard-coded host) so the token can't leak elsewhere. */
class GitHubApi(private val token: String) {
    private val http = OkHttpClient.Builder().callTimeout(60, TimeUnit.SECONDS).build()
    private val json = "application/json; charset=utf-8".toMediaType()

    private suspend fun call(method: String, path: String, body: JSONObject? = null): Pair<Int, String> =
        withContext(Dispatchers.IO) {
            val rb = Request.Builder().url("https://api.github.com$path")
                .header("Authorization", "Bearer $token")
                .header("Accept", "application/vnd.github+json")
                .header("X-GitHub-Api-Version", "2022-11-28")
            val payload = if (method == "GET") null else (body?.toString() ?: "{}").toRequestBody(json)
            rb.method(method, payload)
            try {
                http.newCall(rb.build()).execute().use { it.code to (it.body?.string().orEmpty()) }
            } catch (e: IOException) {
                throw GitHubException("Network error: ${e.message ?: "check connection"}")
            }
        }

    suspend fun login(): String {
        val (c, b) = call("GET", "/user")
        if (c != 200) throw GitHubException("GitHub token rejected (HTTP $c). Check token and scopes.")
        return JSONObject(b).getString("login")
    }

    suspend fun createRepo(name: String, private: Boolean = false) {
        val (c, b) = call("POST", "/user/repos", JSONObject().put("name", name).put("auto_init", true).put("private", private))
        if (c != 201 && c != 422) throw GitHubException("Could not create repo (HTTP $c): ${b.take(120)}")
    }

    suspend fun putFile(owner: String, repo: String, f: GenFile) {
        val enc = f.path.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
        val (gc, gb) = call("GET", "/repos/$owner/$repo/contents/$enc")
        val body = JSONObject().put("message", "Add ${f.path}")
            .put("content", Base64.encodeToString(f.content.toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
        if (gc == 200) body.put("sha", JSONObject(gb).optString("sha"))
        val (c, b) = call("PUT", "/repos/$owner/$repo/contents/$enc", body)
        if (c != 200 && c != 201) throw GitHubException("Upload failed for ${f.path} (HTTP $c): ${b.take(120)}")
    }

    suspend fun enablePages(owner: String, repo: String) {
        call("POST", "/repos/$owner/$repo/pages",
            JSONObject().put("source", JSONObject().put("branch", "main").put("path", "/")))
    }

    suspend fun latestRun(owner: String, repo: String): RunInfo? {
        val (c, b) = call("GET", "/repos/$owner/$repo/actions/runs?per_page=1")
        if (c != 200) throw GitHubException("Could not read build status (HTTP $c)")
        val arr = JSONObject(b).getJSONArray("workflow_runs")
        if (arr.length() == 0) return null
        val r = arr.getJSONObject(0)
        return RunInfo(r.getLong("id"), r.optString("status"), r.optString("conclusion"))
    }

    suspend fun failedLog(owner: String, repo: String, runId: Long): String {
        val (c, b) = call("GET", "/repos/$owner/$repo/actions/runs/$runId/jobs")
        if (c != 200) return ""
        val jobs = JSONObject(b).getJSONArray("jobs")
        for (i in 0 until jobs.length()) {
            val j = jobs.getJSONObject(i)
            if (j.optString("conclusion") == "failure") {
                val (lc, lb) = call("GET", "/repos/$owner/$repo/actions/jobs/${j.getLong("id")}/logs")
                if (lc != 200) return ""
                val lines = lb.lines()
                val hits = lines.filter {
                    it.contains("e: ") || it.contains("error:", true) || it.contains("What went wrong") || it.contains("FAILURE")
                }
                return (if (hits.isNotEmpty()) hits.take(60) else lines.takeLast(60)).joinToString("\n").takeLast(6000)
            }
        }
        return ""
    }

    suspend fun dispatchWorkflow(owner: String, repo: String, workflow: String, inputs: JSONObject) {
        val (c, b) = call("POST", "/repos/$owner/$repo/actions/workflows/$workflow/dispatches",
            JSONObject().put("ref", "main").put("inputs", inputs))
        if (c != 204) throw GitHubException("Could not start run (HTTP $c): ${b.take(120)}")
    }

    suspend fun runLog(owner: String, repo: String, runId: Long): String {
        val (c, b) = call("GET", "/repos/$owner/$repo/actions/runs/$runId/jobs")
        if (c != 200) return ""
        val jobs = JSONObject(b).getJSONArray("jobs")
        if (jobs.length() == 0) return ""
        val (lc, lb) = call("GET", "/repos/$owner/$repo/actions/jobs/${jobs.getJSONObject(0).getLong("id")}/logs")
        if (lc != 200) return ""
        return lb.lines().joinToString("\n") { it.replaceFirst(Regex("^\\S+Z "), "") }
    }

    suspend fun dispatchBuild(owner: String, repo: String) {
        val (c, b) = call("POST", "/repos/$owner/$repo/actions/workflows/android.yml/dispatches",
            JSONObject().put("ref", "main"))
        if (c != 204) throw GitHubException("Could not start build (HTTP $c): ${b.take(120)}")
    }
}

fun safePath(p: String): String? {
    val s = p.trim().replace('\\', '/').trimStart('/')
    if (s.isEmpty() || s.length > 200) return null
    if (s.split('/').any { it.isEmpty() || it == ".." || it == "." }) return null
    if (s.startsWith(".github")) return null
    return s
}

fun parseFiles(text: String): List<GenFile> {
    try {
        val a = text.indexOf('{'); val z = text.lastIndexOf('}')
        val arr = JSONObject(text.substring(a, z + 1)).getJSONArray("files")
        val out = ArrayList<GenFile>()
        var total = 0
        for (i in 0 until minOf(arr.length(), 60)) {
            val o = arr.getJSONObject(i)
            val path = safePath(o.optString("path")) ?: continue
            val content = o.optString("content")
            total += content.length
            if (total > 600_000) break
            out += GenFile(path, content)
        }
        return out
    } catch (e: Exception) {
        throw LlmException("Model returned invalid output - please try again")
    }
}
