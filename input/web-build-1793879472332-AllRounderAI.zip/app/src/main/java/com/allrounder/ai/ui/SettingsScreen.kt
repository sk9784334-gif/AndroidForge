@file:OptIn(ExperimentalMaterial3Api::class)

package com.allrounder.ai.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import com.allrounder.ai.data.ProviderType
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.biometric.BiometricManager
import com.allrounder.ai.LOCK_AUTH
import com.allrounder.ai.R
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.allrounder.ai.ChatViewModel
import com.allrounder.ai.data.PROVIDERS
import com.allrounder.ai.data.ProviderSpec
import com.allrounder.ai.data.SettingsState

@Composable
fun SettingsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val st by vm.settings.state.collectAsState()
    var confirmDelete by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0.0"
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text("AI providers", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Add a key for any provider. The primary one is used first; the others are automatic backups.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            items(PROVIDERS.filter { it.type != ProviderType.ONDEVICE }, key = { it.id }) { spec -> ProviderCard(spec, st, vm) }
            item { OnDeviceCard(st, vm) }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Auto fallback", fontWeight = FontWeight.SemiBold)
                            Text(
                                "Try the next provider if one fails or hits a limit.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(checked = st.fallback, onCheckedChange = { vm.settings.setFallback(it) })
                    }
                }
            }
            item {
                var token by remember { mutableStateOf(st.githubToken) }
                var showTok by remember { mutableStateOf(false) }
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("GitHub hosting", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Needed to publish websites (GitHub Pages) and build APKs (GitHub Actions). Create a classic token " +
                                "with only the repo and workflow scopes. It is sent only to api.github.com. Revoke it any time.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = token,
                            onValueChange = { token = it; vm.settings.setGithubToken(it) },
                            label = { Text("GitHub token") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            visualTransformation = if (showTok) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            trailingIcon = { TextButton(onClick = { showTok = !showTok }) { Text(if (showTok) "Hide" else "Show") } }
                        )
                    }
                }
            }
            item {
                var prompt by remember { mutableStateOf(st.systemPrompt) }
                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it; vm.settings.setSystemPrompt(it) },
                    label = { Text("System prompt") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    maxLines = 6
                )
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Privacy", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "API keys are stored encrypted on this device. Your messages are sent directly " +
                                "from your phone to the provider you choose - there is no AllRounder server in between. " +
                                "Chats are saved only on this device.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            item {
                var tk by remember { mutableStateOf(st.tavilyKey) }
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Web search", fontWeight = FontWeight.SemiBold)
                                Text(
                                    "Adds fresh web results to your questions. Your question text is sent to Tavily (needs a Tavily API key).",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(checked = st.webSearch, onCheckedChange = { vm.settings.setWebSearch(it) })
                        }
                        OutlinedTextField(
                            value = tk,
                            onValueChange = { tk = it; vm.settings.setTavilyKey(it) },
                            label = { Text("Tavily API key") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                        )
                    }
                }
            }
            item {
                var lockMsg by remember { mutableStateOf("") }
                val uri = LocalUriHandler.current
                val policy = ctx.getString(R.string.privacy_url)
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("App lock", fontWeight = FontWeight.SemiBold)
                                Text(
                                    "Ask for fingerprint, face or screen lock to open the app. Also hides it in recent apps and blocks screenshots.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(checked = st.appLock, onCheckedChange = { on ->
                                if (!on) { vm.settings.setAppLock(false); lockMsg = "" }
                                else if (BiometricManager.from(ctx).canAuthenticate(LOCK_AUTH) == BiometricManager.BIOMETRIC_SUCCESS) {
                                    vm.settings.setAppLock(true); lockMsg = ""
                                } else lockMsg = "Set a screen lock or fingerprint on your phone first."
                            })
                        }
                        if (lockMsg.isNotEmpty()) Text(lockMsg, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        if (!policy.contains("CHANGE_ME")) TextButton(onClick = { uri.openUri(policy) }) { Text("Privacy policy") }
                    }
                }
            }
            item {
                OutlinedButton(
                    onClick = { confirmDelete = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) { Text("Delete all chats") }
            }
            item {
                Text(
                    "AllRounder AI  v$version",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete all chats?") },
            text = { Text("This permanently removes every conversation from this device.") },
            confirmButton = {
                TextButton(onClick = { vm.deleteAll(); confirmDelete = false }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ProviderCard(spec: ProviderSpec, st: SettingsState, vm: ChatViewModel) {
    var key by remember(spec.id) { mutableStateOf(st.keys[spec.id].orEmpty()) }
    var url by remember(spec.id) { mutableStateOf(st.urls[spec.id].orEmpty()) }
    var model by remember(spec.id) { mutableStateOf(st.models[spec.id]?.takeIf { it.isNotBlank() } ?: spec.defaultModel) }
    var show by remember { mutableStateOf(false) }
    val isPrimary = st.preferred == spec.id
    val active = if (spec.needsKey) key.isNotBlank() else url.isNotBlank()

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    spec.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                if (active) {
                    FilterChip(
                        selected = isPrimary,
                        onClick = { vm.settings.setPreferred(spec.id) },
                        label = { Text(if (isPrimary) "Primary" else "Make primary") }
                    )
                }
            }
            run {
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it; vm.settings.setKey(spec.id, it) },
                    label = { Text(if (spec.needsKey) "API key" else "API key (optional)") },
                    placeholder = { Text(spec.keyHint) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = { TextButton(onClick = { show = !show }) { Text(if (show) "Hide" else "Show") } }
                )
            }
            if (!spec.needsKey) {
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it; vm.settings.setUrl(spec.id, it) },
                    label = { Text("Server URL (empty = off)") },
                    placeholder = { Text(spec.baseUrl) },
                    supportingText = { Text("Any OpenAI-compatible server. Plain http works only for 127.0.0.1 / localhost (e.g. Ollama in Termux); other hosts need https.") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            OutlinedTextField(
                value = model,
                onValueChange = { model = it; vm.settings.setModel(spec.id, it) },
                label = { Text("Model") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun OnDeviceCard(st: SettingsState, vm: ChatViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            busy = true; msg = "Importing model - this can take a minute..."
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        val dest = File(ctx.filesDir, "model.task")
                        ctx.contentResolver.openInputStream(uri)!!.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
                        vm.settings.setModelPath(dest.absolutePath)
                    }
                    msg = "Model ready"
                } catch (e: Exception) {
                    msg = "Import failed: ${e.message}"
                } finally { busy = false }
            }
        }
    }
    val has = st.modelPath.isNotBlank()
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "On-device model (offline)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                if (has) FilterChip(
                    selected = st.preferred == "ondevice",
                    onClick = { vm.settings.setPreferred("ondevice") },
                    label = { Text(if (st.preferred == "ondevice") "Primary" else "Make primary") }
                )
            }
            Text(
                "Runs fully on your phone, no internet. First download a MediaPipe-compatible .task model (Gemma family) " +
                    "to your phone, then import it here. Needs a recent phone with plenty of RAM; replies are slower than cloud models.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !busy) {
                    Text(if (has) "Replace model" else "Import model file")
                }
                if (has) TextButton(onClick = { File(st.modelPath).delete(); vm.settings.setModelPath("") }, enabled = !busy) {
                    Text("Remove")
                }
            }
            if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall)
        }
    }
}
