package com.aigirlfriend.vtuber.ai

class AiOrchestrator {
    private val api = ApiModelManager()
    @Volatile private var apiKey: String? = null
    @Volatile private var provider: String = "gemini"

    fun configure(apiKey: String?, provider: String = "gemini") {
        this.apiKey = apiKey?.trim()?.takeIf { it.isNotEmpty() }
        this.provider = provider.lowercase()
    }

    // Call from a background coroutine/thread, never the Android main thread.
    fun processPrompt(prompt: String): String {
        val key = apiKey ?: return "Please add your API key in app settings before chatting."
        return try {
            when (provider) {
                "openai" -> api.callOpenAI(prompt, key)
                "gemini" -> api.callGemini(prompt, key)
                else -> "Unsupported AI provider: $provider"
            }
        } catch (e: Exception) {
            "AI request failed: ${e.message ?: "network error"}"
        }
    }
}
