package com.aigirlfriend.vtuber.util

import android.content.Context

class SettingsManager(context: Context) {
    private val prefs = context.getSharedPreferences("ai_girlfriend_prefs", Context.MODE_PRIVATE)
    fun setApiKey(key: String) { prefs.edit().putString("api_key", key).apply() }
    fun getApiKey(): String? = prefs.getString("api_key", null)
    fun setPreferLocal(prefer: Boolean) { prefs.edit().putBoolean("prefer_local", prefer).apply() }
    fun getPreferLocal(): Boolean = prefs.getBoolean("prefer_local", true)
    fun setCharacterName(name: String) { prefs.edit().putString("character_name", name).apply() }
    fun getCharacterName(): String = prefs.getString("character_name", "Companion") ?: "Companion"
}
