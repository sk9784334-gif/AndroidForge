package com.aigirlfriend.vtuber.services

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent

class AssistantAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "Accessibility service connected")
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally does not read or upload screen text. Add user-consented features only.
    }
    override fun onInterrupt() { Log.d(TAG, "Interrupted") }
    companion object { private const val TAG = "AIGFAccessibility" }
}
