package com.aigirlfriend.vtuber.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.sin

class AvatarView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    private val facePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val detailPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var tick = 0
    private var animationStarted = false

    fun startAnimation() {
        if (animationStarted) return
        animationStarted = true
        post(object : Runnable {
            override fun run() {
                tick++
                invalidate()
                if (isAttachedToWindow) postDelayed(this, 80)
                else animationStarted = false
            }
        })
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) * 0.34f
        facePaint.color = Color.rgb(255, 182, 193)
        detailPaint.color = Color.rgb(75, 35, 55)
        canvas.drawCircle(cx, cy, r, facePaint)
        canvas.drawCircle(cx - r * .34f, cy - r * .12f, r * .09f, detailPaint)
        canvas.drawCircle(cx + r * .34f, cy - r * .12f, r * .09f, detailPaint)
        val mouth = (sin(tick * .25) * r * .08).toFloat()
        val mouthRect = RectF(cx - r * .20f, cy + r * .25f + mouth, cx + r * .20f, cy + r * .36f + mouth)
        detailPaint.color = Color.WHITE
        canvas.drawRoundRect(mouthRect, r * .1f, r * .1f, detailPaint)
    }
}
