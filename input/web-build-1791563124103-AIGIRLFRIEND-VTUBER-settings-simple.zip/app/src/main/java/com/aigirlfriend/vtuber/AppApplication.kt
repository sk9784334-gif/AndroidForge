package com.aigirlfriend.vtuber

import android.app.Application
import android.content.Context
import androidx.datastore.preferences.preferencesDataStore

private const val DATA_STORE_NAME = "ai_girlfriend_prefs"
val Context.dataStore by preferencesDataStore(name = DATA_STORE_NAME)

class AppApplication : Application()
