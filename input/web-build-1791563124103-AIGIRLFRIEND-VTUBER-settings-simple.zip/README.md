# AI Girlfriend VTuber — corrected starter project

This is a corrected Android Studio starter project, not a finished AI companion app.

## Included
- Android project structure and Gradle configuration
- Draggable floating avatar overlay
- Foreground notification for the overlay service
- Optional accessibility service that does not read screen content
- JSON-safe request construction for Gemini and OpenAI API calls
- Basic AI API orchestration helper

## Not implemented yet
- Full chat screen and settings UI
- Actual on-device LLM inference (a model file alone does not run itself)
- Speech-to-text and natural text-to-speech
- Unity/Live2D model integration
- Secure API key entry/storage UI

## Build
Use Android Studio with JDK 17 and Android SDK platform 34 or newer. Open the extracted project folder and sync Gradle.

## Important Android phone / Termux note
Termux alone normally does not include the Android SDK/build-tools needed to build an APK. You can edit files in Termux, but the easiest phone-only build route is to push this project to a GitHub repository and use GitHub Actions to build the APK, or use a compatible Android IDE app. Never publish API keys in a public repository.

## Permissions
The app asks for microphone/notification permissions but does not record audio in this starter version. The overlay needs the user to enable "Display over other apps". Accessibility is optional and currently does not collect screen content.
