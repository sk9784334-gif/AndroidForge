
package com.allrounder.ai.data

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Fully offline inference with a MediaPipe-compatible .task model (Gemma family). */
object OnDeviceLlm {
    private var engine: LlmInference? = null
    private var loadedPath: String? = null

    suspend fun generate(ctx: Context, path: String, system: String, history: List<Turn>): String =
        withContext(Dispatchers.Default) {
            if (path.isBlank() || !File(path).exists()) {
                throw LlmException("On-device model missing - import a .task model in Settings")
            }
            val e = synchronized(this@OnDeviceLlm) {
                if (engine == null || loadedPath != path) {
                    engine?.close()
                    engine = try {
                        LlmInference.createFromOptions(
                            ctx.applicationContext,
                            LlmInference.LlmInferenceOptions.builder().setModelPath(path).setMaxTokens(2048).build()
                        )
                    } catch (ex: Exception) {
                        throw LlmException("Could not load on-device model: ${ex.message}")
                    }
                    loadedPath = path
                }
                engine!!
            }
            val turns = history.takeLast(6)
            val prompt = buildString {
                turns.forEachIndexed { i, t ->
                    val text = if (i == 0 && t.role == "user" && system.isNotBlank()) system + "\n\n" + t.content else t.content
                    append(if (t.role == "user") "<start_of_turn>user\n" else "<start_of_turn>model\n")
                    append(text.take(4000)).append("<end_of_turn>\n")
                }
                append("<start_of_turn>model\n")
            }
            try {
                e.generateResponse(prompt).trim()
            } catch (ex: Exception) {
                throw LlmException("On-device error: ${ex.message}")
            }
        }
}

suspend fun runProvider(
    ctx: Context, spec: ProviderSpec, s: SettingsState, system: String, history: List<Turn>,
    onDelta: ((String) -> Unit)? = null
): String =
    if (spec.type == ProviderType.ONDEVICE) OnDeviceLlm.generate(ctx, s.modelPath, system, history)
    else LlmClient.complete(spec, s.keys[spec.id].orEmpty(), s.modelFor(spec), system, history, s.urls[spec.id], s.temperature, onDelta)
