
package com.allrounder.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.allrounder.ai.data.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import android.net.Uri
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    val settings = SettingsRepo.get(app)

    val currentChatId = MutableStateFlow<Long?>(null)
    val loading = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)
    /** Text of the reply while it is still being streamed in. */
    val streaming = MutableStateFlow<String?>(null)
    /** Text to put back into the input box (edit & resend, shared text). */
    val draft = MutableStateFlow<String?>(null)
    val policyStatus = MutableStateFlow("")

    val chats: StateFlow<List<ChatEntity>> = dao.chats()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val messages: StateFlow<List<MessageEntity>> = currentChatId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.messages(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var job: Job? = null

    fun send(text: String, image: String? = null) {
        val t = text.trim()
        if ((t.isEmpty() && image == null) || loading.value) return
        job = viewModelScope.launch {
            val now = System.currentTimeMillis()
            var id = currentChatId.value
            if (id == null) {
                id = dao.insertChat(ChatEntity(title = t.ifBlank { "Image" }.take(48), updatedAt = now))
                currentChatId.value = id
            }
            dao.insertMessage(
                MessageEntity(chatId = id, role = "user", content = t, provider = null, createdAt = now, image = image)
            )
            dao.touch(id, now)
            generate(id)
        }
    }

    fun retry() {
        val id = currentChatId.value ?: return
        if (loading.value) return
        job = viewModelScope.launch { generate(id) }
    }

    /** Stops generation but keeps whatever was already streamed. */
    fun stop() {
        val partial = streaming.value
        val id = currentChatId.value
        job?.cancel()
        if (!partial.isNullOrBlank() && id != null) {
            viewModelScope.launch {
                dao.insertMessage(
                    MessageEntity(
                        chatId = id, role = "assistant", content = partial,
                        provider = "Stopped", createdAt = System.currentTimeMillis()
                    )
                )
            }
        }
    }

    private suspend fun withWebSearch(s: SettingsState, history: List<Turn>, base: String): String {
        if (!s.webSearch || s.tavilyKey.isBlank()) return base
        val q = history.lastOrNull { it.role == "user" }?.content?.takeIf { it.isNotBlank() } ?: return base
        return try {
            val r = SearchClient.search(s.tavilyKey, q)
            if (r.isBlank()) base
            else base + "\n\nLive web search results for the user's latest message " +
                "(use them when relevant and mention the source URLs):\n" + r
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            base
        }
    }

    private suspend fun generate(chatId: Long) {
        error.value = null
        streaming.value = null
        loading.value = true
        try {
            val s = settings.state.value
            val order = s.providerOrder()
            if (order.isEmpty()) {
                error.value = "Add an API key in Settings to start chatting."
                return
            }
            val history = dao.messagesOnce(chatId).map { Turn(it.role, it.content, it.image) }
            var base = dao.chat(chatId)?.systemPrompt?.takeIf { it.isNotBlank() } ?: s.systemPrompt
            if (s.replyLang.isNotBlank()) base += "\n\nAlways reply in: " + s.replyLang + "."
            val system = withWebSearch(s, history, base)
            var last = "Request failed"
            for (spec in order) {
                streaming.value = null
                try {
                    val reply = runProvider(getApplication<Application>(), spec, s, system, history) { streaming.value = it }
                    val now = System.currentTimeMillis()
                    dao.insertMessage(
                        MessageEntity(chatId = chatId, role = "assistant", content = reply, provider = spec.name, createdAt = now)
                    )
                    dao.touch(chatId, now)
                    return
                } catch (e: LlmException) {
                    last = e.message ?: last
                    if (!s.fallback) break
                }
            }
            error.value = last
        } finally {
            loading.value = false
            streaming.value = null
        }
    }

    fun deleteMessage(id: Long) {
        if (loading.value) return
        viewModelScope.launch { dao.deleteMessage(id) }
    }

    fun editMessage(m: MessageEntity) {
        if (loading.value) return
        viewModelScope.launch {
            dao.deleteFrom(m.chatId, m.id)
            draft.value = m.content
        }
    }

    fun regenerate() {
        val id = currentChatId.value ?: return
        if (loading.value) return
        job = viewModelScope.launch {
            val last = dao.messagesOnce(id).lastOrNull()
            if (last != null && last.role == "assistant") dao.deleteMessage(last.id)
            generate(id)
        }
    }

    fun duplicateChat(chat: ChatEntity) {
        viewModelScope.launch {
            val newId = dao.insertChat(
                ChatEntity(title = chat.title + " (copy)", updatedAt = System.currentTimeMillis(), systemPrompt = chat.systemPrompt)
            )
            dao.messagesOnce(chat.id).forEach { dao.insertMessage(it.copy(id = 0, chatId = newId)) }
        }
    }

    fun clearChat(id: Long) {
        viewModelScope.launch { dao.clearMessages(id) }
    }

    suspend fun exportBackup(): Uri = withContext(Dispatchers.IO) {
        val app = getApplication<Application>()
        val msgs = dao.allMessages().groupBy { it.chatId }
        val arr = JSONArray()
        dao.allChats().forEach { c ->
            val ma = JSONArray()
            msgs[c.id].orEmpty().forEach { m ->
                ma.put(
                    JSONObject().put("role", m.role).put("content", m.content)
                        .put("provider", m.provider ?: JSONObject.NULL).put("createdAt", m.createdAt)
                )
            }
            arr.put(
                JSONObject().put("title", c.title).put("updatedAt", c.updatedAt).put("pinned", c.pinned)
                    .put("systemPrompt", c.systemPrompt ?: JSONObject.NULL).put("messages", ma)
            )
        }
        val dir = File(app.cacheDir, "exports").apply { mkdirs() }
        val f = File(dir, "allrounder-backup.json")
        f.writeText(JSONObject().put("version", 1).put("chats", arr).toString())
        FileProvider.getUriForFile(app, app.packageName + ".fileprovider", f)
    }

    suspend fun importBackup(uri: Uri): Int = withContext(Dispatchers.IO) {
        val text = getApplication<Application>().contentResolver.openInputStream(uri)
            ?.bufferedReader()?.use { it.readText() } ?: return@withContext 0
        val arr = JSONObject(text).getJSONArray("chats")
        var n = 0
        for (i in 0 until arr.length()) {
            val c = arr.getJSONObject(i)
            val id = dao.insertChat(
                ChatEntity(
                    title = c.optString("title", "Imported chat"),
                    updatedAt = c.optLong("updatedAt", System.currentTimeMillis()),
                    pinned = c.optBoolean("pinned"),
                    systemPrompt = if (c.isNull("systemPrompt")) null else c.optString("systemPrompt")
                )
            )
            val ms = c.getJSONArray("messages")
            for (j in 0 until ms.length()) {
                val m = ms.getJSONObject(j)
                dao.insertMessage(
                    MessageEntity(
                        chatId = id, role = m.getString("role"), content = m.optString("content"),
                        provider = if (m.isNull("provider")) null else m.optString("provider"),
                        createdAt = m.optLong("createdAt")
                    )
                )
            }
            n++
        }
        n
    }

    /** Publishes the bundled privacy policy page to the developer's own GitHub Pages (gives the URL Play Console needs). */
    fun publishPolicy() {
        val token = settings.state.value.githubToken
        if (token.isBlank()) { policyStatus.value = "Add your GitHub token first (GitHub hosting card)."; return }
        viewModelScope.launch {
            try {
                policyStatus.value = "Publishing..."
                val api = GitHubApi(token)
                val owner = api.login()
                val repo = "allrounder-privacy"
                api.createRepo(repo)
                val page = getApplication<Application>().assets.open("privacy-policy.html").bufferedReader().readText()
                api.putFile(owner, repo, GenFile("index.html", page))
                api.enablePages(owner, repo)
                policyStatus.value = "https://$owner.github.io/$repo/\nLive in 1-2 minutes. Paste this URL in Play Console and strings.xml (privacy_url)."
            } catch (e: GitHubException) {
                policyStatus.value = e.message ?: "Failed"
            }
        }
    }

    fun renameChat(id: Long, title: String) {
        viewModelScope.launch { dao.rename(id, title.trim().take(60)) }
    }

    fun togglePin(chat: ChatEntity) {
        viewModelScope.launch { dao.setPinned(chat.id, !chat.pinned) }
    }

    fun setChatPrompt(id: Long, prompt: String) {
        viewModelScope.launch { dao.setSystemPrompt(id, prompt.trim().ifBlank { null }) }
    }

    fun newChat() {
        job?.cancel()
        currentChatId.value = null
        error.value = null
    }

    fun openChat(id: Long) {
        job?.cancel()
        currentChatId.value = id
        error.value = null
    }

    fun deleteChat(id: Long) {
        viewModelScope.launch {
            if (currentChatId.value == id) newChat()
            dao.deleteChat(id)
        }
    }

    fun deleteAll() {
        viewModelScope.launch {
            newChat()
            dao.deleteAll()
        }
    }
}
