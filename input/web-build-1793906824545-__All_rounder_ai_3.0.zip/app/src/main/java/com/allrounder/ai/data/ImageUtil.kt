
package com.allrounder.ai.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlin.math.max

object ImageUtil {
    /** Reads an image via the system Photo Picker URI, downsizes it and returns base64 JPEG (or null). */
    fun encode(ctx: Context, uri: Uri, maxSide: Int = 1024): String? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        if (bmp == null) null else {
            val scale = maxSide.toFloat() / max(bmp.width, bmp.height)
            val out = if (scale < 1f) Bitmap.createScaledBitmap(
                bmp, (bmp.width * scale).toInt().coerceAtLeast(1), (bmp.height * scale).toInt().coerceAtLeast(1), true
            ) else bmp
            val bos = ByteArrayOutputStream()
            out.compress(Bitmap.CompressFormat.JPEG, 80, bos)
            Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        }
    } catch (e: Exception) {
        null
    }

    /** Renders the first pages of a PDF to JPEGs (joined with |) so vision models can read them. */
    fun pdfPages(ctx: Context, uri: Uri, maxPages: Int = 5, maxSide: Int = 1100): String? = try {
        ctx.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
            PdfRenderer(pfd).use { r ->
                val out = ArrayList<String>()
                for (i in 0 until minOf(r.pageCount, maxPages)) {
                    r.openPage(i).use { page ->
                        val scale = maxSide.toFloat() / max(page.width, page.height)
                        val bmp = Bitmap.createBitmap(
                            (page.width * scale).toInt().coerceAtLeast(1),
                            (page.height * scale).toInt().coerceAtLeast(1),
                            Bitmap.Config.ARGB_8888
                        )
                        bmp.eraseColor(android.graphics.Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        val bos = ByteArrayOutputStream()
                        bmp.compress(Bitmap.CompressFormat.JPEG, 80, bos)
                        out += Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
                    }
                }
                if (out.isEmpty()) null else out.joinToString("|")
            }
        }
    } catch (e: Exception) {
        null
    }

    fun decode(b64: String): Bitmap? = try {
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    } catch (e: Exception) {
        null
    }
}
