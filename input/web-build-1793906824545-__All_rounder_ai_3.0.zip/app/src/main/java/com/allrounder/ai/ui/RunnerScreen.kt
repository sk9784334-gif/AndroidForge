
@file:OptIn(ExperimentalMaterial3Api::class)

package com.allrounder.ai.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.allrounder.ai.Lang
import com.allrounder.ai.RunnerViewModel
import com.allrounder.ai.RunnerPrefill
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString

@Composable
fun RunnerScreen(onBack: () -> Unit, onSettings: () -> Unit) {
    val vm: RunnerViewModel = viewModel()
    val busy by vm.busy.collectAsState()
    val status by vm.status.collectAsState()
    val output by vm.output.collectAsState()
    val error by vm.error.collectAsState()
    val pre = remember { RunnerPrefill.take() }
    var lang by rememberSaveable { mutableStateOf(pre.first ?: Lang.PYTHON) }
    var code by rememberSaveable { mutableStateOf(pre.second.ifBlank { (pre.first ?: Lang.PYTHON).template }) }
    val clip = LocalClipboardManager.current

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Code runner") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    "Runs your code in a private repo on your own GitHub (allrounder-runner) using GitHub Actions. " +
                        "Nothing runs on your phone. Takes about 30-60 seconds, 5 min limit.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Lang.values().forEach {
                        FilterChip(
                            selected = lang == it,
                            onClick = { if (code.isBlank() || code == lang.template) code = it.template; lang = it },
                            label = { Text(it.label) }
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = code, onValueChange = { code = it },
                    label = { Text("Code (${lang.file})") },
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                    modifier = Modifier.fillMaxWidth(), minLines = 8, maxLines = 20
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { vm.run(lang, code) },
                    enabled = !busy && code.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Run") }
            }
            if (busy) item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(status)
                }
            }
            error?.let { msg ->
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        contentColor = MaterialTheme.colorScheme.onErrorContainer,
                        shape = MaterialTheme.shapes.medium
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(msg)
                            TextButton(onClick = onSettings) { Text("Open settings") }
                        }
                    }
                }
            }
            if (output.isNotEmpty()) item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Output", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                    TextButton(onClick = { clip.setText(AnnotatedString(output)) }) { Text("Copy") }
                }
                Spacer(Modifier.height(4.dp))
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.medium) {
                    SelectionContainer {
                        Text(output, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(12.dp).fillMaxWidth())
                    }
                }
            }
        }
    }
}
