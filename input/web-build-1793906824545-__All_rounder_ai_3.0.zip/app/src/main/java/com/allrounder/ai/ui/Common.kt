package com.allrounder.ai.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import com.allrounder.ai.R
import com.allrounder.ai.Lang
import androidx.compose.runtime.staticCompositionLocalOf

@Composable
fun LogoMark(size: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.28f))
            .background(Brush.linearGradient(listOf(BrandViolet, BrandCyan))),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(R.drawable.ic_logo_mark),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(0.62f)
        )
    }
}

/** Lets a code block in a chat open the Code runner pre-filled. Provided in MainActivity. */
val LocalOpenRunner = staticCompositionLocalOf<(Lang, String) -> Unit> { { _, _ -> } }

fun langFor(tag: String): Lang? = when (tag) {
    "python", "py", "python3" -> Lang.PYTHON
    "javascript", "js", "node" -> Lang.JS
    "bash", "sh", "shell" -> Lang.SHELL
    "java" -> Lang.JAVA
    else -> null
}
