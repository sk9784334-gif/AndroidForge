# New features (beyond v1.5)

**30 built in v1.7.0, 36 planned. Total 66.**

## Built

1. PDF attach (first 5 pages sent as images to vision models)
2. Several images per message
3. Run button on chat code blocks (Python, JavaScript, Shell, Java)
4. Backup all chats to a JSON file
5. Restore chats from a backup file
6. In-app privacy policy screen
7. One-tap publish of the privacy policy page to your GitHub Pages (URL for Play Console)
8. Regenerate the last reply
9. Edit and resend a message
10. Delete a single message
11. Message timestamps
12. Duplicate a chat
13. Clear a chat's messages
14. Theme choice: system / light / dark
15. Text size (S/M/L/XL)
16. Accent colour (5 choices)
17. Custom temperature setting
18. Reply-language preference (e.g. Hinglish)
19. Prompt library (saved prompts, sparkle button)
20. Model switcher in the top bar
21. Haptic feedback on send
22. Token estimate for long messages
23. Keep screen on while the AI is replying
24. Block-screenshots setting
25. Reset app (keys, settings, chats)
26. Web builder starter templates
27. App builder starter templates
28. Code runner hello-world templates
29. Copy Code runner output
30. Receive text from other apps via the Share sheet

## Planned

31. Auto-generate chat titles with AI
32. Search inside the current chat
33. Export a chat as Markdown or PDF
34. Bookmark / star messages
35. Starred messages list
36. Folders and tags for chats
37. Scroll-to-bottom button
38. Read replies aloud (text-to-speech)
39. Offline queue: retry when the network returns
40. Compare two models on one prompt
41. Per-chat model choice
42. Token and cost usage tracker
43. Response length presets
44. Streaming for the on-device model
45. Personas / chat templates
46. Share a reply as an image card
47. Home-screen shortcut and quick-ask tile
48. Quick-ask from clipboard
49. Markdown tables and headings in replies
50. Math (LaTeX) rendering
51. Syntax highlighting in code blocks
52. Web builder: multi-page sites and custom domain
53. Web builder: AI-made images
54. App builder: signed release AAB via Actions with your keystore secret
55. App builder: app icon generation
56. Code runner: stdin input and file upload
57. Code runner: Go, Rust, C++
58. Code runner: run history
59. Auto-lock timeout setting
60. Hindi / Hinglish app language
61. Tablet and foldable two-pane layout
62. Home-screen widgets
63. Notification when a long build finishes
64. Passphrase-encrypted backups
65. Camera capture attach
66. Hands-free voice conversation mode
