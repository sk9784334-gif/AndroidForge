plugins {
    id("com.android.application")
    id("com.chaquo.python")
}

android {
    namespace = "com.artemis.helper"
    compileSdk = 35
    ndkVersion = "27.2.12479018"

    defaultConfig {
        applicationId = "com.artemis.helper"
        minSdk = 26
        targetSdk = 35
        versionCode = 7
        versionName = "1.3.0"
        ndk { abiFilters += "arm64-v8a" }
        externalNativeBuild { cmake { cppFlags += "-std=c++17" } }
    }
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    lint { abortOnError = false; checkReleaseBuilds = false }
    packaging { jniLibs { pickFirsts += "**/libc++_shared.so" } }
}

chaquopy {
    defaultConfig {
        version = "3.12"
        buildPython("python3")
        pip { install("-r", "requirements-android.txt") }
    }
}
