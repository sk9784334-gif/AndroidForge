"""Stub modules for packages mobile-use imports at module level but never uses on Android (iOS / BrowserStack / Vertex)."""
import sys, types, importlib.util

class _Any:
    def __init__(self, *a, **k): pass
    def __call__(self, *a, **k): return _Any()
    def __getattr__(self, n): return _Any()

class _Stub(types.ModuleType):
    __path__ = []
    def __getattr__(self, name):
        if name.startswith("__"): raise AttributeError(name)
        return type(name, (_Any,), {})

def _stub(name):
    if name in sys.modules: return
    try:
        if importlib.util.find_spec(name.split(".")[0]) is not None and "." not in name: return
    except Exception: pass
    sys.modules[name] = _Stub(name)

def install():
    for n in ["idb", "idb.common", "idb.common.types", "idb.grpc", "idb.grpc.client",
              "wda", "wda.exceptions", "appium", "appium.options", "appium.options.common",
              "appium.options.common.base", "appium.webdriver", "appium.webdriver.webdriver",
              "langchain_google_vertexai", "jupyter_client", "jupyter_client.blocking"]:
        _stub(n)
    if importlib.util.find_spec("uuid_utils") is None:
        import uuid
        m = types.ModuleType("uuid_utils"); m.uuid7 = uuid.uuid4; m.uuid4 = uuid.uuid4; sys.modules["uuid_utils"] = m
