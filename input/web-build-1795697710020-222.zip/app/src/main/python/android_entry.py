import os, asyncio, traceback
import android_stubs; android_stubs.install()

def run(engine, goal, google_key, openai_key, adb_host, adb_port, base_url):
    """Called from Java. engine = 'artemis' | 'mobile_use'. Needs a PC adb server at adb_host:adb_port with the target phone attached."""
    for k in ("MOBILE_USE_TELEMETRY_ENABLED", "ARTEMIS_TELEMETRY_ENABLED"): os.environ[k] = "false"
    if google_key: os.environ["GOOGLE_API_KEY"] = google_key
    if openai_key: os.environ["OPENAI_API_KEY"] = openai_key
    if base_url: os.environ["OPENAI_BASE_URL"] = base_url
    os.environ["ADB_HOST"] = adb_host; os.environ["ADB_PORT"] = str(adb_port)
    try:
        return asyncio.run(_go(engine, goal, adb_host, int(adb_port)))
    except Exception:
        return "ERROR:\n" + traceback.format_exc()

async def _go(engine, goal, host, port):
    if engine == "mobile_use":
        from minitap.mobile_use.sdk import Agent
        from minitap.mobile_use.sdk.builders import Builders
        cfg = Builders.AgentConfig.with_adb_server(host, port).build()
    else:
        from artemis.sdk import Agent
        from artemis.sdk.builders import AgentConfigBuilder
        cfg = AgentConfigBuilder().with_adb_server(host, port).build()
    agent = Agent(config=cfg)
    try:
        await agent.init()
        return str(await agent.run_task(goal=goal))
    finally:
        try: await agent.clean()
        except Exception: pass
