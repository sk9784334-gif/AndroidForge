package com.artemis.helper;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.*;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

/** Launcher: runs Artemis (default) or upstream mobile-use via Python (Chaquopy). Needs a PC adb server: adb -a nodaemon server */
public class MainActivity extends Activity {
    private EditText field(String hint, String value, boolean secret) {
        EditText e = new EditText(this); e.setHint(hint); e.setText(value);
        if (secret) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return e;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
        final SharedPreferences p = getSharedPreferences("am", MODE_PRIVATE);
        final EditText host = field("ADB server host (PC)", p.getString("host", "192.168.1.10"), false);
        final EditText port = field("ADB port", p.getString("port", "5037"), false);
        final EditText gkey = field("Google API key", p.getString("g", ""), true);
        final EditText okey = field("OpenAI API key", p.getString("o", ""), true);
        final EditText base = field("OpenAI base URL (optional)", p.getString("b", ""), false);
        final EditText goal = field("Task, e.g. Open Settings and turn on Wi-Fi", "", false);
        final RadioGroup engine = new RadioGroup(this);
        RadioButton rA = new RadioButton(this); rA.setText("Artemis"); rA.setId(1);
        RadioButton rM = new RadioButton(this); rM.setText("Mobile Use (minitap)"); rM.setId(2);
        engine.addView(rA); engine.addView(rM); engine.check(1);
        Button a11y = new Button(this); a11y.setText("Enable Accessibility Helper");
        a11y.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        final Button run = new Button(this); run.setText("Run");
        final TextView out = new TextView(this); out.setTextIsSelectable(true);
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setPadding(32, 96, 32, 32);
        for (android.view.View v : new android.view.View[]{engine, host, port, gkey, okey, base, goal, a11y, run, out})
            col.addView(v, new ViewGroup.LayoutParams(-1, -2));
        ScrollView sv = new ScrollView(this); sv.addView(col); setContentView(sv);

        run.setOnClickListener(v -> {
            p.edit().putString("host", host.getText().toString()).putString("port", port.getText().toString())
                .putString("g", gkey.getText().toString()).putString("o", okey.getText().toString()).putString("b", base.getText().toString()).apply();
            run.setEnabled(false); out.setText("Running...");
            final String eng = engine.getCheckedRadioButtonId() == 2 ? "mobile_use" : "artemis";
            new Thread(() -> {
                String r;
                try {
                    int prt = 5037; try { prt = Integer.parseInt(port.getText().toString()); } catch (Exception ignored) {}
                    PyObject m = Python.getInstance().getModule("android_entry");
                    r = m.callAttr("run", eng, goal.getText().toString(), gkey.getText().toString(),
                        okey.getText().toString(), host.getText().toString(), prt, base.getText().toString()).toString();
                } catch (Exception e) { r = "ERROR: " + e; }
                final String res = r;
                runOnUiThread(() -> { out.setText(res); run.setEnabled(true); });
            }).start();
        });
    }
}
