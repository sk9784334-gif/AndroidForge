// Minimal native module: keeps NDK + CMake + Ninja + Clang(ARM64) in the build chain. Not loaded by the app.
#include <jni.h>
extern "C" JNIEXPORT jint JNICALL Java_com_artemis_helper_NativeStub_version(JNIEnv*, jclass) { return 1; }
