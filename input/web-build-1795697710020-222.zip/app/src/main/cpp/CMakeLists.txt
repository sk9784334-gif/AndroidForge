cmake_minimum_required(VERSION 3.22.1)
project(artemis_native LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 17)
add_library(artemis_native SHARED native-lib.cpp)
