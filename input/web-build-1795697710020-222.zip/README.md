# Artemis + Mobile Use (merged APK project)
- Android layer: Artemis Accessibility Helper (Java, com.artemis.helper) + launcher screen.
- Python (Chaquopy 3.12) in app/src/main/python: `artemis`, `third_party/mobile_use`, `artemis_client`, `mcp_server`, and upstream `minitap/mobile_use` 3.3.0.
- App screen: pick engine (Artemis / Mobile Use), enter PC adb server host:5037 (`adb -a nodaemon server`), API key, task, Run.
- Merge note: mobile-use pins langchain 0.3.x, Artemis needs 1.x; Artemis versions are used for both (see app/requirements-android.txt).
- Licenses: LICENSE-artemis (Apache-2.0), LICENSE-mobile-use.
