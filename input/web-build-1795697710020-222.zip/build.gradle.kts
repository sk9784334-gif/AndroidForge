// Repos used: mavenCentral() maven.google.com jitpack.io are listed here on purpose so AndroidForge's repo injector skips this file.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("com.chaquo.python") version "16.0.0" apply false
}
