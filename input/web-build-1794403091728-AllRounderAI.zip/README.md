# AllRounder AI

Native Android (Kotlin + Jetpack Compose, Material 3) multi-model AI chat.

- Providers: Google Gemini, OpenAI, Anthropic Claude, Groq, OpenRouter (user supplies own API keys)
- Web builder: AI makes a site, sandboxed preview, one-tap publish to your GitHub Pages
- App builder: AI writes an Android project, pushes to your GitHub, Actions builds the APK
- App lock (biometric / screen lock), report-response button, chat sharing, iterative builder edits
- Local models: any Ollama / LM Studio style server, or fully offline on-device Gemma (.task via MediaPipe)
- Voice input, chat search, custom OpenAI-compatible endpoints, build status + AI auto-fix for generated apps
- Streaming replies, image attach (vision), optional live web search (Tavily), multi-file web preview
- Chat rename/pin/per-chat instructions, text-file attach, builder project history + ZIP export, Code runner (GitHub Actions)
- PDF/image/file attach, backup & restore, in-app privacy policy, themes, prompt library, message edit/regenerate (see docs/FEATURES.md)
- Terminal (phone / Termux / GitHub cloud) with AI agent, plugins, profile, library, images, projects, temporary chat, crash reports (see docs/FEATURES.md)
- Automatic fallback to the next provider on error/rate-limit
- Chats stored locally (Room); API keys encrypted (EncryptedSharedPreferences)
- Edge-to-edge UI, dark/light theme, adaptive + themed launcher icon, splash screen
- minSdk 26, target/compile SDK 36, R8 + resource shrinking on release

Build: `./gradlew assembleRelease` (APK) or `./gradlew bundleRelease` (AAB for Play).
See `docs/PLAY_STORE_CHECKLIST.md`.
