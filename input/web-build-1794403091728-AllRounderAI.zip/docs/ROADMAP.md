# Roadmap and how to extend

## Done
Multi-provider chat + fallback, local server, on-device Gemma, streaming, image attach, text/code file attach, web search,
Web builder (GitHub Pages), App builder (GitHub Actions APK), change requests, build auto-fix, project history + ZIP export,
code runner (GitHub Actions), chat rename/pin/per-chat instructions, voice input, chat search/share/report, app lock, encrypted keys.

## Ideas for later (full list in FEATURES.md)
- PDF attach (render pages to images for vision models)
- Run button directly on chat code blocks
- Cloud backup/export of chats

## How to add things
- **New AI provider**: add one `ProviderSpec(...)` line to `PROVIDERS` in `data/Llm.kt`. If it speaks the OpenAI chat format, nothing else is needed.
- **New provider API format**: add a `ProviderType`, then a branch in `buildRequest`, `parse` and `parseDelta` in `Llm.kt`.
- **New screen**: add a composable and a case in `AppRoot` (`MainActivity.kt`) plus a drawer item in `ChatScreen.kt`.
- **New builder target**: add a `BuildMode` and a system prompt in `BuilderViewModel.kt`.
- **New runner language**: add an entry to `Lang` (`RunnerViewModel.kt`) and a case in `app/src/main/assets/run.yml`.
