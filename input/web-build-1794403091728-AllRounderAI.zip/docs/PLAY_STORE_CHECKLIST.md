# Play Store checklist (AllRounder AI)

0. `support_email` and `privacy_url` are set in `app/src/main/res/values/strings.xml`. The privacy page goes live after you tap Settings > Privacy policy > Publish page once (needs your GitHub token). Use that same URL in Play Console.
1. **applicationId** - change `com.allrounder.ai` in `app/build.gradle.kts` (and `namespace` + package folders if you want them to match) to something unique to you. It can never be changed after publishing.
2. **Signing** - create an upload key once:
   `keytool -genkey -v -keystore upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload`
   then copy `keystore.properties.example` to `keystore.properties`. Back the keystore up safely.
3. **Upload format** - Play Console requires an **.aab** (`./gradlew bundleRelease`). The APK is for testing/sideloading.
4. **Target SDK** - already 36 (required for new apps/updates since 31 Aug 2026).
5. **Store assets** - in `store/`: `icon_512.png` and `feature_graphic_1024x500.png`. You still need 2-8 phone screenshots.
6. **Privacy policy URL** - mandatory (the app sends user messages to third-party AI APIs). Host one and enter it in Play Console.
7. **Data safety form** - declare: user messages sent to third-party AI providers chosen by the user; API keys stored on-device; no data collected by the developer.
8. **Content rating + target audience** - complete the questionnaires (AI chat apps must handle generated-content policy: add in-app reporting/flagging if you ship to a wider audience).
9. **Versioning** - increase `versionCode` for every upload.
