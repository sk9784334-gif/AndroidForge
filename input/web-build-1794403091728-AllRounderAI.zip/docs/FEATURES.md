# Features

**87 built (v2.2.0). Nothing left on the planned list.**

## Built

1. PDF attach (first 5 pages sent as images to vision models)
2. Several images per message
3. Run button on chat code blocks (Python, JavaScript, Shell, Java)
4. Backup all chats to a JSON file
5. Restore chats from a backup file
6. In-app privacy policy screen
7. One-tap publish of the privacy policy page to your GitHub Pages (URL for Play Console)
8. Regenerate the last reply
9. Edit and resend a message
10. Delete a single message
11. Message timestamps
12. Duplicate a chat
13. Clear a chat's messages
14. Theme choice: system / light / dark
15. Text size (S/M/L/XL)
16. Accent colour (5 choices)
17. Custom temperature setting
18. Reply-language preference (e.g. Hinglish)
19. Prompt library (saved prompts, sparkle button)
20. Model switcher in the top bar
21. Haptic feedback on send
22. Token estimate for long messages
23. Keep screen on while the AI is replying
24. Block-screenshots setting
25. Reset app (keys, settings, chats)
26. Web builder starter templates
27. App builder starter templates
28. Code runner hello-world templates
29. Copy Code runner output
30. Receive text from other apps via the Share sheet
31. Global search across chat titles and message text
32. Starred messages + Library screen
33. Read replies aloud (text-to-speech)
34. Scroll-to-bottom button
35. Export a chat as a Markdown file
36. Headings and bullet lists rendered in replies
37. Temporary (ghost) chat that is deleted when you leave
38. Plugin system: your own slash commands with templates and optional https lookups
39. Profile screen: name, avatar, personalisation instructions
40. Time-based greeting home screen with provider chip
41. Redesigned drawer: Images, Library, Projects, Terminal, Plugins, builders
42. Pill-style message bar with + attach menu
43. Terminal with 3 backends: this phone, Termux, GitHub cloud shell
44. AI terminal agent: say what you want in plain words, it picks the commands
45. Chat-to-terminal bridge: $ command in chat, Terminal button on shell code blocks, send output back to chat
46. Auto-run of safe commands with a risky-command guard (delete, sudo, chmod need a tap)
47. Model download from chat (/download link or AI download block) + Hugging Face token
48. Model import with progress, free-space check and error messages
49. Crash reporter with Diagnostics (copy / share the stack trace)
50. Images gallery of everything you attached
51. Projects hub for saved websites and apps
52. Attached images stored as files (prevents oversized database rows)
53. Auto-generate chat titles with AI
54. Export a chat as PDF
55. Response length presets (short / normal / detailed)
56. Token usage tracker (estimated)
57. Markdown tables
58. Syntax highlighting in code blocks
59. Share a reply as an image card
60. Home-screen app shortcuts (New chat, Terminal)
61. Web builder: multi-page sites and custom domain (CNAME)
62. Code runner: Go, Rust, C++
63. Code runner: stdin input
64. Auto-lock timeout setting
65. Camera capture attach
66. Passphrase-encrypted backups (AES-256-GCM)
67. Per-chat model choice
68. Ask another model (compare answers)
69. Code runner: run history
70. Quick-ask about what you copied (clipboard)
71. Folders / tags for chats with a filter in the drawer
72. Offline queue: failed requests retry automatically when the network returns
73. Quick Settings tile (Ask AI)
74. Home-screen widget (Ask AllRounder AI)
75. Math rendering: basic LaTeX to Unicode (fractions, roots, Greek, powers)
76. Web builder: AI-drawn inline SVG illustrations
77. App builder: AI-made adaptive launcher icon
78. App builder: signed APK + AAB in the build when you add 4 repo secrets
79. Hindi app language (main screens)
80. Tablet / foldable layout with a permanent drawer
81. Notification when a build finishes (while the app is alive)
82. Hands-free voice conversation mode (listen, answer, speak, repeat)
83. Scheduled prompts (daily or once) with a notification
84. Remote terminal over SSH to your own computer
85. Streaming for the on-device model (when the MediaPipe version supports it, otherwise normal reply)
86. Web builder: AI-generated photos via your OpenAI/Gemini key, placed into the site automatically
87. Privacy policy URL set (publish it once with Settings > Publish page)
