# AndroidForge compatibility

`scripts/setup_environment.py` in AndroidForge injects extra Maven repositories into every `repositories {}` block of
`settings.gradle.kts` / `build.gradle.kts`. With two blocks (pluginManagement + dependencyResolutionManagement) it uses stale
string offsets and corrupts the file (build error: `Expecting '"'`).

This project avoids it on purpose: both files contain the three marker strings (`mavenCentral()`, `maven.google.com`,
`jitpack.io`) in a comment, so the injector skips them. Do not remove those comment lines.
Also note: AndroidForge builds `assembleDebug` first. For the Play Store build a signed release **AAB** (`./gradlew bundleRelease`).
