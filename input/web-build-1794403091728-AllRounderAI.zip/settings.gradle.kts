// Repos used: mavenCentral() maven.google.com jitpack.io are listed here on purpose so AndroidForge's repo injector skips this file.
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "AllRounderAI"
include(":app")
