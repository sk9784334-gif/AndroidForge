package com.allrounder.ai.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

const val DEFAULT_SYSTEM = "You are an expert software engineer and helpful assistant. Help with any legitimate coding task: write, debug, refactor and explain code. Give complete, working code in fenced blocks, and keep explanations short."

data class Plugin(val name: String, val description: String, val template: String, val url: String, val enabled: Boolean)

val DEFAULT_PROMPTS = listOf(
    "Explain this code step by step",
    "Find bugs in this code and fix them",
    "Write unit tests for this",
    "Summarize this in 5 bullet points"
)

data class SettingsState(
    val keys: Map<String, String>,
    val models: Map<String, String>,
    val preferred: String,
    val systemPrompt: String,
    val fallback: Boolean,
    val githubToken: String = "",
    val appLock: Boolean = false,
    val urls: Map<String, String> = emptyMap(),
    val modelPath: String = "",
    val webSearch: Boolean = false,
    val tavilyKey: String = "",
    val theme: String = "system",
    val fontScale: Float = 1f,
    val accent: String = "violet",
    val temperature: Float = -1f,
    val replyLang: String = "",
    val blockShots: Boolean = false,
    val prompts: List<String> = DEFAULT_PROMPTS,
    val userName: String = "",
    val aboutMe: String = "",
    val termBackend: String = "device",
    val termAuto: Boolean = false,
    val terminalTool: Boolean = true,
    val hfToken: String = "",
    val plugins: List<Plugin> = emptyList(),
    val autoTitle: Boolean = true,
    val lengthPreset: String = "normal",
    val lockTimeout: Int = 30,
    val usage: Map<String, Long> = emptyMap(),
    val uiLang: String = "en",
    val sshHost: String = "",
    val sshPort: Int = 22,
    val sshUser: String = "",
    val sshPass: String = ""
) {
    val hasKey: Boolean get() = providerOrder().isNotEmpty()

    fun modelFor(spec: ProviderSpec): String =
        models[spec.id]?.takeIf { it.isNotBlank() } ?: spec.defaultModel

    fun providerOrder(): List<ProviderSpec> {
        val ready = PROVIDERS.filter {
            when {
                it.type == ProviderType.ONDEVICE -> modelPath.isNotBlank() && java.io.File(modelPath).exists()
                it.needsKey -> !keys[it.id].isNullOrBlank()
                else -> !urls[it.id].isNullOrBlank()
            }
        }
        val first = ready.firstOrNull { it.id == preferred }
        val rest = ready.filter { it !== first }
        return if (first != null) listOf(first) + rest else rest
    }
}

class SettingsRepo private constructor(context: Context) {
    companion object {
        @Volatile private var inst: SettingsRepo? = null
        fun get(c: Context): SettingsRepo = inst ?: synchronized(this) {
            inst ?: SettingsRepo(c.applicationContext).also { inst = it }
        }
    }

    private val prefs: SharedPreferences = open(context.applicationContext)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<SettingsState> = _state.asStateFlow()

    private fun open(ctx: Context): SharedPreferences {
        fun create(): SharedPreferences {
            val master = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            return EncryptedSharedPreferences.create(
                ctx, "secure_prefs", master,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }
        return try {
            create()
        } catch (e: Exception) {
            // Keystore got reset (e.g. restored device) - start clean instead of crashing.
            runCatching { ctx.deleteSharedPreferences("secure_prefs") }
            try { create() } catch (e2: Exception) { ctx.getSharedPreferences("fallback_prefs", Context.MODE_PRIVATE) }
        }
    }

    private fun load(): SettingsState = SettingsState(
        keys = PROVIDERS.associate { it.id to prefs.getString("key_${it.id}", "").orEmpty() },
        models = (PROVIDERS.map { it.id } + listOf("img_openai", "img_gemini")).associateWith { prefs.getString("model_$it", "").orEmpty() },
        preferred = prefs.getString("preferred", "gemini") ?: "gemini",
        systemPrompt = prefs.getString("system", DEFAULT_SYSTEM) ?: DEFAULT_SYSTEM,
        fallback = prefs.getBoolean("fallback", true),
        githubToken = prefs.getString("gh_token", "").orEmpty(),
        appLock = prefs.getBoolean("app_lock", false),
        urls = PROVIDERS.associate { it.id to prefs.getString("url_${it.id}", "").orEmpty() },
        modelPath = prefs.getString("model_path", "").orEmpty(),
        webSearch = prefs.getBoolean("web_search", false),
        tavilyKey = prefs.getString("tavily_key", "").orEmpty(),
        theme = prefs.getString("theme", "system") ?: "system",
        fontScale = prefs.getFloat("font_scale", 1f),
        accent = prefs.getString("accent", "violet") ?: "violet",
        temperature = prefs.getFloat("temperature", -1f),
        replyLang = prefs.getString("reply_lang", "").orEmpty(),
        blockShots = prefs.getBoolean("block_shots", false),
        prompts = loadPrompts(),
        userName = prefs.getString("user_name", "").orEmpty(),
        aboutMe = prefs.getString("about_me", "").orEmpty(),
        termBackend = prefs.getString("term_backend", "device") ?: "device",
        termAuto = prefs.getBoolean("term_auto", false),
        terminalTool = prefs.getBoolean("terminal_tool", true),
        hfToken = prefs.getString("hf_token", "").orEmpty(),
        plugins = loadPlugins(),
        autoTitle = prefs.getBoolean("auto_title", true),
        lengthPreset = prefs.getString("length_preset", "normal") ?: "normal",
        lockTimeout = prefs.getInt("lock_timeout", 30),
        usage = PROVIDERS.flatMap { listOf(it.id + ":in", it.id + ":out") }
            .associateWith { prefs.getLong("usage_" + it.replace(":", "_"), 0L) },
        uiLang = prefs.getString("ui_lang", "en") ?: "en",
        sshHost = prefs.getString("ssh_host", "").orEmpty(),
        sshPort = prefs.getInt("ssh_port", 22),
        sshUser = prefs.getString("ssh_user", "").orEmpty(),
        sshPass = prefs.getString("ssh_pass", "").orEmpty()
    )

    private fun loadPlugins(): List<Plugin> {
        val raw = prefs.getString("plugins", null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Plugin(o.getString("name"), o.optString("description"), o.optString("template"), o.optString("url"), o.optBoolean("enabled", true))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun loadPrompts(): List<String> {
        val raw = prefs.getString("prompts", null) ?: return DEFAULT_PROMPTS
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { a.getString(it) }
        } catch (e: Exception) {
            DEFAULT_PROMPTS
        }
    }

    fun setKey(id: String, value: String) {
        val v = value.trim()
        prefs.edit().putString("key_$id", v).apply()
        _state.update { it.copy(keys = it.keys + (id to v)) }
    }

    fun setModel(id: String, value: String) {
        val v = value.trim()
        prefs.edit().putString("model_$id", v).apply()
        _state.update { it.copy(models = it.models + (id to v)) }
    }

    fun setPreferred(id: String) {
        prefs.edit().putString("preferred", id).apply()
        _state.update { it.copy(preferred = id) }
    }

    fun setSystemPrompt(value: String) {
        prefs.edit().putString("system", value).apply()
        _state.update { it.copy(systemPrompt = value) }
    }

    fun setGithubToken(value: String) {
        val v = value.trim()
        prefs.edit().putString("gh_token", v).apply()
        _state.update { it.copy(githubToken = v) }
    }

    fun setAppLock(value: Boolean) {
        prefs.edit().putBoolean("app_lock", value).apply()
        _state.update { it.copy(appLock = value) }
    }

    fun setUrl(id: String, value: String) {
        val v = value.trim()
        prefs.edit().putString("url_$id", v).apply()
        _state.update { it.copy(urls = it.urls + (id to v)) }
    }

    fun setModelPath(value: String) {
        prefs.edit().putString("model_path", value).apply()
        _state.update { it.copy(modelPath = value) }
    }

    fun setWebSearch(value: Boolean) {
        prefs.edit().putBoolean("web_search", value).apply()
        _state.update { it.copy(webSearch = value) }
    }

    fun setTavilyKey(value: String) {
        val v = value.trim()
        prefs.edit().putString("tavily_key", v).apply()
        _state.update { it.copy(tavilyKey = v) }
    }

    fun setTheme(v: String) { prefs.edit().putString("theme", v).apply(); _state.update { it.copy(theme = v) } }
    fun setFontScale(v: Float) { prefs.edit().putFloat("font_scale", v).apply(); _state.update { it.copy(fontScale = v) } }
    fun setAccent(v: String) { prefs.edit().putString("accent", v).apply(); _state.update { it.copy(accent = v) } }
    fun setTemperature(v: Float) { prefs.edit().putFloat("temperature", v).apply(); _state.update { it.copy(temperature = v) } }
    fun setReplyLang(v: String) { prefs.edit().putString("reply_lang", v.trim()).apply(); _state.update { it.copy(replyLang = v.trim()) } }
    fun setBlockShots(v: Boolean) { prefs.edit().putBoolean("block_shots", v).apply(); _state.update { it.copy(blockShots = v) } }
    fun setPrompts(list: List<String>) {
        prefs.edit().putString("prompts", JSONArray(list).toString()).apply()
        _state.update { it.copy(prompts = list) }
    }

    fun setUserName(v: String) { prefs.edit().putString("user_name", v.trim()).apply(); _state.update { it.copy(userName = v.trim()) } }
    fun setAboutMe(v: String) { prefs.edit().putString("about_me", v).apply(); _state.update { it.copy(aboutMe = v) } }
    fun setTermBackend(v: String) { prefs.edit().putString("term_backend", v).apply(); _state.update { it.copy(termBackend = v) } }
    fun setTermAuto(v: Boolean) { prefs.edit().putBoolean("term_auto", v).apply(); _state.update { it.copy(termAuto = v) } }
    fun setTerminalTool(v: Boolean) { prefs.edit().putBoolean("terminal_tool", v).apply(); _state.update { it.copy(terminalTool = v) } }
    fun setHfToken(v: String) { prefs.edit().putString("hf_token", v.trim()).apply(); _state.update { it.copy(hfToken = v.trim()) } }
    fun setPlugins(list: List<Plugin>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("name", it.name).put("description", it.description)
                .put("template", it.template).put("url", it.url).put("enabled", it.enabled))
        }
        prefs.edit().putString("plugins", a.toString()).apply()
        _state.update { it.copy(plugins = list) }
    }

    fun setAutoTitle(v: Boolean) { prefs.edit().putBoolean("auto_title", v).apply(); _state.update { it.copy(autoTitle = v) } }
    fun setLengthPreset(v: String) { prefs.edit().putString("length_preset", v).apply(); _state.update { it.copy(lengthPreset = v) } }
    fun setLockTimeout(v: Int) { prefs.edit().putInt("lock_timeout", v).apply(); _state.update { it.copy(lockTimeout = v) } }

    /** Rough token estimates (characters / 4) so you can see how much each provider is used. */
    fun addUsage(id: String, tokensIn: Int, tokensOut: Int) {
        val kin = "$id:in"
        val kout = "$id:out"
        val u = _state.value.usage
        val nin = (u[kin] ?: 0L) + tokensIn
        val nout = (u[kout] ?: 0L) + tokensOut
        prefs.edit().putLong("usage_" + id + "_in", nin).putLong("usage_" + id + "_out", nout).apply()
        _state.update { it.copy(usage = it.usage + (kin to nin) + (kout to nout)) }
    }

    fun setUiLang(v: String) { prefs.edit().putString("ui_lang", v).apply(); _state.update { it.copy(uiLang = v) } }

    fun setSsh(host: String, port: Int, user: String, pass: String) {
        prefs.edit().putString("ssh_host", host.trim()).putInt("ssh_port", port).putString("ssh_user", user.trim()).putString("ssh_pass", pass).apply()
        _state.update { it.copy(sshHost = host.trim(), sshPort = port, sshUser = user.trim(), sshPass = pass) }
    }

    fun hostKey(id: String): String? = prefs.getString("hk_$id", null)
    fun setHostKey(id: String, fp: String) { prefs.edit().putString("hk_$id", fp).apply() }

    fun resetAll() {
        prefs.edit().clear().apply()
        _state.value = load()
    }

    fun setFallback(value: Boolean) {
        prefs.edit().putBoolean("fallback", value).apply()
        _state.update { it.copy(fallback = value) }
    }
}
