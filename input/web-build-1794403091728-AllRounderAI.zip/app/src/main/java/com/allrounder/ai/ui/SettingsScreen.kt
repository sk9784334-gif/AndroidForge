@file:OptIn(ExperimentalMaterial3Api::class)

package com.allrounder.ai.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import com.allrounder.ai.data.ProviderType
import android.content.Intent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.biometric.BiometricManager
import com.allrounder.ai.LOCK_AUTH
import com.allrounder.ai.R
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.allrounder.ai.ChatViewModel
import com.allrounder.ai.data.PROVIDERS
import com.allrounder.ai.data.ProviderSpec
import com.allrounder.ai.data.SettingsState

@Composable
fun SettingsScreen(vm: ChatViewModel, onBack: () -> Unit, onOpenPrivacy: () -> Unit) {
    val st by vm.settings.state.collectAsState()
    var confirmDelete by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0.0"
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(tr("Settings")) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(tr("AI providers"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Add a key for any provider. The primary one is used first; the others are automatic backups.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            items(PROVIDERS.filter { it.type != ProviderType.ONDEVICE }, key = { it.id }) { spec -> ProviderCard(spec, st, vm) }
            item { OnDeviceCard(st, vm) }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Auto fallback", fontWeight = FontWeight.SemiBold)
                            Text(
                                "Try the next provider if one fails or hits a limit.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(checked = st.fallback, onCheckedChange = { vm.settings.setFallback(it) })
                    }
                }
            }
            item {
                var token by remember { mutableStateOf(st.githubToken) }
                var showTok by remember { mutableStateOf(false) }
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("GitHub hosting", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Needed to publish websites (GitHub Pages) and build APKs (GitHub Actions). Create a classic token " +
                                "with only the repo and workflow scopes. It is sent only to api.github.com. Revoke it any time.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = token,
                            onValueChange = { token = it; vm.settings.setGithubToken(it) },
                            label = { Text("GitHub token") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            visualTransformation = if (showTok) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            trailingIcon = { TextButton(onClick = { showTok = !showTok }) { Text(if (showTok) "Hide" else "Show") } }
                        )
                    }
                }
            }
            item {
                var prompt by remember { mutableStateOf(st.systemPrompt) }
                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it; vm.settings.setSystemPrompt(it) },
                    label = { Text("System prompt") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    maxLines = 6
                )
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Privacy", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "API keys are stored encrypted on this device. Your messages are sent directly " +
                                "from your phone to the provider you choose - there is no AllRounder server in between. " +
                                "Chats are saved only on this device.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            item { AppearanceCard(st, vm) }
            item { GenerationCard(st, vm) }
            item { ImageModelsCard(st, vm) }
            item { PromptsCard(st, vm) }
            item { BackupCard(vm) }
            item { PrivacyCard(vm, onOpenPrivacy) }
            item {
                var tk by remember { mutableStateOf(st.tavilyKey) }
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Web search", fontWeight = FontWeight.SemiBold)
                                Text(
                                    "Adds fresh web results to your questions. Your question text is sent to Tavily (needs a Tavily API key).",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(checked = st.webSearch, onCheckedChange = { vm.settings.setWebSearch(it) })
                        }
                        OutlinedTextField(
                            value = tk,
                            onValueChange = { tk = it; vm.settings.setTavilyKey(it) },
                            label = { Text("Tavily API key") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                        )
                    }
                }
            }
            item {
                var lockMsg by remember { mutableStateOf("") }
                val uri = LocalUriHandler.current
                val policy = ctx.getString(R.string.privacy_url)
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("App lock", fontWeight = FontWeight.SemiBold)
                                Text(
                                    "Ask for fingerprint, face or screen lock to open the app. Also hides it in recent apps and blocks screenshots.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(checked = st.appLock, onCheckedChange = { on ->
                                if (!on) { vm.settings.setAppLock(false); lockMsg = "" }
                                else if (BiometricManager.from(ctx).canAuthenticate(LOCK_AUTH) == BiometricManager.BIOMETRIC_SUCCESS) {
                                    vm.settings.setAppLock(true); lockMsg = ""
                                } else lockMsg = "Set a screen lock or fingerprint on your phone first."
                            })
                        }
                        if (lockMsg.isNotEmpty()) Text(lockMsg, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        if (!policy.contains("CHANGE_ME")) TextButton(onClick = { uri.openUri(policy) }) { Text(tr("Privacy policy")) }
                    }
                }
            }
            item { ResetCard(vm) }
            item {
                OutlinedButton(
                    onClick = { confirmDelete = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) { Text(tr("Delete all chats")) }
            }
            item {
                Text(
                    "AllRounder AI  v$version",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete all chats?") },
            text = { Text("This permanently removes every conversation from this device.") },
            confirmButton = {
                TextButton(onClick = { vm.deleteAll(); confirmDelete = false }) { Text(tr("Delete")) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(tr("Cancel")) } }
        )
    }
}

@Composable
private fun ProviderCard(spec: ProviderSpec, st: SettingsState, vm: ChatViewModel) {
    var key by remember(spec.id) { mutableStateOf(st.keys[spec.id].orEmpty()) }
    var url by remember(spec.id) { mutableStateOf(st.urls[spec.id].orEmpty()) }
    var model by remember(spec.id) { mutableStateOf(st.models[spec.id]?.takeIf { it.isNotBlank() } ?: spec.defaultModel) }
    var show by remember { mutableStateOf(false) }
    val isPrimary = st.preferred == spec.id
    val active = if (spec.needsKey) key.isNotBlank() else url.isNotBlank()

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    spec.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                if (active) {
                    FilterChip(
                        selected = isPrimary,
                        onClick = { vm.settings.setPreferred(spec.id) },
                        label = { Text(if (isPrimary) "Primary" else "Make primary") }
                    )
                }
            }
            run {
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it; vm.settings.setKey(spec.id, it) },
                    label = { Text(if (spec.needsKey) "API key" else "API key (optional)") },
                    placeholder = { Text(spec.keyHint) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = { TextButton(onClick = { show = !show }) { Text(if (show) "Hide" else "Show") } }
                )
            }
            if (!spec.needsKey) {
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it; vm.settings.setUrl(spec.id, it) },
                    label = { Text("Server URL (empty = off)") },
                    placeholder = { Text(spec.baseUrl) },
                    supportingText = { Text("Any OpenAI-compatible server. Plain http works only for 127.0.0.1 / localhost (e.g. Ollama in Termux); other hosts need https.") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            OutlinedTextField(
                value = model,
                onValueChange = { model = it; vm.settings.setModel(spec.id, it) },
                label = { Text("Model") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun OnDeviceCard(st: SettingsState, vm: ChatViewModel) {
    val importStatus by vm.modelStatus.collectAsState()
    val dlStatus by vm.downloadStatus.collectAsState()
    var url by remember { mutableStateOf("") }
    var hf by remember { mutableStateOf(st.hfToken) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importModel(uri)
    }
    val has = st.modelPath.isNotBlank()
    val importing = importStatus.startsWith("Importing")
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "On-device model (offline)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                if (has) FilterChip(
                    selected = st.preferred == "ondevice",
                    onClick = { vm.settings.setPreferred("ondevice") },
                    label = { Text(if (st.preferred == "ondevice") "Primary" else "Make primary") }
                )
            }
            Text(
                "Runs on your phone with no internet. Use a MediaPipe-compatible .task model (Gemma family). " +
                    "Import a file you already downloaded, or paste a direct https link (you can also say /download <link> in chat).",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !importing) {
                    Text(if (has) "Replace model" else "Import model file")
                }
                if (has) TextButton(onClick = { File(st.modelPath).delete(); vm.settings.setModelPath("") }, enabled = !importing) {
                    Text(tr("Remove"))
                }
            }
            if (importStatus.isNotEmpty()) Text(importStatus, style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(
                value = url, onValueChange = { url = it },
                label = { Text("Model download link (https)") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = hf, onValueChange = { hf = it; vm.settings.setHfToken(it) },
                label = { Text("Hugging Face token (only for gated models)") },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
            )
            Button(onClick = { vm.startDownload(url) }, enabled = url.isNotBlank()) { Text("Download model") }
            if (dlStatus.isNotEmpty()) Text(dlStatus, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
internal fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(tr(title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
internal fun AppearanceCard(st: SettingsState, vm: ChatViewModel) = SettingsCard("Appearance") {
    Text("Theme", style = MaterialTheme.typography.labelLarge)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("system" to "System", "light" to "Light", "dark" to "Dark").forEach { (k, l) ->
            FilterChip(selected = st.theme == k, onClick = { vm.settings.setTheme(k) }, label = { Text(l) })
        }
    }
    Text("Text size", style = MaterialTheme.typography.labelLarge)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(0.85f to "S", 1f to "M", 1.15f to "L", 1.3f to "XL").forEach { (v, l) ->
            FilterChip(selected = st.fontScale == v, onClick = { vm.settings.setFontScale(v) }, label = { Text(l) })
        }
    }
    Text("Accent colour", style = MaterialTheme.typography.labelLarge)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("violet", "cyan", "green", "orange", "pink").forEach { a ->
            FilterChip(
                selected = st.accent == a,
                onClick = { vm.settings.setAccent(a) },
                label = { Text(a.replaceFirstChar { it.uppercase() }) }
            )
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Block screenshots", fontWeight = FontWeight.SemiBold)
            Text(
                "Hides the app in recent apps and blocks screen capture.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = st.blockShots, onCheckedChange = { vm.settings.setBlockShots(it) })
    }
}

@Composable
private fun GenerationCard(st: SettingsState, vm: ChatViewModel) = SettingsCard("Replies") {
    var lang by remember { mutableStateOf(st.replyLang) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Custom creativity (temperature)", fontWeight = FontWeight.SemiBold)
            Text(
                "Off = each provider's default. Some newer models only accept their default.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(
            checked = st.temperature >= 0f,
            onCheckedChange = { vm.settings.setTemperature(if (it) 0.7f else -1f) }
        )
    }
    if (st.temperature >= 0f) {
        Slider(value = st.temperature, onValueChange = { vm.settings.setTemperature(it) }, valueRange = 0f..1.5f)
        Text(String.format("%.2f", st.temperature), style = MaterialTheme.typography.bodySmall)
    }
    Text("Answer length", style = MaterialTheme.typography.labelLarge)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("short" to "Short", "normal" to "Normal", "detailed" to "Detailed").forEach { (k, l) ->
            FilterChip(selected = st.lengthPreset == k, onClick = { vm.settings.setLengthPreset(k) }, label = { Text(l) })
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Auto-name new chats with AI", Modifier.weight(1f))
        Switch(checked = st.autoTitle, onCheckedChange = { vm.settings.setAutoTitle(it) })
    }
    OutlinedTextField(
        value = lang,
        onValueChange = { lang = it; vm.settings.setReplyLang(it) },
        label = { Text("Reply language (e.g. Hinglish, Hindi, English)") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun PromptsCard(st: SettingsState, vm: ChatViewModel) = SettingsCard("Prompt library") {
    var newP by remember { mutableStateOf("") }
    Text(
        "Saved prompts show up under the sparkle button in the message box.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    st.prompts.forEachIndexed { i, p ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(p, Modifier.weight(1f), maxLines = 2)
            TextButton(onClick = { vm.settings.setPrompts(st.prompts.filterIndexed { j, _ -> j != i }) }) { Text(tr("Delete")) }
        }
    }
    OutlinedTextField(
        value = newP, onValueChange = { newP = it },
        label = { Text("New prompt") }, modifier = Modifier.fillMaxWidth()
    )
    Button(onClick = {
        if (newP.isNotBlank()) { vm.settings.setPrompts(st.prompts + newP.trim()); newP = "" }
    }) { Text("Add prompt") }
}

@Composable
private fun BackupCard(vm: ChatViewModel) = SettingsCard("Backup") {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            msg = try { "Restored " + vm.importBackup(uri, pass) + " chats" } catch (e: Exception) { "Restore failed: wrong passphrase or not a valid backup file" }
        }
    }
    Text(
        "Exports chat text only (no images, keys or tokens) as a plain JSON file. Keep it private.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    OutlinedTextField(
        value = pass, onValueChange = { pass = it },
        label = { Text("Passphrase (optional, encrypts the backup)") },
        singleLine = true, modifier = Modifier.fillMaxWidth(),
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = {
            scope.launch {
                try {
                    val u = vm.exportBackup(pass)
                    val send = Intent(Intent.ACTION_SEND).setType(if (pass.isBlank()) "application/json" else "application/octet-stream")
                        .putExtra(Intent.EXTRA_STREAM, u)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    ctx.startActivity(Intent.createChooser(send, "Save backup"))
                } catch (e: Exception) {
                    msg = "Export failed"
                }
            }
        }) { Text("Export chats") }
        OutlinedButton(onClick = { picker.launch(arrayOf("application/json", "*/*")) }) { Text("Restore") }
    }
    if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall)
}

@Composable
private fun PrivacyCard(vm: ChatViewModel, onOpenPrivacy: () -> Unit) = SettingsCard("Privacy policy") {
    val status by vm.policyStatus.collectAsState()
    Text(
        "Read the policy built into this app. Play Console also needs a public URL: Publish page puts the same policy " +
            "on your own GitHub Pages (needs the GitHub token above).",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = onOpenPrivacy) { Text("Read policy") }
        OutlinedButton(onClick = { vm.publishPolicy() }) { Text("Publish page") }
    }
    if (status.isNotEmpty()) SelectionContainer { Text(status, style = MaterialTheme.typography.bodySmall) }
}

@Composable
private fun ResetCard(vm: ChatViewModel) {
    var confirm by remember { mutableStateOf(false) }
    OutlinedButton(
        onClick = { confirm = true },
        modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
    ) { Text("Reset app (keys, settings, chats)") }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Reset everything?") },
        text = { Text("Deletes all chats, API keys, tokens and settings on this device. This cannot be undone.") },
        confirmButton = {
            TextButton(onClick = { vm.settings.resetAll(); vm.deleteAll(); confirm = false }) { Text("Reset") }
        },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text(tr("Cancel")) } }
    )
}

@Composable
private fun ImageModelsCard(st: SettingsState, vm: ChatViewModel) = SettingsCard("AI images (Web builder)") {
    var openai by remember { mutableStateOf(st.models["img_openai"].orEmpty()) }
    var gemini by remember { mutableStateOf(st.models["img_gemini"].orEmpty()) }
    Text(
        "Uses your OpenAI key if present, otherwise your Gemini key. Billed by the provider; some image models need a paid plan. " +
            "Leave empty for the defaults (gpt-image-1 / gemini-2.5-flash-image).",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    OutlinedTextField(
        value = openai, onValueChange = { openai = it; vm.settings.setModel("img_openai", it) },
        label = { Text("OpenAI image model") }, singleLine = true, modifier = Modifier.fillMaxWidth()
    )
    OutlinedTextField(
        value = gemini, onValueChange = { gemini = it; vm.settings.setModel("img_gemini", it) },
        label = { Text("Gemini image model") }, singleLine = true, modifier = Modifier.fillMaxWidth()
    )
}
