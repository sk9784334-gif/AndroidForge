package com.allrounder.ai.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import com.allrounder.ai.R
import com.allrounder.ai.Lang
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.Composable

@Composable
fun LogoMark(size: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.28f))
            .background(Brush.linearGradient(listOf(BrandViolet, BrandCyan))),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(R.drawable.ic_logo_mark),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(0.62f)
        )
    }
}

/** Lets a code block in a chat open the Code runner pre-filled. Provided in MainActivity. */
val LocalOpenRunner = staticCompositionLocalOf<(Lang, String) -> Unit> { { _, _ -> } }

fun langFor(tag: String): Lang? = when (tag) {
    "python", "py", "python3" -> Lang.PYTHON
    "javascript", "js", "node" -> Lang.JS
    "bash", "sh", "shell" -> Lang.SHELL
    "java" -> Lang.JAVA
    "go", "golang" -> Lang.GO
    "rust", "rs" -> Lang.RUST
    "cpp", "c++" -> Lang.CPP
    else -> null
}

/** Chat code blocks can open the Terminal with commands pre-filled, or start a model download. */
val LocalOpenTerminal = staticCompositionLocalOf<(String) -> Unit> { { } }
val LocalDownload = staticCompositionLocalOf<(String) -> Unit> { { } }

/** True when the app language is Hindi. Provided in MainActivity. */
val LocalUiHi = staticCompositionLocalOf { false }

private val HI_TEXT: Map<String, String> = mapOf(
    "Images" to "चित्र",
    "Library" to "लाइब्रेरी",
    "Projects" to "प्रोजेक्ट",
    "Terminal" to "टर्मिनल",
    "Plugins" to "प्लगइन",
    "Web builder" to "वेब बिल्डर",
    "App builder" to "ऐप बिल्डर",
    "Code runner" to "कोड रनर",
    "Scheduled" to "शेड्यूल",
    "Chat" to "चैट",
    "Search" to "खोजें",
    "Settings" to "सेटिंग्स",
    "Profile" to "प्रोफ़ाइल",
    "No chats yet" to "अभी कोई चैट नहीं",
    "Copy" to "कॉपी करें",
    "Edit and resend" to "बदलकर दोबारा भेजें",
    "Regenerate" to "दोबारा बनाएँ",
    "Report" to "रिपोर्ट करें",
    "Delete" to "हटाएँ",
    "Share as image" to "इमेज की तरह शेयर करें",
    "Read aloud" to "पढ़कर सुनाएँ",
    "Ask another model" to "दूसरे मॉडल से पूछें",
    "Pin" to "पिन करें",
    "Unpin" to "पिन हटाएँ",
    "Rename" to "नाम बदलें",
    "Chat instructions" to "चैट निर्देश",
    "Model for this chat" to "इस चैट का मॉडल",
    "Folder / tag" to "फ़ोल्डर / टैग",
    "Duplicate" to "डुप्लिकेट",
    "Clear messages" to "संदेश साफ़ करें",
    "Share chat" to "चैट शेयर करें",
    "Export as PDF" to "PDF में एक्सपोर्ट करें",
    "Export as Markdown" to "Markdown में एक्सपोर्ट करें",
    "Camera" to "कैमरा",
    "Photo" to "फ़ोटो",
    "File or PDF" to "फ़ाइल या PDF",
    "Prompt library" to "प्रॉम्प्ट लाइब्रेरी",
    "Cancel" to "रद्द करें",
    "Save" to "सेव करें",
    "Close" to "बंद करें",
    "Retry" to "दोबारा कोशिश करें",
    "Dismiss" to "बंद करें",
    "Remove" to "हटाएँ",
    "All" to "सभी",
    "Star (save to Library)" to "स्टार करें (लाइब्रेरी में सेव)",
    "Remove star" to "स्टार हटाएँ",
    "Send output to chat" to "आउटपुट चैट में भेजें",
    "Clear" to "साफ़ करें",
    "Run" to "चलाएँ",
    "Your name" to "आपका नाम",
    "Add plugin" to "प्लगइन जोड़ें",
    "Built-in" to "बिल्ट-इन",
    "Privacy policy" to "गोपनीयता नीति",
    "Delete all chats" to "सभी चैट हटाएँ",
    "Shortcuts" to "शॉर्टकट",
    "AI providers" to "AI प्रदाता",
    "Diagnostics" to "डायग्नोस्टिक्स",
    "Appearance" to "दिखावट",
    "Backup" to "बैकअप",
    "Replies" to "जवाब",
    "Language" to "भाषा",
    "App lock delay" to "ऐप लॉक देरी",
    "Usage (estimated tokens)" to "उपयोग (अनुमानित टोकन)",
    "Recent runs" to "हाल के रन",
    "Output" to "आउटपुट",
    "Message, or \$ command" to "संदेश लिखें, या \$ कमांड",
    "AI can make mistakes. Check important information." to "AI से गलतियाँ हो सकती हैं। ज़रूरी जानकारी ज़रूर जाँच लें।"
)

/** Translates a UI label when Hindi is selected (main screens only); falls back to English. */
@Composable
fun tr(s: String): String = if (LocalUiHi.current) HI_TEXT[s] ?: s else s

private val SUP = mapOf(
    '0' to '\u2070', '1' to '\u00B9', '2' to '\u00B2', '3' to '\u00B3', '4' to '\u2074', '5' to '\u2075', '6' to '\u2076',
    '7' to '\u2077', '8' to '\u2078', '9' to '\u2079', '+' to '\u207A', '-' to '\u207B', '=' to '\u207C', '(' to '\u207D',
    ')' to '\u207E', 'n' to '\u207F', 'i' to '\u2071'
)
private val SUB = mapOf(
    '0' to '\u2080', '1' to '\u2081', '2' to '\u2082', '3' to '\u2083', '4' to '\u2084', '5' to '\u2085', '6' to '\u2086',
    '7' to '\u2087', '8' to '\u2088', '9' to '\u2089', '+' to '\u208A', '-' to '\u208B', '=' to '\u208C', '(' to '\u208D',
    ')' to '\u208E'
)
private val TEX = listOf(
    "\\alpha" to "\u03B1", "\\beta" to "\u03B2", "\\gamma" to "\u03B3", "\\delta" to "\u03B4", "\\epsilon" to "\u03B5",
    "\\theta" to "\u03B8", "\\lambda" to "\u03BB", "\\mu" to "\u03BC", "\\pi" to "\u03C0", "\\sigma" to "\u03C3",
    "\\phi" to "\u03C6", "\\omega" to "\u03C9", "\\Delta" to "\u0394", "\\Sigma" to "\u03A3", "\\Omega" to "\u03A9",
    "\\times" to "\u00D7", "\\cdot" to "\u00B7", "\\div" to "\u00F7", "\\pm" to "\u00B1", "\\leq" to "\u2264",
    "\\geq" to "\u2265", "\\neq" to "\u2260", "\\approx" to "\u2248", "\\infty" to "\u221E", "\\rightarrow" to "\u2192",
    "\\to" to "\u2192", "\\sum" to "\u03A3", "\\int" to "\u222B", "\\partial" to "\u2202", "\\nabla" to "\u2207",
    "\\le" to "\u2264", "\\ge" to "\u2265", "\\ldots" to "\u2026"
)

fun looksMath(s: String): Boolean = s.contains('\\') || s.contains('^') || s.contains('_')

/** Basic LaTeX to Unicode (fractions, roots, Greek letters, super/subscripts, common symbols). */
fun texToUnicode(src: String): String {
    var s = src
    val frac = Regex("\\\\frac\\{([^{}]*)\\}\\{([^{}]*)\\}")
    repeat(3) { s = frac.replace(s) { m -> "(" + m.groupValues[1] + ")/(" + m.groupValues[2] + ")" } }
    s = Regex("\\\\sqrt\\{([^{}]*)\\}").replace(s) { m -> "\u221A(" + m.groupValues[1] + ")" }
    s = s.replace("\\left", "").replace("\\right", "")
    TEX.forEach { (k, v) -> s = s.replace(k, v) }
    s = Regex("\\^\\{([^{}]*)\\}").replace(s) { m -> m.groupValues[1].map { SUP[it] ?: it }.joinToString("") }
    s = Regex("\\^([0-9a-zA-Z+-])").replace(s) { m -> (SUP[m.groupValues[1][0]] ?: m.groupValues[1][0]).toString() }
    s = Regex("_\\{([^{}]*)\\}").replace(s) { m -> m.groupValues[1].map { SUB[it] ?: it }.joinToString("") }
    s = Regex("_([0-9+-])").replace(s) { m -> (SUB[m.groupValues[1][0]] ?: m.groupValues[1][0]).toString() }
    return s.replace("{", "").replace("}", "").replace("\\", "")
}
