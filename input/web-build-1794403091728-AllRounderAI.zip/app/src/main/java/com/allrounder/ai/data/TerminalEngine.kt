
package com.allrounder.ai.data

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.app.PendingIntent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class Backend(val id: String, val label: String) {
    DEVICE("device", "This phone"),
    TERMUX("termux", "Termux"),
    CLOUD("cloud", "GitHub cloud"),
    SSH("ssh", "Remote (SSH)");

    companion object {
        fun from(id: String): Backend = values().firstOrNull { it.id == id } ?: DEVICE
    }
}

data class ExecResult(val output: String, val cwd: String?)
class TerminalException(message: String) : Exception(message)

object TerminalEngine {
    const val TERMUX_PERMISSION = "com.termux.permission.RUN_COMMAND"

    private val RISKY = Regex("""(^|[;&|`(]|\s)(rm|mv|dd|mkfs\S*|shutdown|reboot|chmod|chown|kill|pkill|sudo|format)(\s|\z)|\|\s*(sh|bash)\b|>\s*/""")

    /** Commands that must never run without an explicit tap, even in auto-run mode. */
    fun isRisky(cmd: String): Boolean = RISKY.containsMatchIn(cmd)

    fun describe(b: Backend): String = when (b) {
        Backend.DEVICE -> "Android app sandbox shell (toybox: ls, cat, echo, mkdir, cp, grep, sed, ping...). No package manager, no python, no root, no apt/pip. The working directory persists between commands."
        Backend.TERMUX -> "Termux full Linux userland on Android (bash, pkg/apt, python, pip, git, curl, node...). Install packages with pkg install -y <name>. Each command runs in a fresh login shell in the Termux home directory."
        Backend.SSH -> "A remote Linux/macOS computer or server reached over SSH (the user's own machine). Whatever tools are installed there; each command runs in a fresh session in the home directory."
        Backend.CLOUD -> "Ephemeral Ubuntu GitHub Actions runner with internet, sudo, apt, python3, pip, node, java, git, curl. Nothing persists after a command. 5 minute limit, so chain everything needed into one script."
    }

    suspend fun exec(ctx: Context, backend: Backend, cmd: String, cwd: String?, token: String): ExecResult =
        when (backend) {
            Backend.DEVICE -> device(ctx, cmd, cwd)
            Backend.TERMUX -> ExecResult(termux(ctx, cmd), null)
            Backend.SSH -> ExecResult(Ssh.exec(ctx, cmd), null)
            Backend.CLOUD -> {
                if (token.isBlank()) throw TerminalException("Add your GitHub token in Settings to use the cloud shell.")
                ExecResult(CloudRunner.run(ctx, token, "main.sh", cmd) {}, null)
            }
        }

    private suspend fun device(ctx: Context, cmd: String, cwd: String?): ExecResult = withContext(Dispatchers.IO) {
        val home = File(ctx.filesDir, "home").apply { mkdirs() }
        val dir = cwd?.let { File(it) }?.takeIf { it.isDirectory } ?: home
        val pb = ProcessBuilder("sh", "-c", cmd + "\necho\necho __AF_CWD__\$(pwd)")
            .directory(dir).redirectErrorStream(true)
        pb.environment()["HOME"] = home.path
        val p = pb.start()
        val sb = StringBuilder()
        val reader = thread {
            try {
                p.inputStream.bufferedReader().use { r ->
                    val buf = CharArray(4096)
                    while (true) {
                        val n = r.read(buf)
                        if (n < 0) break
                        synchronized(sb) { if (sb.length < 20000) sb.append(buf, 0, n) }
                    }
                }
            } catch (e: Exception) { /* process ended */ }
        }
        val finished = p.waitFor(60, TimeUnit.SECONDS)
        if (!finished) p.destroyForcibly()
        reader.join(1500)
        var text = synchronized(sb) { sb.toString() }
        var newCwd: String? = null
        val idx = text.lastIndexOf("__AF_CWD__")
        if (idx >= 0) {
            newCwd = text.substring(idx + 10).trim().lines().firstOrNull()
            text = text.substring(0, idx).trimEnd()
        }
        if (!finished) text += "\n[stopped after 60 seconds]"
        ExecResult(text.trim(), newCwd)
    }

    private suspend fun termux(ctx: Context, cmd: String): String {
        try {
            ctx.packageManager.getPackageInfo("com.termux", 0)
        } catch (e: Exception) {
            throw TerminalException("Termux is not installed. Install it from F-Droid.")
        }
        if (ContextCompat.checkSelfPermission(ctx, TERMUX_PERMISSION) != PackageManager.PERMISSION_GRANTED) {
            throw TerminalException("Permission needed: tap Grant in the Terminal screen (Run commands in Termux).")
        }
        val result = withTimeoutOrNull(180_000) {
            suspendCancellableCoroutine<String> { cont ->
                val action = "com.allrounder.ai.TERMUX_RESULT." + UUID.randomUUID()
                val receiver = object : BroadcastReceiver() {
                    override fun onReceive(c: Context, i: Intent) {
                        runCatching { ctx.unregisterReceiver(this) }
                        val b = i.getBundleExtra("result")
                        val out = b?.getString("stdout").orEmpty()
                        val err = b?.getString("stderr").orEmpty()
                        val errMsg = b?.getString("errmsg").orEmpty()
                        val code = b?.getInt("exitCode", -1) ?: -1
                        val text = buildString {
                            append(out)
                            if (err.isNotBlank()) append("\n").append(err)
                            if (errMsg.isNotBlank()) append("\n").append(errMsg)
                            if (code != 0 && code != -1) append("\n[exit code ").append(code).append("]")
                        }
                        if (cont.isActive) cont.resume(text.trim())
                    }
                }
                ContextCompat.registerReceiver(ctx, receiver, IntentFilter(action), ContextCompat.RECEIVER_NOT_EXPORTED)
                cont.invokeOnCancellation { runCatching { ctx.unregisterReceiver(receiver) } }
                val pi = PendingIntent.getBroadcast(
                    ctx, action.hashCode(), Intent(action).setPackage(ctx.packageName),
                    PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                val svc = Intent().setClassName("com.termux", "com.termux.app.RunCommandService")
                    .setAction("com.termux.RUN_COMMAND")
                    .putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
                    .putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-lc", cmd))
                    .putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home")
                    .putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
                    .putExtra("com.termux.RUN_COMMAND_PENDING_INTENT", pi)
                try {
                    ctx.startService(svc)
                } catch (e: Exception) {
                    runCatching { ctx.unregisterReceiver(receiver) }
                    if (cont.isActive) cont.resumeWithException(TerminalException("Could not reach Termux: " + (e.message ?: "")))
                }
            }
        }
        return result ?: throw TerminalException(
            "Termux did not answer. In Termux run: echo 'allow-external-apps=true' >> ~/.termux/termux.properties  then restart Termux."
        )
    }
}
