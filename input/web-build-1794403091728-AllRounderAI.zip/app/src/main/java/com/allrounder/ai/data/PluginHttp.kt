
package com.allrounder.ai.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/** Used by custom slash-command plugins that fetch an https URL. Plain GET, no custom headers. */
object PluginHttp {
    private val http = OkHttpClient.Builder().callTimeout(10, TimeUnit.SECONDS).build()

    suspend fun fetch(url: String): String = withContext(Dispatchers.IO) {
        if (!url.startsWith("https://")) return@withContext "(only https URLs are allowed)"
        try {
            http.newCall(Request.Builder().url(url).build()).execute().use { it.body?.string().orEmpty().take(6000) }
        } catch (e: Exception) {
            "(request failed: " + (e.message ?: "unknown") + ")"
        }
    }
}
