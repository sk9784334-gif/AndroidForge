
package com.allrounder.ai.data

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withTimeoutOrNull
import java.lang.reflect.Proxy
import kotlinx.coroutines.withContext
import java.io.File

/** Fully offline inference with a MediaPipe-compatible .task model (Gemma family). */
object OnDeviceLlm {
    private var engine: LlmInference? = null
    private var loadedPath: String? = null

    suspend fun generate(
        ctx: Context, path: String, system: String, history: List<Turn>, onDelta: ((String) -> Unit)? = null
    ): String =
        withContext(Dispatchers.Default) {
            if (path.isBlank() || !File(path).exists()) {
                throw LlmException("On-device model missing - import a .task model in Settings")
            }
            val e = synchronized(this@OnDeviceLlm) {
                if (engine == null || loadedPath != path) {
                    engine?.close()
                    engine = try {
                        LlmInference.createFromOptions(
                            ctx.applicationContext,
                            LlmInference.LlmInferenceOptions.builder().setModelPath(path).setMaxTokens(2048).build()
                        )
                    } catch (ex: Exception) {
                        throw LlmException("Could not load on-device model: ${ex.message}")
                    }
                    loadedPath = path
                }
                engine!!
            }
            val turns = history.takeLast(6)
            val prompt = buildString {
                turns.forEachIndexed { i, t ->
                    val text = if (i == 0 && t.role == "user" && system.isNotBlank()) system + "\n\n" + t.content else t.content
                    append(if (t.role == "user") "<start_of_turn>user\n" else "<start_of_turn>model\n")
                    append(text.take(4000)).append("<end_of_turn>\n")
                }
                append("<start_of_turn>model\n")
            }
            val streamed = if (onDelta != null) streamViaReflection(e, prompt, onDelta) else null
            if (streamed != null) return@withContext streamed.trim()
            try {
                e.generateResponse(prompt).trim()
            } catch (ex: Exception) {
                throw LlmException("On-device error: ${ex.message}")
            }
        }
}

/**
 * Streams tokens when this MediaPipe version has generateResponseAsync(prompt, listener). Looked up by reflection so the
 * app still builds and falls back to the normal (non-streaming) call on versions where it does not exist.
 */
private suspend fun streamViaReflection(e: LlmInference, prompt: String, onDelta: (String) -> Unit): String? {
    val m = e.javaClass.methods.firstOrNull {
        it.name == "generateResponseAsync" && it.parameterTypes.size == 2 && it.parameterTypes[0] == String::class.java
    } ?: return null
    val listenerType = m.parameterTypes[1]
    val sb = StringBuilder()
    val done = CompletableDeferred<Unit>()
    val proxy = Proxy.newProxyInstance(listenerType.classLoader, arrayOf(listenerType)) { _, method, args ->
        when (method.name) {
            "hashCode" -> 0
            "equals" -> false
            "toString" -> "listener"
            else -> {
                if (args != null && args.size >= 2) {
                    sb.append(args[0] as? String ?: "")
                    onDelta(sb.toString())
                    if (args[1] as? Boolean == true) done.complete(Unit)
                }
                null
            }
        }
    }
    return try {
        m.invoke(e, prompt, proxy)
        withTimeoutOrNull(300_000) { done.await() }
        sb.toString().ifBlank { null }
    } catch (ex: Exception) {
        sb.toString().ifBlank { null }
    }
}

suspend fun runProvider(
    ctx: Context, spec: ProviderSpec, s: SettingsState, system: String, history: List<Turn>,
    onDelta: ((String) -> Unit)? = null
): String =
    if (spec.type == ProviderType.ONDEVICE) OnDeviceLlm.generate(ctx, s.modelPath, system, history, onDelta)
    else LlmClient.complete(spec, s.keys[spec.id].orEmpty(), s.modelFor(spec), system, history, s.urls[spec.id], s.temperature, onDelta)
