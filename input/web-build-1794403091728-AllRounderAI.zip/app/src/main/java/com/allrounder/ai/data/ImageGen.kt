
package com.allrounder.ai.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class GeneratedImage(val b64: String, val ext: String)

/** Photo-style AI images via your own OpenAI or Gemini key (billed by the provider). Model names are editable in Settings. */
object ImageGen {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(180, TimeUnit.SECONDS).callTimeout(200, TimeUnit.SECONDS).build()
    private val JSON_TYPE = "application/json; charset=utf-8".toMediaType()

    suspend fun generate(s: SettingsState, prompt: String): GeneratedImage = withContext(Dispatchers.IO) {
        val openai = s.keys["openai"].orEmpty()
        val gemini = s.keys["gemini"].orEmpty()
        when {
            openai.isNotBlank() -> openAi(openai, s.models["img_openai"]?.takeIf { it.isNotBlank() } ?: "gpt-image-1", prompt)
            gemini.isNotBlank() -> gemini(gemini, s.models["img_gemini"]?.takeIf { it.isNotBlank() } ?: "gemini-2.5-flash-image", prompt)
            else -> throw LlmException("Add an OpenAI or Gemini API key in Settings to generate images.")
        }
    }

    private fun call(req: Request, name: String): JSONObject {
        try {
            http.newCall(req).execute().use { r ->
                val body = r.body?.string().orEmpty()
                if (!r.isSuccessful) {
                    val msg = runCatching { JSONObject(body).optJSONObject("error")?.optString("message") }.getOrNull()
                    throw LlmException("$name image: HTTP ${r.code} - " + (msg?.takeIf { it.isNotBlank() } ?: body.take(160)))
                }
                return JSONObject(body)
            }
        } catch (e: IOException) {
            throw LlmException("$name image: network error (" + (e.message ?: "check connection") + ")")
        }
    }

    private fun openAi(key: String, model: String, prompt: String): GeneratedImage {
        val body = JSONObject().put("model", model).put("prompt", prompt).put("size", "1024x1024").put("n", 1)
        if (model.startsWith("dall-e")) body.put("response_format", "b64_json")
        val req = Request.Builder().url("https://api.openai.com/v1/images/generations")
            .header("Authorization", "Bearer $key").post(body.toString().toRequestBody(JSON_TYPE)).build()
        val json = call(req, "OpenAI")
        val b64 = json.optJSONArray("data")?.optJSONObject(0)?.optString("b64_json").orEmpty()
        if (b64.isBlank()) throw LlmException("OpenAI image: no image returned")
        return GeneratedImage(b64, "png")
    }

    private fun gemini(key: String, model: String, prompt: String): GeneratedImage {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
        val req = Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", key).post(body.toString().toRequestBody(JSON_TYPE)).build()
        val json = call(req, "Gemini")
        val parts = json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
        if (parts != null) for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            val inline = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data")
            val data = inline?.optString("data").orEmpty()
            if (data.isNotBlank()) {
                val mime = (inline?.optString("mimeType")?.takeIf { it.isNotBlank() } ?: inline?.optString("mime_type")).orEmpty()
                return GeneratedImage(data, if (mime.contains("jpeg")) "jpg" else if (mime.contains("webp")) "webp" else "png")
            }
        }
        throw LlmException("Gemini image: no image returned (this model may need a paid plan)")
    }
}
