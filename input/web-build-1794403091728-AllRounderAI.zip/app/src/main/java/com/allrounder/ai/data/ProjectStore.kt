
package com.allrounder.ai.data

import android.content.Context
import android.net.Uri
import android.util.Base64
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class SavedProject(val id: String, val mode: String, val title: String, val updatedAt: Long)

/** Generated projects are kept as small JSON files in app-private storage. */
object ProjectStore {
    private val ID = Regex("[A-Za-z0-9-]+")
    private fun dir(ctx: Context) = File(ctx.filesDir, "projects").apply { mkdirs() }
    private fun file(ctx: Context, id: String): File {
        require(ID.matches(id)) { "bad id" }
        return File(dir(ctx), "$id.json")
    }

    fun save(ctx: Context, id: String, mode: String, title: String, files: List<GenFile>) {
        val arr = JSONArray()
        files.forEach { arr.put(JSONObject().put("path", it.path).put("content", it.content).put("binary", it.binary)) }
        val o = JSONObject().put("id", id).put("mode", mode).put("title", title)
            .put("updatedAt", System.currentTimeMillis()).put("files", arr)
        file(ctx, id).writeText(o.toString())
    }

    fun list(ctx: Context, mode: String): List<SavedProject> =
        dir(ctx).listFiles { f -> f.extension == "json" }.orEmpty().mapNotNull { f ->
            try {
                val o = JSONObject(f.readText())
                if (o.getString("mode") != mode) null
                else SavedProject(o.getString("id"), mode, o.optString("title", "Project"), o.optLong("updatedAt"))
            } catch (e: Exception) {
                null
            }
        }.sortedByDescending { it.updatedAt }

    fun load(ctx: Context, id: String): List<GenFile> = try {
        val arr = JSONObject(file(ctx, id).readText()).getJSONArray("files")
        (0 until arr.length()).map { GenFile(arr.getJSONObject(it).getString("path"), arr.getJSONObject(it).getString("content"), arr.getJSONObject(it).optBoolean("binary")) }
    } catch (e: Exception) {
        emptyList()
    }

    fun delete(ctx: Context, id: String) {
        file(ctx, id).delete()
    }

    /** Writes a ZIP into the cache and returns a shareable content:// URI. */
    fun exportZip(ctx: Context, name: String, files: List<GenFile>): Uri {
        val out = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val safe = name.replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "project" }
        val f = File(out, "$safe.zip")
        ZipOutputStream(f.outputStream()).use { z ->
            files.forEach {
                z.putNextEntry(ZipEntry(it.path))
                z.write(if (it.binary) Base64.decode(it.content, Base64.DEFAULT) else it.content.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
        }
        return FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
    }
}
