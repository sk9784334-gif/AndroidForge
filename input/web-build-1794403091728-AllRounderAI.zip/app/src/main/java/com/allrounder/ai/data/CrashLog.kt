
package com.allrounder.ai.data

import android.app.Application
import android.content.Context
import java.io.File

/** Saves the last crash stack trace so it can be viewed/shared from Profile > Diagnostics. */
object CrashLog {
    private fun file(ctx: Context) = File(ctx.filesDir, "last_crash.txt")

    fun install(app: Application) {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                file(app).writeText(
                    "Time: " + java.util.Date() + "\nThread: " + t.name + "\nAndroid: " + android.os.Build.VERSION.SDK_INT +
                        "\nDevice: " + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL + "\n\n" +
                        android.util.Log.getStackTraceString(e)
                )
            } catch (e2: Throwable) { /* nothing more we can do */ }
            prev?.uncaughtException(t, e)
        }
    }

    fun read(ctx: Context): String? = file(ctx).takeIf { it.exists() }?.readText()
    fun clear(ctx: Context) { file(ctx).delete() }
}
