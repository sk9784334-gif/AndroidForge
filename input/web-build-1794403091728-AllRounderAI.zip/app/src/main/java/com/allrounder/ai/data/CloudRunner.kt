
package com.allrounder.ai.data

import android.content.Context
import kotlinx.coroutines.delay
import org.json.JSONObject

/** Runs a file in a private repo of the user's own GitHub (GitHub Actions). Used by Code runner and Terminal cloud shell. */
object CloudRunner {
    suspend fun run(ctx: Context, token: String, file: String, code: String, stdin: String = "", onStatus: (String) -> Unit): String {
        val api = GitHubApi(token)
        val repo = "allrounder-runner"
        onStatus("Connecting to GitHub...")
        val owner = api.login()
        onStatus("Preparing private runner repo...")
        api.createRepo(repo, private = true)
        val yml = ctx.assets.open("run.yml").bufferedReader().use { it.readText() }
        api.putFile(owner, repo, GenFile(".github/workflows/run.yml", yml))
        api.putFile(owner, repo, GenFile(file, code))
        api.putFile(owner, repo, GenFile("stdin.txt", stdin.ifEmpty { "\n" }))
        val before = api.latestRun(owner, repo)?.id
        onStatus("Starting run...")
        delay(3000)
        var started = false
        var tries = 0
        while (!started) {
            try {
                api.dispatchWorkflow(owner, repo, "run.yml", JSONObject().put("file", file))
                started = true
            } catch (e: GitHubException) {
                if (++tries >= 4) throw e
                delay(3000)
            }
        }
        onStatus("Running on GitHub...")
        var found: RunInfo? = null
        repeat(45) {
            if (found == null) {
                delay(4000)
                val r = api.latestRun(owner, repo)
                if (r != null && r.id != before && r.status == "completed") found = r
            }
        }
        val run = found ?: throw GitHubException("Timed out waiting for the run. Check GitHub Actions.")
        val raw = api.runLog(owner, repo, run.id)
        val out = raw.substringAfter("AF_2BEGIN", "").substringBefore("AF_2END").trim()
        return when {
            out.isNotEmpty() -> out.takeLast(8000)
            raw.contains("AF_2BEGIN") -> "(no output)"
            else -> raw.takeLast(1500).ifBlank { "(no log available)" }
        }
    }
}
