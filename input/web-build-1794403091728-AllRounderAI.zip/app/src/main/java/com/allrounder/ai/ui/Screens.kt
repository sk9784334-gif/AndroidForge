
@file:OptIn(ExperimentalMaterial3Api::class)

package com.allrounder.ai.ui

import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.allrounder.ai.BuildMode
import com.allrounder.ai.BuilderPrefill
import com.allrounder.ai.ChatViewModel
import com.allrounder.ai.data.CrashLog
import com.allrounder.ai.data.ImageStore
import com.allrounder.ai.data.MessageEntity
import com.allrounder.ai.data.Plugin
import com.allrounder.ai.data.ProjectStore
import com.allrounder.ai.data.ScheduledTask
import com.allrounder.ai.data.SchedStore
import com.allrounder.ai.data.Scheduler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType

@Composable
private fun ScreenScaffold(title: String, onBack: () -> Unit, content: @Composable (PaddingValues) -> Unit) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad -> content(pad) }
}

@Composable
fun SearchScreen(vm: ChatViewModel, onBack: () -> Unit, onOpenChat: () -> Unit) {
    val chats by vm.chats.collectAsState()
    var q by remember { mutableStateOf("") }
    var hits by remember { mutableStateOf<List<MessageEntity>>(emptyList()) }
    LaunchedEffect(q) { hits = if (q.length >= 2) vm.search(q) else emptyList() }
    val titles = chats.filter { q.isBlank() || it.title.contains(q, ignoreCase = true) }
    ScreenScaffold("Search", onBack) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding(),
            contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                OutlinedTextField(
                    value = q, onValueChange = { q = it }, placeholder = { Text("Search chats and messages") },
                    singleLine = true, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()
                )
            }
            item { Text("Chats", style = MaterialTheme.typography.labelLarge) }
            items(titles, key = { "c" + it.id }) { c ->
                Text(
                    c.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth().clickable { vm.openChat(c.id); onOpenChat() }.padding(vertical = 10.dp)
                )
            }
            if (hits.isNotEmpty()) {
                item { Text("Messages", style = MaterialTheme.typography.labelLarge) }
                items(hits, key = { "m" + it.id }) { m ->
                    Column(Modifier.fillMaxWidth().clickable { vm.openChat(m.chatId); onOpenChat() }.padding(vertical = 8.dp)) {
                        Text(chats.firstOrNull { it.id == m.chatId }?.title ?: "Chat", style = MaterialTheme.typography.labelSmall)
                        Text(m.content, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
fun ImagesScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val msgs by vm.imageMessages.collectAsState()
    val ctx = LocalContext.current
    val ids = remember(msgs) { msgs.flatMap { it.image.orEmpty().split("|") }.filter { it.isNotBlank() } }
    var open by remember { mutableStateOf<String?>(null) }
    ScreenScaffold("Images", onBack) { pad ->
        if (ids.isEmpty()) Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
            Text("Photos and PDF pages you attach in chats appear here.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else LazyVerticalGrid(
            GridCells.Fixed(3), Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            gridItems(ids, key = { it }) { id ->
                val bmp = remember(id) { ImageStore.bitmap(ctx, id, 4)?.asImageBitmap() }
                if (bmp != null) Image(
                    bitmap = bmp, contentDescription = "Attached image", contentScale = ContentScale.Crop,
                    modifier = Modifier.aspectRatio(1f).clip(RoundedCornerShape(10.dp)).clickable { open = id }
                )
            }
        }
    }
    open?.let { id ->
        Dialog(onDismissRequest = { open = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(Modifier.fillMaxSize()) {
                Column(Modifier.statusBarsPadding().navigationBarsPadding()) {
                    TextButton(onClick = { open = null }, modifier = Modifier.align(Alignment.End)) { Text(tr("Close")) }
                    val bmp = remember(id) { ImageStore.bitmap(ctx, id, 1)?.asImageBitmap() }
                    if (bmp != null) Image(bitmap = bmp, contentDescription = "Image", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                }
            }
        }
    }
}

@Composable
fun LibraryScreen(vm: ChatViewModel, onBack: () -> Unit, onOpenChat: () -> Unit) {
    val starred by vm.starred.collectAsState()
    val clip = LocalClipboardManager.current
    ScreenScaffold("Library", onBack) { pad ->
        if (starred.isEmpty()) Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
            Text("Star a message from its menu to save it here.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else LazyColumn(
            Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(starred, key = { it.id }) { m ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(14.dp)) {
                        Text(m.content, maxLines = 10, overflow = TextOverflow.Ellipsis)
                        Row {
                            TextButton(onClick = { clip.setText(AnnotatedString(m.content)) }) { Text(tr("Copy")) }
                            TextButton(onClick = { vm.openChat(m.chatId); onOpenChat() }) { Text("Open chat") }
                            TextButton(onClick = { vm.toggleStar(m) }) { Text("Unstar") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProjectsScreen(onBack: () -> Unit, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val web = remember { ProjectStore.list(ctx, BuildMode.WEB.name) }
    val app = remember { ProjectStore.list(ctx, BuildMode.APP.name) }
    ScreenScaffold("Projects", onBack) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onOpen("web") }) { Text("New website") }
                    Button(onClick = { onOpen("app") }) { Text("New Android app") }
                }
            }
            if (web.isEmpty() && app.isEmpty()) item {
                Text("Generated websites and apps are saved here.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(web, key = { it.id }) { p ->
                ProjectRow("Website", p.title) { BuilderPrefill.mode = BuildMode.WEB; BuilderPrefill.id = p.id; onOpen("web") }
            }
            items(app, key = { it.id }) { p ->
                ProjectRow("App", p.title) { BuilderPrefill.mode = BuildMode.APP; BuilderPrefill.id = p.id; onOpen("app") }
            }
        }
    }
}

@Composable
private fun ProjectRow(kind: String, title: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(kind, style = MaterialTheme.typography.labelLarge, modifier = Modifier.width(72.dp))
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun PluginsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val st by vm.settings.state.collectAsState()
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var template by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    ScreenScaffold("Plugins", onBack) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding(),
            contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SettingsCard("Built-in") {
                    ToggleRow("Terminal tool in chat", "AI can propose shell commands; start a message with \$ to run one directly.", st.terminalTool) { vm.settings.setTerminalTool(it) }
                    ToggleRow("Auto-run safe commands", "Runs AI-proposed commands without asking, except risky ones (delete, sudo, chmod...).", st.termAuto) { vm.settings.setTermAuto(it) }
                    ToggleRow("Web search", "Adds live results (needs a Tavily key in Settings).", st.webSearch) { vm.settings.setWebSearch(it) }
                }
            }
            item {
                SettingsCard("Your slash commands") {
                    Text(
                        "Type /name your text in chat. The template replaces {input} with your text and {result} with the https URL's response (optional).",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (st.plugins.isEmpty()) Text("No custom plugins yet.", style = MaterialTheme.typography.bodySmall)
                    st.plugins.forEachIndexed { i, p ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("/" + p.name, fontWeight = FontWeight.SemiBold)
                                if (p.description.isNotBlank()) Text(p.description, style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(checked = p.enabled, onCheckedChange = { on ->
                                vm.settings.setPlugins(st.plugins.mapIndexed { j, q -> if (j == i) q.copy(enabled = on) else q })
                            })
                            TextButton(onClick = { vm.settings.setPlugins(st.plugins.filterIndexed { j, _ -> j != i }) }) { Text(tr("Delete")) }
                        }
                    }
                }
            }
            item {
                SettingsCard("Add plugin") {
                    OutlinedTextField(value = name, onValueChange = { name = it.filter { c -> c.isLetterOrDigit() || c == '-' || c == '_' } }, label = { Text("Command name (e.g. translate)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Description") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = template, onValueChange = { template = it }, label = { Text("Template, e.g. Translate to Hindi: {input}") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("Optional https URL ({input} allowed)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Button(
                        enabled = name.isNotBlank() && template.isNotBlank() && (url.isBlank() || url.startsWith("https://")),
                        onClick = {
                            vm.settings.setPlugins(st.plugins + Plugin(name.trim(), desc.trim(), template, url.trim(), true))
                            name = ""; desc = ""; template = ""; url = ""
                        }
                    ) { Text(tr("Add plugin")) }
                }
            }
        }
    }
}

@Composable
private fun ToggleRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun ProfileScreen(vm: ChatViewModel, onBack: () -> Unit, onNavigate: (String) -> Unit) {
    val st by vm.settings.state.collectAsState()
    var name by remember { mutableStateOf(st.userName) }
    var about by remember { mutableStateOf(st.aboutMe) }
    ScreenScaffold("Profile", onBack) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding(),
            contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(name, 64.dp)
                    Spacer(Modifier.width(16.dp))
                    OutlinedTextField(
                        value = name, onValueChange = { name = it; vm.settings.setUserName(it) },
                        label = { Text(tr("Your name")) }, singleLine = true, modifier = Modifier.weight(1f)
                    )
                }
            }
            item {
                OutlinedTextField(
                    value = about, onValueChange = { about = it; vm.settings.setAboutMe(it) },
                    label = { Text("Personalisation: about you and how I should reply") },
                    minLines = 3, maxLines = 8, modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                SettingsCard("Language") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = st.uiLang == "en", onClick = { vm.settings.setUiLang("en") }, label = { Text("English") })
                        FilterChip(selected = st.uiLang == "hi", onClick = { vm.settings.setUiLang("hi") }, label = { Text("\u0939\u093F\u0928\u094D\u0926\u0940") })
                    }
                    Text("Hindi covers the main screens; everything else stays in English.", style = MaterialTheme.typography.bodySmall)
                }
            }
            item { AppearanceCard(st, vm) }
            item {
                SettingsCard("App lock delay") {
                    Text(
                        "How long the app can stay in the background before it asks to unlock again (turn on App lock in AI providers settings).",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0 to "Instantly", 30 to "30 s", 120 to "2 min", 600 to "10 min").forEach { (sec, label) ->
                            FilterChip(selected = st.lockTimeout == sec, onClick = { vm.settings.setLockTimeout(sec) }, label = { Text(label) })
                        }
                    }
                }
            }
            item {
                SettingsCard("Usage (estimated tokens)") {
                    val rows = com.allrounder.ai.data.PROVIDERS.filter { (st.usage[it.id + ":in"] ?: 0L) + (st.usage[it.id + ":out"] ?: 0L) > 0L }
                    if (rows.isEmpty()) Text("Nothing used yet.", style = MaterialTheme.typography.bodySmall)
                    rows.forEach {
                        Text(it.name + ":  ~" + (st.usage[it.id + ":in"] ?: 0L) + " in / ~" + (st.usage[it.id + ":out"] ?: 0L) + " out")
                    }
                    Text("Rough estimate (characters / 4). Check your provider dashboard for exact billing.", style = MaterialTheme.typography.labelSmall)
                }
            }
            item {
                SettingsCard("Shortcuts") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onNavigate("settings") }) { Text(tr("AI providers")) }
                        OutlinedButton(onClick = { onNavigate("plugins") }) { Text(tr("Plugins")) }
                    }
                    OutlinedButton(onClick = { onNavigate("privacy") }) { Text(tr("Privacy policy")) }
                }
            }
            item { DiagnosticsCard() }
        }
    }
}

@Composable
private fun DiagnosticsCard() {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var crash by remember { mutableStateOf(CrashLog.read(ctx)) }
    SettingsCard("Diagnostics") {
        if (crash == null) Text("No crash recorded. If the app ever closes unexpectedly, the report shows up here.", style = MaterialTheme.typography.bodySmall)
        else {
            Text("Last crash report:", style = MaterialTheme.typography.labelLarge)
            SelectionContainer { Text(crash!!.take(2500), fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { clip.setText(AnnotatedString(crash!!)) }) { Text(tr("Copy")) }
                OutlinedButton(onClick = {
                    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, crash)
                    ctx.startActivity(Intent.createChooser(send, "Share crash report"))
                }) { Text("Share") }
                TextButton(onClick = { CrashLog.clear(ctx); crash = null }) { Text(tr("Clear")) }
            }
        }
    }
}

@Composable
fun SchedulerScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var tasks by remember { mutableStateOf(SchedStore.list(ctx)) }
    var prompt by remember { mutableStateOf("") }
    var hh by remember { mutableStateOf("08") }
    var mm by remember { mutableStateOf("00") }
    var daily by remember { mutableStateOf(true) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    ScreenScaffold("Scheduled", onBack) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding(),
            contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    "Ask the AI something at a set time (for example a daily news summary). The answer is saved as a chat and you get a notification. " +
                        "Android may delay it a little to save battery. Needs an AI provider with an API key.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            items(tasks, key = { it.id }) { t ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("%02d:%02d".format(t.hour, t.minute) + (if (t.daily) "  daily" else "  once"), fontWeight = FontWeight.SemiBold)
                        Text(t.prompt, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Row {
                            TextButton(onClick = { Scheduler.schedule(ctx, t, 3000) }) { Text("Test in 3 s") }
                            TextButton(onClick = {
                                Scheduler.cancel(ctx, t.id); SchedStore.remove(ctx, t.id); tasks = SchedStore.list(ctx)
                            }) { Text(tr("Delete")) }
                        }
                    }
                }
            }
            item {
                SettingsCard("New scheduled prompt") {
                    OutlinedTextField(value = prompt, onValueChange = { prompt = it }, label = { Text("What should I do?") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = hh, onValueChange = { hh = it.filter { c -> c.isDigit() }.take(2) }, label = { Text("Hour") },
                            singleLine = true, modifier = Modifier.width(90.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                        Text(":")
                        OutlinedTextField(
                            value = mm, onValueChange = { mm = it.filter { c -> c.isDigit() }.take(2) }, label = { Text("Min") },
                            singleLine = true, modifier = Modifier.width(90.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                        Spacer(Modifier.weight(1f))
                        Text("Daily")
                        Switch(checked = daily, onCheckedChange = { daily = it })
                    }
                    Button(
                        enabled = prompt.isNotBlank(),
                        onClick = {
                            if (android.os.Build.VERSION.SDK_INT >= 33) perm.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                            val t = ScheduledTask(
                                java.util.UUID.randomUUID().toString(), prompt.trim(),
                                (hh.toIntOrNull() ?: 8).coerceIn(0, 23), (mm.toIntOrNull() ?: 0).coerceIn(0, 59), daily
                            )
                            SchedStore.add(ctx, t)
                            Scheduler.schedule(ctx, t)
                            tasks = SchedStore.list(ctx)
                            prompt = ""
                        }
                    ) { Text("Add") }
                }
            }
        }
    }
}
