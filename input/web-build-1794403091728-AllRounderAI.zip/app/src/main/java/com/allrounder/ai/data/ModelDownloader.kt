
package com.allrounder.ai.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Downloads an on-device model file (https only) into app storage. */
object ModelDownloader {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()

    suspend fun download(ctx: Context, url: String, hfToken: String, onProgress: (Long, Long) -> Unit): File =
        withContext(Dispatchers.IO) {
            val host = url.toHttpUrl().host
            val builder = Request.Builder().url(url)
            if (hfToken.isNotBlank() && (host == "huggingface.co" || host.endsWith(".huggingface.co"))) {
                builder.header("Authorization", "Bearer $hfToken")
            }
            http.newCall(builder.build()).execute().use { r ->
                if (!r.isSuccessful) throw IOException("HTTP ${r.code}. Gated models need a Hugging Face token in Settings.")
                val body = r.body ?: throw IOException("Empty response")
                val total = body.contentLength()
                if (total > 0 && ctx.filesDir.usableSpace < total + 200L * 1024 * 1024) throw IOException("Not enough free storage")
                val tmp = File(ctx.filesDir, "model.tmp")
                val dest = File(ctx.filesDir, "model.task")
                body.byteStream().use { input ->
                    tmp.outputStream().use { out ->
                        val buf = ByteArray(1 shl 20)
                        var done = 0L
                        var last = 0L
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (done - last > 20L * 1024 * 1024) { onProgress(done, total); last = done; ensureActive() }
                        }
                    }
                }
                if (dest.exists()) dest.delete()
                if (!tmp.renameTo(dest)) throw IOException("Could not save the model file")
                dest
            }
        }
}
