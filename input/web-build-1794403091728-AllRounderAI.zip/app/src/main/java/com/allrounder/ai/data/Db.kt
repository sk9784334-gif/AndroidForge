package com.allrounder.ai.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val updatedAt: Long,
    @ColumnInfo(defaultValue = "0") val pinned: Boolean = false,
    val systemPrompt: String? = null,
    val providerId: String? = null,
    val tag: String? = null
)

@Entity(
    tableName = "messages",
    foreignKeys = [ForeignKey(
        entity = ChatEntity::class,
        parentColumns = ["id"],
        childColumns = ["chatId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("chatId")]
)
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val chatId: Long,
    val role: String,
    val content: String,
    val provider: String?,
    val createdAt: Long,
    val image: String? = null,
    @ColumnInfo(defaultValue = "0") val starred: Boolean = false
)

@Dao
interface ChatDao {
    @Query("SELECT * FROM chats ORDER BY pinned DESC, updatedAt DESC")
    fun chats(): Flow<List<ChatEntity>>

    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY id ASC")
    fun messages(chatId: Long): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY id ASC")
    suspend fun messagesOnce(chatId: Long): List<MessageEntity>

    @Query("SELECT * FROM chats WHERE id = :id")
    suspend fun chat(id: Long): ChatEntity?

    @Query("UPDATE chats SET title = :title WHERE id = :id")
    suspend fun rename(id: Long, title: String)

    @Query("UPDATE chats SET pinned = :pinned WHERE id = :id")
    suspend fun setPinned(id: Long, pinned: Boolean)

    @Query("UPDATE chats SET systemPrompt = :prompt WHERE id = :id")
    suspend fun setSystemPrompt(id: Long, prompt: String?)

    @Query("SELECT * FROM chats")
    suspend fun allChats(): List<ChatEntity>

    @Query("SELECT * FROM messages ORDER BY id ASC")
    suspend fun allMessages(): List<MessageEntity>

    @Query("DELETE FROM messages WHERE id = :id")
    suspend fun deleteMessage(id: Long)

    @Query("DELETE FROM messages WHERE chatId = :chatId AND id >= :fromId")
    suspend fun deleteFrom(chatId: Long, fromId: Long)

    @Query("DELETE FROM messages WHERE chatId = :chatId")
    suspend fun clearMessages(chatId: Long)

    @Query("SELECT * FROM messages WHERE starred = 1 ORDER BY id DESC")
    fun starred(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE image IS NOT NULL AND image != '' ORDER BY id DESC LIMIT 200")
    fun imageMessages(): Flow<List<MessageEntity>>

    @Query("UPDATE messages SET starred = :v WHERE id = :id")
    suspend fun setStarred(id: Long, v: Boolean)

    @Query("SELECT * FROM messages WHERE content LIKE '%' || :q || '%' ORDER BY id DESC LIMIT 60")
    suspend fun search(q: String): List<MessageEntity>

    @Query("UPDATE chats SET tag = :tag WHERE id = :id")
    suspend fun setTag(id: Long, tag: String?)

    @Query("UPDATE chats SET providerId = :providerId WHERE id = :id")
    suspend fun setProvider(id: Long, providerId: String?)

    @Insert
    suspend fun insertChat(chat: ChatEntity): Long

    @Insert
    suspend fun insertMessage(message: MessageEntity): Long

    @Query("UPDATE chats SET updatedAt = :time WHERE id = :id")
    suspend fun touch(id: Long, time: Long)

    @Query("DELETE FROM chats WHERE id = :id")
    suspend fun deleteChat(id: Long)

    @Query("DELETE FROM chats")
    suspend fun deleteAll()
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE messages ADD COLUMN image TEXT")
    }
}

val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE chats ADD COLUMN pinned INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE chats ADD COLUMN systemPrompt TEXT")
    }
}

val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE messages ADD COLUMN starred INTEGER NOT NULL DEFAULT 0")
    }
}

val MIGRATION_4_5 = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE chats ADD COLUMN providerId TEXT")
    }
}

val MIGRATION_5_6 = object : Migration(5, 6) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE chats ADD COLUMN tag TEXT")
    }
}

@Database(entities = [ChatEntity::class, MessageEntity::class], version = 6, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): ChatDao

    companion object {
        @Volatile private var instance: AppDb? = null
        fun get(context: Context): AppDb = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDb::class.java, "allrounder.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6)
                .build().also { instance = it }
        }
    }
}
