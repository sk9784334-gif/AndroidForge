
package com.allrounder.ai.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Optional live web search (Tavily). Only used when the user turns it on and adds a key. */
object SearchClient {
    private val http = OkHttpClient.Builder().callTimeout(25, TimeUnit.SECONDS).build()

    suspend fun search(key: String, query: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject().put("query", query.take(300)).put("max_results", 5)
        val req = Request.Builder().url("https://api.tavily.com/search")
            .header("Authorization", "Bearer $key")
            .post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("search HTTP ${r.code}")
            val arr = JSONObject(r.body?.string().orEmpty()).optJSONArray("results")
            buildString {
                if (arr != null) for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    append("- ").append(o.optString("title")).append(" (").append(o.optString("url")).append("): ")
                        .append(o.optString("content").take(400)).append("\n")
                }
            }
        }
    }
}
