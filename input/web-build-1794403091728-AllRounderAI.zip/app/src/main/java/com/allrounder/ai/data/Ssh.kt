
package com.allrounder.ai.data

import android.content.Context
import com.jcraft.jsch.ChannelExec
import com.jcraft.jsch.JSch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/** Runs a command on your own computer/VPS over SSH (password login). Host key is pinned on first use. */
object Ssh {
    suspend fun exec(ctx: Context, cmd: String): String = withContext(Dispatchers.IO) {
        val repo = SettingsRepo.get(ctx)
        val s = repo.state.value
        if (s.sshHost.isBlank() || s.sshUser.isBlank()) {
            throw TerminalException("Fill in the SSH host, user and password in the Terminal screen.")
        }
        val jsch = JSch()
        val session = jsch.getSession(s.sshUser, s.sshHost, s.sshPort)
        session.setPassword(s.sshPass)
        session.setConfig("StrictHostKeyChecking", "no")
        try {
            session.connect(15_000)
            val fp = session.hostKey.getFingerPrint(jsch)
            val id = s.sshHost + ":" + s.sshPort
            val known = repo.hostKey(id)
            if (known == null) repo.setHostKey(id, fp)
            else if (known != fp) throw TerminalException("Host key changed - possible attack. Disconnected.")
            val ch = session.openChannel("exec") as ChannelExec
            ch.setCommand(cmd)
            val err = ByteArrayOutputStream()
            ch.setErrStream(err)
            val input = ch.inputStream
            ch.connect(15_000)
            val out = StringBuilder()
            val buf = ByteArray(4096)
            val deadline = System.currentTimeMillis() + 60_000
            while (System.currentTimeMillis() < deadline) {
                while (input.available() > 0) {
                    val n = input.read(buf)
                    if (n < 0) break
                    if (out.length < 20_000) out.append(String(buf, 0, n))
                }
                if (ch.isClosed && input.available() == 0) break
                Thread.sleep(50)
            }
            val timedOut = !ch.isClosed
            val code = ch.exitStatus
            ch.disconnect()
            var text = out.toString()
            val e = err.toString()
            if (e.isNotBlank()) text += "\n" + e
            if (timedOut) text += "\n[stopped after 60 seconds]" else if (code > 0) text += "\n[exit code $code]"
            text.trim()
        } catch (e: TerminalException) {
            throw e
        } catch (e: Exception) {
            throw TerminalException("SSH error: " + (e.message ?: e.javaClass.simpleName))
        } finally {
            session.disconnect()
        }
    }
}
