
package com.allrounder.ai

import android.app.Application
import android.net.ConnectivityManager
import android.net.Network
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.allrounder.ai.data.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    val settings = SettingsRepo.get(app)

    val currentChatId = MutableStateFlow<Long?>(null)
    val loading = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)
    /** Text of the reply while it is still being streamed in. */
    val streaming = MutableStateFlow<String?>(null)
    /** Text to put back into the input box (edit & resend, shared text, terminal output). */
    val draft = MutableStateFlow<String?>(null)
    val policyStatus = MutableStateFlow("")
    val tempChat = MutableStateFlow(false)
    val modelStatus = MutableStateFlow("")
    val downloadStatus = MutableStateFlow("")

    private var tempId: Long? = null
    private var termCwd: String? = null

    val chats: StateFlow<List<ChatEntity>> = dao.chats()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val starred: StateFlow<List<MessageEntity>> = dao.starred()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val imageMessages: StateFlow<List<MessageEntity>> = dao.imageMessages()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val messages: StateFlow<List<MessageEntity>> = currentChatId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.messages(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var job: Job? = null
    private var retryPending = false

    init {
        // Offline queue: if a request failed for lack of network, retry once the connection is back.
        try {
            val cm = app.getSystemService(ConnectivityManager::class.java)
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    if (retryPending) {
                        retryPending = false
                        viewModelScope.launch { if (!loading.value) retry() }
                    }
                }
            })
        } catch (e: Exception) { /* connectivity info is optional */ }
    }

    suspend fun search(q: String): List<MessageEntity> = dao.search(q)

    // ---------------- sending ----------------
    fun send(text: String, image: String? = null) {
        val t = text.trim()
        if ((t.isEmpty() && image == null) || loading.value) return
        job = viewModelScope.launch {
            val app = getApplication<Application>()
            val s = settings.state.value
            var shown = t
            if (t.startsWith("/")) {
                val name = t.drop(1).substringBefore(' ')
                val rest = t.drop(1).substringAfter(' ', "").trim()
                if (name == "download") { startDownload(rest); return@launch }
                val p = s.plugins.firstOrNull { it.enabled && it.name.equals(name, ignoreCase = true) }
                if (p != null) {
                    loading.value = true
                    val result = if (p.url.isNotBlank()) PluginHttp.fetch(p.url.replace("{input}", URLEncoder.encode(rest, "UTF-8"))) else ""
                    loading.value = false
                    shown = p.template.replace("{input}", rest).replace("{result}", result)
                }
            }
            val now = System.currentTimeMillis()
            var id = currentChatId.value
            if (id == null) {
                id = dao.insertChat(ChatEntity(title = shown.ifBlank { "Image" }.take(48), updatedAt = now))
                currentChatId.value = id
                if (tempChat.value) tempId = id
            }
            val ids = image?.let { ImageStore.saveAll(app, it) }
            dao.insertMessage(
                MessageEntity(chatId = id, role = "user", content = shown, provider = null, createdAt = now, image = ids)
            )
            dao.touch(id, now)
            if (s.terminalTool && shown.startsWith("\$ ")) { runDirect(id, shown.drop(2)); return@launch }
            generate(id)
        }
    }

    private suspend fun insertAssistant(chatId: Long, text: String, label: String) {
        val now = System.currentTimeMillis()
        dao.insertMessage(MessageEntity(chatId = chatId, role = "assistant", content = text, provider = label, createdAt = now))
        dao.touch(chatId, now)
    }

    private suspend fun runDirect(chatId: Long, cmd: String) {
        loading.value = true
        try {
            val s = settings.state.value
            val res = TerminalEngine.exec(getApplication<Application>(), Backend.from(s.termBackend), cmd, termCwd, s.githubToken)
            termCwd = res.cwd ?: termCwd
            insertAssistant(chatId, "```\n" + res.output.ifBlank { "(no output)" } + "\n```", "Terminal")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error.value = e.message ?: "Terminal error"
        } finally {
            loading.value = false
        }
    }

    fun retry() {
        val id = currentChatId.value ?: return
        if (loading.value) return
        job = viewModelScope.launch { generate(id) }
    }

    /** Stops generation but keeps whatever was already streamed. */
    fun stop() {
        val partial = streaming.value
        val id = currentChatId.value
        job?.cancel()
        if (!partial.isNullOrBlank() && id != null) {
            viewModelScope.launch { insertAssistant(id, partial, "Stopped") }
        }
    }

    private suspend fun withWebSearch(s: SettingsState, history: List<Turn>, base: String): String {
        if (!s.webSearch || s.tavilyKey.isBlank()) return base
        val q = history.lastOrNull { it.role == "user" }?.content?.takeIf { it.isNotBlank() } ?: return base
        return try {
            val r = SearchClient.search(s.tavilyKey, q)
            if (r.isBlank()) base
            else base + "\n\nLive web search results for the user's latest message " +
                "(use them when relevant and mention the source URLs):\n" + r
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            base
        }
    }

    private fun autoTitle(chatId: Long, userText: String, reply: String, s: SettingsState) {
        viewModelScope.launch {
            try {
                val spec = s.providerOrder().firstOrNull() ?: return@launch
                if (spec.type == ProviderType.ONDEVICE) return@launch
                val t = runProvider(
                    getApplication<Application>(), spec, s,
                    "Reply with ONLY a 3 to 5 word title for this conversation. No quotes, no ending punctuation.",
                    listOf(Turn("user", userText.take(500) + "\n\nAssistant: " + reply.take(500)))
                )
                val clean = t.trim().trim('"', '\'', '.').take(48)
                if (clean.isNotBlank() && !clean.contains('\n')) dao.rename(chatId, clean)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) { /* keep the default title */ }
        }
    }

    private fun terminalInstruction(s: SettingsState): String =
        "Terminal tool: the user can run shell commands from this chat. Backend: " + TerminalEngine.describe(Backend.from(s.termBackend)) +
            " When the user wants to install, download, run or inspect something, work out what they really mean (do not assume fixed commands) " +
            "and reply with a brief explanation plus ONE fenced ```sh block with the exact commands for this backend (non-interactive, use -y). " +
            "To get an AI model file for on-device use, reply with a ```download block whose only content is the https URL. " +
            "After you see a [Terminal output] message, continue the task or confirm it is finished. Never claim a command worked before seeing its output."

    private fun extractBlock(text: String, vararg langs: String): String? {
        for (m in Regex("```(\\w*)\\n([\\s\\S]*?)```").findAll(text)) {
            if (m.groupValues[1].lowercase() in langs) return m.groupValues[2].trim()
        }
        return null
    }

    private suspend fun generate(chatId: Long, depth: Int = 0, forceSpec: String? = null) {
        error.value = null
        streaming.value = null
        loading.value = true
        try {
            val s = settings.state.value
            var order = s.providerOrder()
            val pin = forceSpec ?: dao.chat(chatId)?.providerId
            val pinned = order.firstOrNull { it.id == pin }
            if (pinned != null) order = if (forceSpec != null) listOf(pinned) else listOf(pinned) + order.filter { it !== pinned }
            if (order.isEmpty()) {
                error.value = "Add an API key in Settings to start chatting."
                return
            }
            val app = getApplication<Application>()
            val history = dao.messagesOnce(chatId).map { Turn(it.role, it.content, it.image?.let { ids -> ImageStore.b64All(app, ids) }?.ifBlank { null }) }.let { h -> if (forceSpec != null) h.dropLastWhile { it.role != "user" } else h }
            var base = dao.chat(chatId)?.systemPrompt?.takeIf { it.isNotBlank() } ?: s.systemPrompt
            if (s.replyLang.isNotBlank()) base += "\n\nAlways reply in: " + s.replyLang + "."
            when (s.lengthPreset) {
                "short" -> base += "\n\nKeep answers very short and direct."
                "detailed" -> base += "\n\nGive thorough, detailed answers with examples."
            }
            if (s.userName.isNotBlank()) base += "\n\nThe user's name is " + s.userName + "."
            if (s.aboutMe.isNotBlank()) base += "\n\nAbout the user / custom instructions: " + s.aboutMe
            if (s.terminalTool) base += "\n\n" + terminalInstruction(s)
            val system = withWebSearch(s, history, base)
            var last = "Request failed"
            for (spec in order) {
                streaming.value = null
                try {
                    val reply = runProvider(app, spec, s, system, history) { streaming.value = it }
                    insertAssistant(chatId, reply, spec.name)
                    settings.addUsage(spec.id, (history.sumOf { it.content.length } + system.length) / 4, reply.length / 4)
                    if (s.autoTitle && depth == 0 && !tempChat.value && history.count { it.role == "user" } == 1) {
                        autoTitle(chatId, history.first { it.role == "user" }.content, reply, s)
                    }
                    if (s.terminalTool && depth < 3) {
                        val sh = extractBlock(reply, "sh", "bash", "shell")
                        val dl = extractBlock(reply, "download")
                        if (dl != null && s.termAuto) startDownload(dl)
                        if (sh != null && s.termAuto && !TerminalEngine.isRisky(sh)) {
                            val out = try {
                                val r = TerminalEngine.exec(app, Backend.from(s.termBackend), sh, termCwd, s.githubToken)
                                termCwd = r.cwd ?: termCwd
                                r.output
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                "Error: " + (e.message ?: "failed")
                            }
                            dao.insertMessage(
                                MessageEntity(
                                    chatId = chatId, role = "user", provider = "Terminal", createdAt = System.currentTimeMillis(),
                                    content = "[Terminal output]\n```\n" + out.ifBlank { "(no output)" } + "\n```"
                                )
                            )
                            generate(chatId, depth + 1)
                        }
                    }
                    return
                } catch (e: LlmException) {
                    last = e.message ?: last
                    if (!s.fallback) break
                }
            }
            if (last.contains("network error")) {
                retryPending = true
                error.value = last + " - will retry automatically when you are back online"
            } else {
                error.value = last
            }
        } finally {
            loading.value = false
            streaming.value = null
        }
    }

    // ---------------- chat management ----------------
    fun deleteMessage(id: Long) {
        if (loading.value) return
        viewModelScope.launch { dao.deleteMessage(id) }
    }

    fun toggleStar(m: MessageEntity) {
        viewModelScope.launch { dao.setStarred(m.id, !m.starred) }
    }

    fun editMessage(m: MessageEntity) {
        if (loading.value) return
        viewModelScope.launch {
            dao.deleteFrom(m.chatId, m.id)
            draft.value = m.content
        }
    }

    fun regenerate() {
        val id = currentChatId.value ?: return
        if (loading.value) return
        job = viewModelScope.launch {
            val last = dao.messagesOnce(id).lastOrNull()
            if (last != null && last.role == "assistant") dao.deleteMessage(last.id)
            generate(id)
        }
    }

    fun duplicateChat(chat: ChatEntity) {
        viewModelScope.launch {
            val newId = dao.insertChat(
                ChatEntity(title = chat.title + " (copy)", updatedAt = System.currentTimeMillis(), systemPrompt = chat.systemPrompt)
            )
            dao.messagesOnce(chat.id).forEach { dao.insertMessage(it.copy(id = 0, chatId = newId)) }
        }
    }

    fun setChatTag(id: Long, tag: String) {
        viewModelScope.launch { dao.setTag(id, tag.trim().ifBlank { null }) }
    }

    fun setChatProvider(id: Long, providerId: String?) {
        viewModelScope.launch { dao.setProvider(id, providerId) }
    }

    /** Sends the same conversation to a different model and adds its answer (compare models). */
    fun askAnother(providerId: String) {
        val id = currentChatId.value ?: return
        if (loading.value) return
        job = viewModelScope.launch { generate(id, 0, providerId) }
    }

    fun clearChat(id: Long) {
        viewModelScope.launch { dao.clearMessages(id) }
    }

    fun renameChat(id: Long, title: String) {
        viewModelScope.launch { dao.rename(id, title.trim().take(60)) }
    }

    fun togglePin(chat: ChatEntity) {
        viewModelScope.launch { dao.setPinned(chat.id, !chat.pinned) }
    }

    fun setChatPrompt(id: Long, prompt: String) {
        viewModelScope.launch { dao.setSystemPrompt(id, prompt.trim().ifBlank { null }) }
    }

    fun setTemp(on: Boolean) {
        if (!on) discardTemp()
        tempChat.value = on
    }

    private fun discardTemp() {
        val id = tempId ?: return
        tempId = null
        if (currentChatId.value == id) currentChatId.value = null
        viewModelScope.launch { dao.deleteChat(id) }
    }

    fun newChat() {
        job?.cancel()
        discardTemp()
        currentChatId.value = null
        error.value = null
    }

    fun openChat(id: Long) {
        job?.cancel()
        if (id != tempId) discardTemp()
        currentChatId.value = id
        error.value = null
    }

    fun deleteChat(id: Long) {
        viewModelScope.launch {
            if (currentChatId.value == id) newChat()
            dao.deleteChat(id)
        }
    }

    fun deleteAll() {
        viewModelScope.launch {
            newChat()
            dao.deleteAll()
            ImageStore.clear(getApplication<Application>())
        }
    }

    // ---------------- local model: import + download ----------------
    fun importModel(uri: Uri) {
        if (modelStatus.value.startsWith("Importing")) return
        viewModelScope.launch {
            val app = getApplication<Application>()
            try {
                modelStatus.value = "Importing... keep the app open"
                val path = withContext(Dispatchers.IO) {
                    var size = -1L
                    app.contentResolver.query(uri, null, null, null, null)?.use { c ->
                        val i = c.getColumnIndex(OpenableColumns.SIZE)
                        if (i >= 0 && c.moveToFirst()) size = c.getLong(i)
                    }
                    if (size > 0 && app.filesDir.usableSpace < size + 200L * 1024 * 1024) {
                        throw java.io.IOException("Not enough free storage (need about " + (size / 1048576) + " MB)")
                    }
                    val tmp = File(app.filesDir, "model.tmp")
                    val dest = File(app.filesDir, "model.task")
                    val input = app.contentResolver.openInputStream(uri) ?: throw java.io.IOException("Cannot open that file")
                    input.use { i ->
                        tmp.outputStream().use { o ->
                            val buf = ByteArray(1 shl 20)
                            var done = 0L
                            var last = 0L
                            while (true) {
                                val n = i.read(buf)
                                if (n < 0) break
                                o.write(buf, 0, n)
                                done += n
                                if (done - last > 50L * 1024 * 1024) {
                                    last = done
                                    modelStatus.value = "Importing... " + (done / 1048576) + (if (size > 0) " / " + (size / 1048576) else "") + " MB"
                                }
                            }
                        }
                    }
                    if (dest.exists()) dest.delete()
                    if (!tmp.renameTo(dest)) throw java.io.IOException("Could not save the model")
                    dest.absolutePath
                }
                settings.setModelPath(path)
                modelStatus.value = "Model ready"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                modelStatus.value = "Import failed: " + (e.message ?: e.javaClass.simpleName)
            }
        }
    }

    fun startDownload(url: String) {
        val u = url.trim()
        if (!u.startsWith("https://")) { downloadStatus.value = "Only https:// links are allowed"; return }
        if (downloadStatus.value.startsWith("Downloading")) return
        viewModelScope.launch {
            try {
                downloadStatus.value = "Downloading..."
                val f = ModelDownloader.download(getApplication<Application>(), u, settings.state.value.hfToken) { done, total ->
                    downloadStatus.value = "Downloading " + (done / 1048576) + (if (total > 0) " / " + (total / 1048576) else "") + " MB"
                }
                settings.setModelPath(f.absolutePath)
                downloadStatus.value = "Model ready (" + (f.length() / 1048576) + " MB). Set it as primary in Settings."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                downloadStatus.value = "Download failed: " + (e.message ?: e.javaClass.simpleName)
            }
        }
    }

    // ---------------- backup / policy ----------------
    suspend fun exportBackup(pass: String = ""): Uri = withContext(Dispatchers.IO) {
        val app = getApplication<Application>()
        val msgs = dao.allMessages().groupBy { it.chatId }
        val arr = JSONArray()
        dao.allChats().forEach { c ->
            val ma = JSONArray()
            msgs[c.id].orEmpty().forEach { m ->
                ma.put(
                    JSONObject().put("role", m.role).put("content", m.content)
                        .put("provider", m.provider ?: JSONObject.NULL).put("createdAt", m.createdAt)
                )
            }
            arr.put(
                JSONObject().put("title", c.title).put("updatedAt", c.updatedAt).put("pinned", c.pinned)
                    .put("systemPrompt", c.systemPrompt ?: JSONObject.NULL).put("messages", ma)
            )
        }
        val dir = File(app.cacheDir, "exports").apply { mkdirs() }
        val plain = JSONObject().put("version", 1).put("chats", arr).toString().toByteArray(Charsets.UTF_8)
        val f = File(dir, if (pass.isBlank()) "allrounder-backup.json" else "allrounder-backup.afbak")
        f.writeBytes(if (pass.isBlank()) plain else BackupCrypto.encrypt(plain, pass.toCharArray()))
        FileProvider.getUriForFile(app, app.packageName + ".fileprovider", f)
    }

    suspend fun importBackup(uri: Uri, pass: String = ""): Int = withContext(Dispatchers.IO) {
        val raw = getApplication<Application>().contentResolver.openInputStream(uri)
            ?.use { it.readBytes() } ?: return@withContext 0
        val bytes = if (BackupCrypto.isEncrypted(raw)) {
            if (pass.isBlank()) throw IllegalArgumentException("Passphrase needed")
            BackupCrypto.decrypt(raw, pass.toCharArray())
        } else raw
        val arr = JSONObject(String(bytes, Charsets.UTF_8)).getJSONArray("chats")
        var n = 0
        for (i in 0 until arr.length()) {
            val c = arr.getJSONObject(i)
            val id = dao.insertChat(
                ChatEntity(
                    title = c.optString("title", "Imported chat"),
                    updatedAt = c.optLong("updatedAt", System.currentTimeMillis()),
                    pinned = c.optBoolean("pinned"),
                    systemPrompt = if (c.isNull("systemPrompt")) null else c.optString("systemPrompt")
                )
            )
            val ms = c.getJSONArray("messages")
            for (j in 0 until ms.length()) {
                val m = ms.getJSONObject(j)
                dao.insertMessage(
                    MessageEntity(
                        chatId = id, role = m.getString("role"), content = m.optString("content"),
                        provider = if (m.isNull("provider")) null else m.optString("provider"),
                        createdAt = m.optLong("createdAt")
                    )
                )
            }
            n++
        }
        n
    }

    /** Publishes the bundled privacy policy page to the developer's own GitHub Pages (gives the URL Play Console needs). */
    fun publishPolicy() {
        val token = settings.state.value.githubToken
        if (token.isBlank()) { policyStatus.value = "Add your GitHub token first (GitHub hosting card)."; return }
        viewModelScope.launch {
            try {
                policyStatus.value = "Publishing..."
                val api = GitHubApi(token)
                val owner = api.login()
                val repo = "allrounder-privacy"
                api.createRepo(repo)
                val page = getApplication<Application>().assets.open("privacy-policy.html").bufferedReader().readText()
                api.putFile(owner, repo, GenFile("index.html", page))
                api.enablePages(owner, repo)
                policyStatus.value = "https://$owner.github.io/$repo/\nLive in 1-2 minutes. Paste this URL in Play Console and strings.xml (privacy_url)."
            } catch (e: GitHubException) {
                policyStatus.value = e.message ?: "Failed"
            }
        }
    }
}
