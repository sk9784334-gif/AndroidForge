
package com.allrounder.ai.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class RunEntry(val lang: String, val code: String, val output: String, val time: Long)

/** Last 20 Code runner runs, kept in app-private storage. */
object RunHistory {
    private fun file(ctx: Context) = File(ctx.filesDir, "run_history.json")

    fun list(ctx: Context): List<RunEntry> = try {
        val a = JSONArray(file(ctx).takeIf { it.exists() }?.readText() ?: "[]")
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            RunEntry(o.getString("lang"), o.getString("code"), o.optString("output"), o.optLong("time"))
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun add(ctx: Context, e: RunEntry) {
        try {
            val all = (listOf(e) + list(ctx)).take(20)
            val a = JSONArray()
            all.forEach { a.put(JSONObject().put("lang", it.lang).put("code", it.code).put("output", it.output).put("time", it.time)) }
            file(ctx).writeText(a.toString())
        } catch (ex: Exception) { /* history is best-effort */ }
    }
}
