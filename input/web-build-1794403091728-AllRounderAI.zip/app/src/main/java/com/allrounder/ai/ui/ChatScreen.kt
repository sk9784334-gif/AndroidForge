
@file:OptIn(ExperimentalMaterial3Api::class)

package com.allrounder.ai.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.os.Handler
import android.os.Looper
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.allrounder.ai.ChatViewModel
import com.allrounder.ai.R
import com.allrounder.ai.data.ChatEntity
import com.allrounder.ai.data.ImageStore
import com.allrounder.ai.data.ImageUtil
import com.allrounder.ai.data.MessageEntity
import com.allrounder.ai.data.SettingsState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

private class MsgActions(
    val onDelete: (Long) -> Unit,
    val onEdit: (MessageEntity) -> Unit,
    val onRegenerate: () -> Unit,
    val onStar: (MessageEntity) -> Unit,
    val onSpeak: (String) -> Unit,
    val providers: List<Pair<String, String>>,
    val onAsk: (String) -> Unit
)

private fun greeting(name: String, hi: Boolean = false): String {
    val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    val g = when (h) {
        in 5..11 -> if (hi) "सुप्रभात" else "Good morning"
        in 12..16 -> if (hi) "नमस्कार" else "Good afternoon"
        in 17..20 -> if (hi) "शुभ संध्या" else "Good evening"
        else -> if (hi) "नमस्ते" else "Hello, night owl"
    }
    return if (name.isNotBlank()) (if (h in 5..20) "$g, $name" else (if (hi) "नमस्ते, $name" else "Hello, $name")) else g
}

@Composable
fun Avatar(name: String, size: androidx.compose.ui.unit.Dp, onClick: (() -> Unit)? = null) {
    val initials = name.trim().split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.take(1).uppercase() }.ifBlank { "U" }
    Box(
        Modifier.size(size).clip(CircleShape).background(MaterialTheme.colorScheme.primary)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Text(initials, color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ChatScreen(vm: ChatViewModel, onNavigate: (String) -> Unit) {
    val messages by vm.messages.collectAsState()
    val chats by vm.chats.collectAsState()
    val loading by vm.loading.collectAsState()
    val streaming by vm.streaming.collectAsState()
    val draft by vm.draft.collectAsState()
    val error by vm.error.collectAsState()
    val currentId by vm.currentChatId.collectAsState()
    val temp by vm.tempChat.collectAsState()
    val dl by vm.downloadStatus.collectAsState()
    val settings by vm.settings.state.collectAsState()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val view = LocalView.current
    SideEffect { view.keepScreenOn = loading }
    var modelMenu by remember { mutableStateOf(false) }
    var tagFilter by remember { mutableStateOf<String?>(null) }
    val tags = chats.mapNotNull { it.tag }.distinct()
    var topMenu by remember { mutableStateOf(false) }

    var voiceMode by remember { mutableStateOf(false) }
    var listenTick by remember { mutableStateOf(0) }
    val voiceRef = rememberUpdatedState(voiceMode)
    val tts = remember { arrayOfNulls<TextToSpeech>(1) }
    DisposableEffect(Unit) {
        tts[0] = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts[0]?.language = Locale.getDefault()
                tts[0]?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onError(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        if (utteranceId == "voice" && voiceRef.value) Handler(Looper.getMainLooper()).post { listenTick++ }
                    }
                })
            }
        }
        onDispose { tts[0]?.shutdown() }
    }
    val lastMsg = messages.lastOrNull()
    LaunchedEffect(lastMsg?.id, loading) {
        if (voiceMode && !loading && lastMsg != null && lastMsg.role == "assistant") {
            tts[0]?.speak(lastMsg.content.replace(Regex("```[\\s\\S]*?```"), " code block ").take(3500), TextToSpeech.QUEUE_FLUSH, null, "voice")
        }
    }
    val provIds = settings.providerOrder().map { it.id }
    val clipboard = LocalClipboardManager.current
    val actions = remember(vm, provIds) {
        MsgActions(
            onDelete = { vm.deleteMessage(it) },
            onEdit = { vm.editMessage(it) },
            onRegenerate = { vm.regenerate() },
            onStar = { vm.toggleStar(it) },
            onSpeak = { tts[0]?.speak(it.take(3500), TextToSpeech.QUEUE_FLUSH, null, "af") },
            providers = settings.providerOrder().map { it.id to it.name },
            onAsk = { vm.askAnother(it) }
        )
    }

    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }
    val close: () -> Unit = { scope.launch { drawerState.close() } }

    val wide = LocalConfiguration.current.screenWidthDp >= 840
    val drawerBody: @Composable ColumnScope.() -> Unit = {
                Row(Modifier.padding(start = 24.dp, end = 16.dp, top = 16.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("AllRounder AI", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    IconButton(
                        onClick = { close(); onNavigate("search") },
                        modifier = Modifier.background(MaterialTheme.colorScheme.surfaceContainerHigh, CircleShape)
                    ) { Icon(Icons.Default.Search, contentDescription = "Search") }
                }
                val nav = listOf(
                    Triple("\uD83D\uDDBC", "Images", "images"),
                    Triple("\uD83D\uDCDA", "Library", "library"),
                    Triple("\uD83D\uDCC1", "Projects", "projects"),
                    Triple("\uD83D\uDCBB", "Terminal", "terminal"),
                    Triple("\uD83E\uDDE9", "Plugins", "plugins"),
                    Triple("\uD83C\uDF10", "Web builder", "web"),
                    Triple("\uD83D\uDCF1", "App builder", "app"),
                    Triple("\u25B6", "Code runner", "run"),
                    Triple("\u23F0", "Scheduled", "scheduled")
                )
                LazyColumn(Modifier.weight(1f)) {
                    items(nav) { (emoji, label, route) ->
                        NavigationDrawerItem(
                            label = { Text(tr(label), style = MaterialTheme.typography.titleMedium) },
                            icon = { Text(emoji, fontSize = 20.sp) },
                            selected = false,
                            onClick = { close(); onNavigate(route) },
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                    }
                    item { HorizontalDivider(Modifier.padding(horizontal = 24.dp, vertical = 8.dp)) }
                    if (tags.isNotEmpty()) item {
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(selected = tagFilter == null, onClick = { tagFilter = null }, label = { Text(tr("All")) })
                            tags.forEach { t -> FilterChip(selected = tagFilter == t, onClick = { tagFilter = t }, label = { Text(t) }) }
                        }
                    }
                    if (chats.isEmpty()) item {
                        Text(
                            "No chats yet", color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                        )
                    }
                    items(chats.filter { tagFilter == null || it.tag == tagFilter }.take(10), key = { it.id }) { chat ->
                        NavigationDrawerItem(
                            label = { Text((if (chat.pinned) "\uD83D\uDCCC " else "") + chat.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            selected = chat.id == currentId,
                            onClick = { vm.openChat(chat.id); close() },
                            badge = { ChatMenu(chat, vm) },
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                    }
                    if (chats.size > 10) item {
                        TextButton(onClick = { close(); onNavigate("search") }, modifier = Modifier.padding(horizontal = 12.dp)) {
                            Text("See all\u2026")
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = { vm.newChat(); close() },
                        shape = RoundedCornerShape(28.dp),
                        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 14.dp)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(tr("Chat"), fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.weight(1f))
                    Avatar(settings.userName, 48.dp) { close(); onNavigate("profile") }
                }
    }
    val screenBody: @Composable () -> Unit = {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { scope.launch { drawerState.open() } }) {
                        Icon(Icons.Default.Menu, contentDescription = "Open menu")
                    }
                    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        if (messages.isNotEmpty() || temp) {
                            Surface(
                                onClick = { modelMenu = true },
                                shape = RoundedCornerShape(20.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    (if (temp) "Temporary \u2022 " else "") +
                                        (settings.providerOrder().firstOrNull()?.name ?: "No provider") + " \u25BE",
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                    style = MaterialTheme.typography.labelLarge,
                                    maxLines = 1
                                )
                            }
                        }
                        DropdownMenu(expanded = modelMenu, onDismissRequest = { modelMenu = false }) {
                            settings.providerOrder().forEach { spec ->
                                DropdownMenuItem(
                                    text = { Text(spec.name) },
                                    onClick = { vm.settings.setPreferred(spec.id); modelMenu = false }
                                )
                            }
                        }
                    }
                    if (messages.isNotEmpty()) Box {
                        IconButton(onClick = { topMenu = true }) { Icon(Icons.Default.MoreVert, contentDescription = "Chat menu") }
                        DropdownMenu(expanded = topMenu, onDismissRequest = { topMenu = false }) {
                            DropdownMenuItem(text = { Text(tr("Share chat")) }, onClick = { topMenu = false; shareChat(ctx, messages) })
                            DropdownMenuItem(text = { Text(tr("Export as PDF")) }, onClick = {
                                topMenu = false
                                exportPdf(ctx, chats.firstOrNull { it.id == currentId }?.title ?: "chat", messages)
                            })
                            DropdownMenuItem(text = { Text(tr("Export as Markdown")) }, onClick = {
                                topMenu = false
                                exportMarkdown(ctx, chats.firstOrNull { it.id == currentId }?.title ?: "chat", messages)
                            })
                        }
                    }
                    IconButton(
                        onClick = { vm.setTemp(!temp); if (!temp) vm.newChat() },
                        modifier = if (temp) Modifier.background(MaterialTheme.colorScheme.primaryContainer, CircleShape) else Modifier
                    ) { Text("\uD83D\uDC7B", fontSize = 20.sp) }
                }
            }
        ) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding()) {
                if (dl.isNotEmpty()) Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp).fillMaxWidth()
                ) {
                    Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(dl, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        if (!dl.startsWith("Downloading")) TextButton(onClick = { vm.downloadStatus.value = "" }) { Text("OK") }
                    }
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    if (messages.isEmpty() && !loading) {
                        EmptyHome(
                            st = settings,
                            temp = temp,
                            onSuggestion = { vm.send(it) },
                            onSettings = { onNavigate("settings") },
                            onModelClick = { modelMenu = true },
                            onPaste = { clipboard.getText()?.text?.takeIf { it.isNotBlank() }?.let { vm.draft.value = it.take(4000) } }
                        )
                    } else {
                        MessageList(messages, loading, streaming, actions)
                    }
                }
                error?.let {
                    ErrorBanner(
                        message = it,
                        canRetry = messages.isNotEmpty() && settings.hasKey,
                        onRetry = { vm.retry() },
                        onDismiss = { vm.error.value = null },
                        onSettings = { onNavigate("settings") }
                    )
                }
                InputPill(
                    loading = loading,
                    onSend = { t, img -> vm.send(t, img) },
                    onStop = { vm.stop() },
                    prompts = settings.prompts,
                    draft = draft,
                    onDraftUsed = { vm.draft.value = null },
                    voiceMode = voiceMode,
                    listenTick = listenTick,
                    onVoiceToggle = { voiceMode = !voiceMode; if (voiceMode) listenTick++ else tts[0]?.stop() }
                )
                Text(
                    tr("AI can make mistakes. Check important information."),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
    if (wide) {
        PermanentNavigationDrawer(
            drawerContent = { PermanentDrawerSheet(Modifier.width(320.dp), content = drawerBody) },
            content = screenBody
        )
    } else {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = { ModalDrawerSheet(content = drawerBody) },
            content = screenBody
        )
    }
}

@Composable
private fun EmptyHome(
    st: SettingsState, temp: Boolean,
    onSuggestion: (String) -> Unit, onSettings: () -> Unit, onModelClick: () -> Unit, onPaste: () -> Unit
) {
    val suggestions = listOf(
        "Explain quantum computing in simple words",
        "Install Python and check the version",
        "Write a polite email asking for a deadline extension",
        "Help me debug a Kotlin coroutine issue"
    )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        LogoMark(64.dp)
        Spacer(Modifier.height(20.dp))
        Text(
            if (temp) "Temporary chat" else greeting(st.userName, LocalUiHi.current),
            style = MaterialTheme.typography.headlineMedium,
            fontFamily = FontFamily.Serif,
            textAlign = TextAlign.Center
        )
        if (temp) {
            Spacer(Modifier.height(6.dp))
            Text(
                "Not saved to history. It is deleted when you leave this chat.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
        Spacer(Modifier.height(20.dp))
        val first = st.providerOrder().firstOrNull()
        Surface(
            onClick = { if (first != null) onModelClick() else onSettings() },
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Text(
                if (first != null) first.name + " \u00B7 " + st.modelFor(first) + " \u25BE" else "Add an API key \u2192",
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                style = MaterialTheme.typography.bodyLarge
            )
        }
        Spacer(Modifier.height(24.dp))
        if (first != null) {
            TextButton(onClick = onPaste) { Text("\uD83D\uDCCB Ask about what I copied") }
            suggestions.forEach {
                OutlinedButton(
                    onClick = { onSuggestion(it) },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) { Text(it, maxLines = 2, overflow = TextOverflow.Ellipsis) }
            }
        }
    }
}

@Composable
private fun MessageList(messages: List<MessageEntity>, loading: Boolean, streaming: String?, actions: MsgActions) {
    val state = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val total = messages.size + if (loading) 1 else 0
    val bucket = (streaming?.length ?: 0) / 40
    LaunchedEffect(total, bucket) {
        if (total > 0) {
            state.scrollToItem(total - 1)
            state.scrollBy(100000f)
        }
    }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            state = state,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(messages, key = { it.id }) { m ->
                MessageBubble(m, isLast = m.id == messages.lastOrNull()?.id, loading = loading, actions = actions)
            }
            if (loading) item(key = "typing") {
                if (!streaming.isNullOrEmpty()) StreamingBubble(streaming) else TypingBubble()
            }
        }
        val atBottom by remember { derivedStateOf { !state.canScrollForward } }
        if (!atBottom && total > 0) {
            SmallFloatingActionButton(
                onClick = { scope.launch { state.animateScrollToItem(total - 1) } },
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
            ) { Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Scroll to bottom") }
        }
    }
}

@Composable
private fun StreamingBubble(text: String) {
    Row(Modifier.fillMaxWidth()) {
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = MaterialTheme.colorScheme.onSurface,
            shape = RoundedCornerShape(20.dp, 20.dp, 20.dp, 4.dp),
            modifier = Modifier.widthIn(max = 340.dp)
        ) {
            Box(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) { RichText(text) }
        }
    }
}

@Composable
private fun MessageBubble(msg: MessageEntity, isLast: Boolean, loading: Boolean, actions: MsgActions) {
    val isUser = msg.role == "user"
    val clipboard = LocalClipboardManager.current
    val ctx = LocalContext.current
    var reporting by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var askDialog by remember { mutableStateOf(false) }
    val time = remember(msg.createdAt) {
        java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(msg.createdAt))
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            contentColor = if (isUser) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
            shape = RoundedCornerShape(
                topStart = 20.dp, topEnd = 20.dp,
                bottomEnd = if (isUser) 4.dp else 20.dp,
                bottomStart = if (isUser) 20.dp else 4.dp
            ),
            modifier = Modifier.widthIn(max = 340.dp)
        ) {
            Column(Modifier.padding(start = 14.dp, end = 6.dp, top = 10.dp, bottom = 0.dp)) {
                msg.image?.split("|")?.filter { it.isNotBlank() }?.forEach { id ->
                    val bmp = remember(id) { ImageStore.bitmap(ctx, id, 2)?.asImageBitmap() }
                    if (bmp != null) Image(
                        bitmap = bmp,
                        contentDescription = "Attached image",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.widthIn(max = 240.dp).padding(bottom = 6.dp, end = 8.dp).clip(RoundedCornerShape(12.dp))
                    )
                }
                if (msg.content.isNotBlank()) Box(Modifier.padding(end = 8.dp)) {
                    SelectionContainer { RichText(msg.content) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        (if (!msg.provider.isNullOrBlank()) msg.provider + "  " else "") + time + (if (msg.starred) "  \u2B50" else ""),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, contentDescription = "Message options") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text(tr("Copy")) }, onClick = { menu = false; clipboard.setText(AnnotatedString(msg.content)) })
                            DropdownMenuItem(text = { Text(if (msg.starred) "Remove star" else "Star (save to Library)") }, onClick = { menu = false; actions.onStar(msg) })
                            DropdownMenuItem(text = { Text(tr("Share as image")) }, onClick = { menu = false; shareAsImage(ctx, msg.content) })
                            if (!isUser) DropdownMenuItem(text = { Text(tr("Read aloud")) }, onClick = { menu = false; actions.onSpeak(msg.content) })
                            if (isUser && msg.provider != "Terminal") DropdownMenuItem(text = { Text(tr("Edit and resend")) }, onClick = { menu = false; actions.onEdit(msg) })
                            if (!isUser && isLast && !loading) DropdownMenuItem(text = { Text(tr("Regenerate")) }, onClick = { menu = false; actions.onRegenerate() })
                            if (!isUser && isLast && !loading) DropdownMenuItem(text = { Text(tr("Ask another model")) }, onClick = { menu = false; askDialog = true })
                            if (!isUser) DropdownMenuItem(text = { Text(tr("Report")) }, onClick = { menu = false; reporting = true })
                            DropdownMenuItem(text = { Text(tr("Delete")) }, onClick = { menu = false; actions.onDelete(msg.id) })
                        }
                    }
                }
                if (askDialog) AlertDialog(
                    onDismissRequest = { askDialog = false },
                    title = { Text(tr("Ask another model")) },
                    text = {
                        Column {
                            actions.providers.forEach { (pid, pname) ->
                                TextButton(onClick = { askDialog = false; actions.onAsk(pid) }) { Text(pname) }
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { askDialog = false }) { Text(tr("Cancel")) } }
                )
                if (reporting) AlertDialog(
                    onDismissRequest = { reporting = false },
                    title = { Text("Report this response") },
                    text = {
                        Column {
                            listOf("Harmful or unsafe", "Inaccurate or misleading", "Hateful or sexual", "Other").forEach { reason ->
                                TextButton(onClick = { reporting = false; sendReport(ctx, reason, msg.content) }) { Text(reason) }
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { reporting = false }) { Text(tr("Cancel")) } }
                )
            }
        }
    }
}

@Composable
private fun TypingBubble() {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(20.dp, 20.dp, 20.dp, 4.dp)
    ) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
            Spacer(Modifier.width(10.dp))
            Text("Thinking\u2026", style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun RichText(text: String) {
    val codeBg = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
    val parts = text.split("```")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        parts.forEachIndexed { index, part ->
            if (index % 2 == 1) CodeBlock(part, codeBg)
            else if (part.isNotBlank()) Markdown(part.trim(), codeBg)
        }
    }
}

@Composable
private fun Markdown(text: String, codeBg: Color) {
    val lines = text.lines()
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        var i = 0
        while (i < lines.size) {
            val line = lines[i].trimEnd()
            if (line.trimStart().startsWith("|")) {
                val rows = ArrayList<String>()
                while (i < lines.size && lines[i].trimStart().startsWith("|")) { rows += lines[i].trim(); i++ }
                val cells = rows.filter { r -> r.replace("|", "").replace("-", "").replace(":", "").isNotBlank() }
                    .map { r -> r.trim('|').split("|").map { it.trim() } }
                if (cells.isNotEmpty()) {
                    val cols = cells.maxOf { it.size }
                    val widths = (0 until cols).map { c -> cells.maxOf { row -> row.getOrNull(c)?.length ?: 0 } }
                    Box(Modifier.horizontalScroll(rememberScrollState())) {
                        Text(
                            cells.joinToString("\n") { row -> row.indices.joinToString("  ") { c -> row[c].padEnd(widths[c]) } },
                            fontFamily = FontFamily.Monospace, fontSize = 12.sp
                        )
                    }
                }
                continue
            }
            when {
                line.isBlank() -> Spacer(Modifier.height(2.dp))
                line.startsWith("### ") -> Text(inline(line.drop(4), codeBg), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                line.startsWith("## ") -> Text(inline(line.drop(3), codeBg), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                line.startsWith("# ") -> Text(inline(line.drop(2), codeBg), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                line.startsWith("- ") || line.startsWith("* ") -> Text(inline("\u2022 " + line.drop(2), codeBg), style = MaterialTheme.typography.bodyLarge)
                else -> Text(inline(line, codeBg), style = MaterialTheme.typography.bodyLarge)
            }
            i++
        }
    }
}

private val KEYWORDS = setOf(
    "fun", "val", "var", "class", "def", "return", "if", "else", "for", "while", "import", "from", "in", "is", "not", "and", "or",
    "new", "public", "private", "static", "void", "int", "string", "let", "const", "function", "async", "await", "try", "catch",
    "except", "finally", "throw", "true", "false", "null", "None", "True", "False", "package", "interface", "object", "when",
    "do", "switch", "case", "break", "continue", "echo", "fi", "then", "done", "fn", "struct", "impl", "use", "mut"
)

private fun highlight(code: String): AnnotatedString = buildAnnotatedString {
    val re = Regex("(//.*|#.*)|(\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*')|\\b(\\d+(?:\\.\\d+)?)\\b|\\b([A-Za-z_][A-Za-z0-9_]*)\\b")
    var last = 0
    for (m in re.findAll(code)) {
        append(code.substring(last, m.range.first))
        val t = m.value
        when {
            m.groups[1] != null -> withStyle(SpanStyle(color = Color(0xFF8D99A6))) { append(t) }
            m.groups[2] != null -> withStyle(SpanStyle(color = Color(0xFF4CAF50))) { append(t) }
            m.groups[3] != null -> withStyle(SpanStyle(color = Color(0xFFFB8C00))) { append(t) }
            t in KEYWORDS -> withStyle(SpanStyle(color = Color(0xFF42A5F5), fontWeight = FontWeight.Bold)) { append(t) }
            else -> append(t)
        }
        last = m.range.last + 1
    }
    append(code.substring(last))
}

@Composable
private fun CodeBlock(part: String, codeBg: Color) {
    val clip = LocalClipboardManager.current
    val openRunner = LocalOpenRunner.current
    val openTerminal = LocalOpenTerminal.current
    val download = LocalDownload.current
    val lang = part.substringBefore('\n', "").trim().lowercase()
    val code = part.substringAfter('\n', part).trimEnd()
    val runLang = langFor(lang)
    val isShell = lang in setOf("sh", "bash", "shell", "zsh")
    Surface(color = codeBg, shape = RoundedCornerShape(10.dp)) {
        Column {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.End) {
                if (lang == "download") TextButton(onClick = { download(code) }) { Text("Download", style = MaterialTheme.typography.labelSmall) }
                if (isShell) TextButton(onClick = { openTerminal(code) }) { Text(tr("Terminal"), style = MaterialTheme.typography.labelSmall) }
                if (runLang != null) TextButton(onClick = { openRunner(runLang, code) }) { Text("Run in cloud", style = MaterialTheme.typography.labelSmall) }
                TextButton(onClick = { clip.setText(AnnotatedString(code)) }) { Text("Copy code", style = MaterialTheme.typography.labelSmall) }
            }
            Box(Modifier.horizontalScroll(rememberScrollState())) {
                Text(
                    if (code.length < 8000) highlight(code) else AnnotatedString(code), fontFamily = FontFamily.Monospace, fontSize = 13.sp,
                    modifier = Modifier.padding(start = 10.dp, end = 10.dp, bottom = 10.dp)
                )
            }
        }
    }
}

private fun inline(text: String, codeBg: Color): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < text.length) {
        if (text.startsWith("**", i)) {
            val e = text.indexOf("**", i + 2)
            if (e > 0) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(text.substring(i + 2, e)) }
                i = e + 2
                continue
            }
        } else if (text[i] == '`') {
            val e = text.indexOf('`', i + 1)
            if (e > 0) {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)) {
                    append(text.substring(i + 1, e))
                }
                i = e + 1
                continue
            }
        } else if (text[i] == '$') {
            val dbl = text.startsWith("\$\$", i)
            val open = if (dbl) 2 else 1
            val e = text.indexOf(if (dbl) "\$\$" else "\$", i + open)
            if (e > i + open && looksMath(text.substring(i + open, e))) {
                withStyle(SpanStyle(fontFamily = FontFamily.Serif, fontStyle = FontStyle.Italic)) {
                    append(texToUnicode(text.substring(i + open, e).trim()))
                }
                i = e + open
                continue
            }
        }
        append(text[i])
        i++
    }
}

@Composable
private fun ErrorBanner(
    message: String, canRetry: Boolean,
    onRetry: () -> Unit, onDismiss: () -> Unit, onSettings: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.errorContainer,
        contentColor = MaterialTheme.colorScheme.onErrorContainer,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(message, style = MaterialTheme.typography.bodyMedium, maxLines = 4, overflow = TextOverflow.Ellipsis)
            Row {
                if (canRetry) TextButton(onClick = onRetry) { Text(tr("Retry")) }
                TextButton(onClick = onSettings) { Text(tr("Settings")) }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onDismiss) { Text(tr("Dismiss")) }
            }
        }
    }
}

@Composable
private fun InputPill(
    loading: Boolean, onSend: (String, String?) -> Unit, onStop: () -> Unit,
    prompts: List<String>, draft: String?, onDraftUsed: () -> Unit,
    voiceMode: Boolean, listenTick: Int, onVoiceToggle: () -> Unit
) {
    var text by remember { mutableStateOf("") }
    var image by remember { mutableStateOf<String?>(null) }
    var file by remember { mutableStateOf<Pair<String, String>?>(null) }
    var plusMenu by remember { mutableStateOf(false) }
    var showPrompts by remember { mutableStateOf(false) }
    var attachError by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    LaunchedEffect(draft) { if (draft != null) { text = draft; onDraftUsed() } }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val said = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && !said.isNullOrBlank()) {
            if (voiceMode) onSend(said, null) else text = (text + " " + said).trim()
        } else if (voiceMode) onVoiceToggle()
    }
    val startSpeech = {
        try {
            speech.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            )
        } catch (e: ActivityNotFoundException) { attachError = "No speech service on this phone" }
    }
    LaunchedEffect(listenTick) { if (listenTick > 0 && voiceMode) startSpeech() }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { ImageUtil.encode(ctx, uri) }.getOrNull() }
            if (r == null) attachError = "Could not read that image" else { image = r; attachError = "" }
        }
    }
    val camUri = remember { mutableStateOf<Uri?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = camUri.value
        if (ok && u != null) scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { ImageUtil.encode(ctx, u) }.getOrNull() }
            if (r == null) attachError = "Could not read the photo" else { image = r; attachError = "" }
        }
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val isPdf = runCatching { ctx.contentResolver.getType(uri) == "application/pdf" }.getOrDefault(false)
            if (isPdf) {
                val r = withContext(Dispatchers.IO) { runCatching { ImageUtil.pdfPages(ctx, uri) }.getOrNull() }
                if (r == null) attachError = "Could not read that PDF" else { image = r; attachError = "" }
            } else {
                val r = withContext(Dispatchers.IO) { runCatching { readTextFile(ctx, uri) }.getOrNull() }
                if (r == null) attachError = "Only text, code and PDF files can be attached" else { file = r; attachError = "" }
            }
        }
    }
    val preview = remember(image) { image?.substringBefore("|")?.let { ImageUtil.decode(it)?.asImageBitmap() } }
    val imageCount = image?.split("|")?.size ?: 0

    if (showPrompts) AlertDialog(
        onDismissRequest = { showPrompts = false },
        title = { Text(tr("Prompt library")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                prompts.forEach { p ->
                    TextButton(onClick = { text = (text + " " + p).trim(); showPrompts = false }) { Text(p) }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showPrompts = false }) { Text(tr("Close")) } }
    )

    Surface(
        shape = RoundedCornerShape(32.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        tonalElevation = 2.dp,
        shadowElevation = 2.dp,
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp).fillMaxWidth()
    ) {
        Column(Modifier.padding(6.dp)) {
            file?.let { f ->
                Row(Modifier.padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("\uD83D\uDCC4 " + f.first, Modifier.weight(1f, fill = false), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    TextButton(onClick = { file = null }) { Text(tr("Remove")) }
                }
            }
            if (preview != null) {
                Row(Modifier.padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        bitmap = preview, contentDescription = "Attached image", contentScale = ContentScale.Crop,
                        modifier = Modifier.size(56.dp).clip(RoundedCornerShape(10.dp))
                    )
                    if (imageCount > 1) Text("$imageCount pages", Modifier.padding(start = 8.dp))
                    TextButton(onClick = { image = null }) { Text(tr("Remove")) }
                }
            }
            if (attachError.isNotEmpty()) Text(
                attachError, color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 14.dp)
            )
            if (text.length > 200) Text(
                "~" + (text.length / 4) + " tokens",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.align(Alignment.End).padding(end = 16.dp)
            )
            Row(verticalAlignment = Alignment.Bottom) {
                Box {
                    FilledTonalIconButton(onClick = { plusMenu = true }) { Icon(Icons.Default.Add, contentDescription = "Attach") }
                    DropdownMenu(expanded = plusMenu, onDismissRequest = { plusMenu = false }) {
                        DropdownMenuItem(text = { Text(tr("Camera")) }, onClick = {
                            plusMenu = false
                            try {
                                val f = File(File(ctx.cacheDir, "exports").apply { mkdirs() }, "camera.jpg")
                                val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                                camUri.value = u
                                camera.launch(u)
                            } catch (e: Exception) { attachError = "Camera not available" }
                        })
                        DropdownMenuItem(text = { Text(tr("Photo")) }, onClick = {
                            plusMenu = false
                            photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        })
                        DropdownMenuItem(text = { Text(tr("File or PDF")) }, onClick = {
                            plusMenu = false
                            filePicker.launch(arrayOf("text/*", "application/json", "application/xml", "application/javascript", "application/pdf"))
                        })
                        DropdownMenuItem(text = { Text(tr("Prompt library")) }, onClick = { plusMenu = false; showPrompts = true })
                    }
                }
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text(tr("Message, or \$ command")) },
                    maxLines = 6,
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent, unfocusedBorderColor = Color.Transparent,
                        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent
                    ),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
                )
                FilledTonalIconButton(onClick = {
                    try {
                        speech.launch(
                            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        )
                    } catch (e: ActivityNotFoundException) { attachError = "No speech service on this phone" }
                }) { Text("\uD83C\uDFA4") }
                FilledTonalIconButton(
                    onClick = onVoiceToggle,
                    colors = if (voiceMode) IconButtonDefaults.filledTonalIconButtonColors(containerColor = MaterialTheme.colorScheme.primary)
                    else IconButtonDefaults.filledTonalIconButtonColors()
                ) { Text("\uD83C\uDFA7") }
                Spacer(Modifier.width(6.dp))
                FilledIconButton(
                    onClick = {
                        if (loading) onStop() else {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            val attached = file?.let { f -> "\n\n[Attached file: " + f.first + "]\n```\n" + f.second + "\n```" } ?: ""
                            onSend(text + attached, image)
                            text = ""; image = null; file = null; attachError = ""
                        }
                    },
                    enabled = loading || text.isNotBlank() || image != null || file != null
                ) {
                    if (loading) Icon(Icons.Default.Close, contentDescription = "Stop")
                    else Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
                }
            }
        }
    }
}

private fun shareChat(ctx: Context, messages: List<MessageEntity>) {
    val text = messages.joinToString("\n\n") { (if (it.role == "user") "You: " else "AI: ") + it.content }
    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
    ctx.startActivity(Intent.createChooser(send, "Share chat"))
}

private fun exportMarkdown(ctx: Context, title: String, messages: List<MessageEntity>) {
    try {
        val md = "# " + title + "\n\n" + messages.joinToString("\n\n") {
            "**" + (if (it.role == "user") "You" else (it.provider ?: "AI")) + ":**\n\n" + it.content
        }
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val f = File(dir, title.replace(Regex("[^A-Za-z0-9_-]"), "_").take(40).ifBlank { "chat" } + ".md")
        f.writeText(md)
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
        val send = Intent(Intent.ACTION_SEND).setType("text/markdown")
            .putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, "Export chat"))
    } catch (e: Exception) { /* nothing to export */ }
}

private fun sendReport(ctx: Context, reason: String, content: String) {
    val mail = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
        .putExtra(Intent.EXTRA_EMAIL, arrayOf(ctx.getString(R.string.support_email)))
        .putExtra(Intent.EXTRA_SUBJECT, "AI content report: $reason")
        .putExtra(Intent.EXTRA_TEXT, "Reason: $reason\n\nResponse:\n" + content.take(3000))
    try { ctx.startActivity(mail) } catch (e: ActivityNotFoundException) { /* no mail app installed */ }
}

/** Reads a small plain-text/code file (max 60k chars). Returns name to content, or null for binary files. */
private fun readTextFile(ctx: Context, uri: Uri): Pair<String, String>? = try {
    var name = "file"
    ctx.contentResolver.query(uri, null, null, null, null)?.use { cur ->
        val idx = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (idx >= 0 && cur.moveToFirst()) name = cur.getString(idx) ?: name
    }
    val body = ctx.contentResolver.openInputStream(uri)?.reader()?.use { r ->
        val buf = CharArray(60_000)
        val n = r.read(buf)
        if (n <= 0) "" else String(buf, 0, n)
    }
    if (body == null || body.contains('\u0000')) null else name to body
} catch (e: Throwable) {
    null
}

@Composable
private fun ChatMenu(chat: ChatEntity, vm: ChatViewModel) {
    var open by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf("") }
    var field by remember { mutableStateOf("") }
    IconButton(onClick = { open = true }) { Icon(Icons.Default.MoreVert, contentDescription = "Chat options") }
    DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
        DropdownMenuItem(text = { Text(if (chat.pinned) "Unpin" else "Pin") }, onClick = { open = false; vm.togglePin(chat) })
        DropdownMenuItem(text = { Text(tr("Rename")) }, onClick = { open = false; field = chat.title; dialog = "rename" })
        DropdownMenuItem(text = { Text(tr("Chat instructions")) }, onClick = { open = false; field = chat.systemPrompt.orEmpty(); dialog = "prompt" })
        DropdownMenuItem(text = { Text(tr("Folder / tag")) }, onClick = { open = false; field = chat.tag.orEmpty(); dialog = "tag" })
        DropdownMenuItem(text = { Text(tr("Model for this chat")) }, onClick = { open = false; dialog = "model" })
        DropdownMenuItem(text = { Text(tr("Duplicate")) }, onClick = { open = false; vm.duplicateChat(chat) })
        DropdownMenuItem(text = { Text(tr("Clear messages")) }, onClick = { open = false; vm.clearChat(chat.id) })
        DropdownMenuItem(text = { Text(tr("Delete")) }, onClick = { open = false; vm.deleteChat(chat.id) })
    }
    val chatSettings by vm.settings.state.collectAsState()
    if (dialog == "model") AlertDialog(
        onDismissRequest = { dialog = "" },
        title = { Text(tr("Model for this chat")) },
        text = {
            Column {
                TextButton(onClick = { vm.setChatProvider(chat.id, null); dialog = "" }) {
                    Text((if (chat.providerId == null) "\u2713 " else "") + "Default (primary model)")
                }
                chatSettings.providerOrder().forEach { spec ->
                    TextButton(onClick = { vm.setChatProvider(chat.id, spec.id); dialog = "" }) {
                        Text((if (chat.providerId == spec.id) "\u2713 " else "") + spec.name)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { dialog = "" }) { Text(tr("Close")) } }
    )
    if (dialog == "rename" || dialog == "prompt" || dialog == "tag") AlertDialog(
        onDismissRequest = { dialog = "" },
        title = { Text(when (dialog) { "rename" -> "Rename chat"; "tag" -> "Folder / tag"; else -> "Chat instructions" }) },
        text = {
            OutlinedTextField(
                value = field, onValueChange = { field = it },
                modifier = Modifier.fillMaxWidth(),
                minLines = if (dialog == "prompt") 3 else 1,
                label = { Text(when (dialog) { "prompt" -> "Custom system prompt (empty = default)"; "tag" -> "Folder or tag name (empty = none)"; else -> "Title" }) }
            )
        },
        confirmButton = {
            TextButton(onClick = {
                when (dialog) {
                    "rename" -> if (field.isNotBlank()) vm.renameChat(chat.id, field)
                    "tag" -> vm.setChatTag(chat.id, field)
                    else -> vm.setChatPrompt(chat.id, field)
                }
                dialog = ""
            }) { Text(tr("Save")) }
        },
        dismissButton = { TextButton(onClick = { dialog = "" }) { Text(tr("Cancel")) } }
    )
}

private fun shareFile(ctx: Context, file: File, mime: String, chooser: String) {
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
    val send = Intent(Intent.ACTION_SEND).setType(mime)
        .putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(send, chooser))
}

private fun exportPdf(ctx: Context, title: String, messages: List<MessageEntity>) {
    try {
        val doc = android.graphics.pdf.PdfDocument()
        val paint = android.text.TextPaint().apply { textSize = 11f; color = android.graphics.Color.BLACK; isAntiAlias = true }
        val w = 595
        val h = 842
        val margin = 40
        val text = title + "\n\n" + messages.joinToString("\n\n") { (if (it.role == "user") "You: " else "AI: ") + it.content }
        val layout = android.text.StaticLayout.Builder.obtain(text, 0, text.length, paint, w - 2 * margin).build()
        var page = 0
        var lineIdx = 0
        while (lineIdx < layout.lineCount) {
            val info = android.graphics.pdf.PdfDocument.PageInfo.Builder(w, h, ++page).create()
            val p = doc.startPage(info)
            val top = layout.getLineTop(lineIdx)
            var end = lineIdx
            while (end < layout.lineCount && layout.getLineBottom(end) - top <= h - 2 * margin) end++
            if (end == lineIdx) end = lineIdx + 1
            val c = p.canvas
            c.save()
            c.translate(margin.toFloat(), margin.toFloat() - top)
            c.clipRect(0f, top.toFloat(), (w - 2 * margin).toFloat(), layout.getLineBottom(end - 1).toFloat())
            layout.draw(c)
            c.restore()
            doc.finishPage(p)
            lineIdx = end
        }
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val f = File(dir, title.replace(Regex("[^A-Za-z0-9_-]"), "_").take(40).ifBlank { "chat" } + ".pdf")
        f.outputStream().use { doc.writeTo(it) }
        doc.close()
        shareFile(ctx, f, "application/pdf", "Export chat")
    } catch (e: Exception) { /* nothing to export */ }
}

private fun shareAsImage(ctx: Context, text: String) {
    try {
        val width = 1080
        val pad = 64
        val tp = android.text.TextPaint().apply { textSize = 42f; color = android.graphics.Color.WHITE; isAntiAlias = true }
        val body = text.take(1800)
        val layout = android.text.StaticLayout.Builder.obtain(body, 0, body.length, tp, width - 2 * pad).build()
        val h = layout.height + 2 * pad + 80
        val bmp = android.graphics.Bitmap.createBitmap(width, h, android.graphics.Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(bmp)
        c.drawColor(0xFF0B1020.toInt())
        c.save()
        c.translate(pad.toFloat(), pad.toFloat())
        layout.draw(c)
        c.restore()
        val sp = android.text.TextPaint().apply { textSize = 30f; color = 0xFF8B7CFF.toInt(); isAntiAlias = true }
        c.drawText("AllRounder AI", pad.toFloat(), (h - 40).toFloat(), sp)
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val f = File(dir, "share.png")
        f.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
        shareFile(ctx, f, "image/png", "Share reply")
    } catch (e: Exception) { /* could not render */ }
}
