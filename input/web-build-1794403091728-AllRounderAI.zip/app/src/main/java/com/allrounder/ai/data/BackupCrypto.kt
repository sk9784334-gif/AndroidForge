
package com.allrounder.ai.data

import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Passphrase-encrypted backups: AES-256-GCM with a PBKDF2 key. File layout: magic | salt(16) | iv(12) | ciphertext. */
object BackupCrypto {
    private const val MAGIC = "AFENC1"

    private fun key(pass: CharArray, salt: ByteArray): SecretKeySpec {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return SecretKeySpec(f.generateSecret(PBEKeySpec(pass, salt, 120_000, 256)).encoded, "AES")
    }

    fun isEncrypted(data: ByteArray): Boolean = data.size > 34 && String(data, 0, 6, Charsets.US_ASCII) == MAGIC

    fun encrypt(plain: ByteArray, pass: CharArray): ByteArray {
        val rnd = SecureRandom()
        val salt = ByteArray(16).also { rnd.nextBytes(it) }
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(pass, salt), GCMParameterSpec(128, iv))
        return MAGIC.toByteArray(Charsets.US_ASCII) + salt + iv + c.doFinal(plain)
    }

    fun decrypt(data: ByteArray, pass: CharArray): ByteArray {
        val salt = data.copyOfRange(6, 22)
        val iv = data.copyOfRange(22, 34)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(pass, salt), GCMParameterSpec(128, iv))
        return c.doFinal(data, 34, data.size - 34)
    }
}
