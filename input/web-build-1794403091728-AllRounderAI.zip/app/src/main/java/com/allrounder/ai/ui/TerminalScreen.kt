
@file:OptIn(ExperimentalMaterial3Api::class)

package com.allrounder.ai.ui

import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.allrounder.ai.TerminalPrefill
import com.allrounder.ai.TerminalViewModel
import com.allrounder.ai.data.Backend
import com.allrounder.ai.data.TerminalEngine
import com.allrounder.ai.data.SettingsState
import androidx.compose.ui.text.input.PasswordVisualTransformation

@Composable
fun TerminalScreen(onBack: () -> Unit, onSettings: () -> Unit, onSendToChat: (String) -> Unit) {
    val vm: TerminalViewModel = viewModel()
    val st by vm.settings.state.collectAsState()
    val lines by vm.lines.collectAsState()
    val busy by vm.busy.collectAsState()
    val proposal by vm.proposal.collectAsState()
    val ctx = LocalContext.current
    val prefill = remember { TerminalPrefill.take() }
    var input by rememberSaveable { mutableStateOf(prefill) }
    var ai by rememberSaveable { mutableStateOf(prefill.isBlank()) }
    val backend = Backend.from(st.termBackend)
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, TerminalEngine.TERMUX_PERMISSION) == PackageManager.PERMISSION_GRANTED)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    val listState = rememberLazyListState()
    LaunchedEffect(lines.size) { if (lines.isNotEmpty()) listState.animateScrollToItem(lines.size - 1) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(tr("Terminal")) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = { TextButton(onClick = { vm.clear() }) { Text(tr("Clear")) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding().padding(horizontal = 12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Backend.values().forEach {
                    FilterChip(selected = backend == it, onClick = { vm.settings.setTermBackend(it.id) }, label = { Text(it.label) })
                }
            }
            Text(
                TerminalEngine.describe(backend),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 4.dp)
            )
            if (backend == Backend.TERMUX && !granted) {
                OutlinedButton(onClick = { permLauncher.launch(TerminalEngine.TERMUX_PERMISSION) }) { Text("Grant Termux permission") }
                Text(
                    "One-time setup in Termux: echo 'allow-external-apps=true' >> ~/.termux/termux.properties, then restart Termux.",
                    style = MaterialTheme.typography.labelSmall
                )
            }
            if (backend == Backend.SSH) SshCard(st, vm)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Auto-run safe commands", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                Switch(checked = st.termAuto, onCheckedChange = { vm.settings.setTermAuto(it) })
            }
            Surface(
                color = Color(0xFF0B0F19),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f).fillMaxWidth()
            ) {
                SelectionContainer {
                    LazyColumn(state = listState, contentPadding = PaddingValues(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(lines) { l ->
                            val (prefix, color) = when (l.kind) {
                                0 -> "$ " to Color(0xFF7EE787)
                                1 -> "" to Color(0xFFE6EDF3)
                                3 -> "AI: " to Color(0xFF79C0FF)
                                4 -> "You: " to Color(0xFFFFA657)
                                else -> "" to Color(0xFF8B949E)
                            }
                            Text(prefix + l.text, color = color, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }
                    }
                }
            }
            if (proposal.isNotEmpty()) Card(
                Modifier.padding(top = 8.dp).fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text("AI wants to run:", fontWeight = FontWeight.SemiBold)
                    proposal.forEach { Text("$ $it", fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { vm.runProposal() }, enabled = !busy) { Text(tr("Run")) }
                        TextButton(onClick = { vm.dismissProposal() }) { Text(tr("Dismiss")) }
                    }
                }
            }
            Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                FilterChip(selected = ai, onClick = { ai = true }, label = { Text("Ask AI") })
                FilterChip(selected = !ai, onClick = { ai = false }, label = { Text("Shell") })
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { val o = vm.lastOutput(); if (o.isNotBlank()) onSendToChat("Terminal output:\n```\n$o\n```") }) {
                    Text(tr("Send output to chat"))
                }
            }
            Row(Modifier.padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text(if (ai) "e.g. install python and check version" else "command") },
                    maxLines = 4
                )
                Spacer(Modifier.width(8.dp))
                if (busy) FilledIconButton(onClick = { vm.stop() }) { Text("\u25A0") }
                else FilledIconButton(onClick = { vm.submit(input, ai); input = "" }, enabled = input.isNotBlank()) { Text("\u25B6") }
            }
        }
    }
}

@Composable
private fun SshCard(st: SettingsState, vm: TerminalViewModel) {
    var host by remember { mutableStateOf(st.sshHost) }
    var port by remember { mutableStateOf(st.sshPort.toString()) }
    var user by remember { mutableStateOf(st.sshUser) }
    var pass by remember { mutableStateOf(st.sshPass) }
    fun save() { vm.settings.setSsh(host, port.toIntOrNull() ?: 22, user, pass) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 4.dp)) {
        Text(
            "Your own computer or server. The password is stored encrypted and the host key is pinned on first connect.",
            style = MaterialTheme.typography.labelSmall
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(value = host, onValueChange = { host = it; save() }, label = { Text("Host") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(
                value = port, onValueChange = { port = it.filter { c -> c.isDigit() }; save() },
                label = { Text("Port") }, singleLine = true, modifier = Modifier.width(90.dp)
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(value = user, onValueChange = { user = it; save() }, label = { Text("User") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(
                value = pass, onValueChange = { pass = it; save() }, label = { Text("Password") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.weight(1f)
            )
        }
    }
}
