
package com.allrounder.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.allrounder.ai.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

enum class BuildMode { WEB, APP }

/** Hand-off from the Projects screen to a builder screen. */
object BuilderPrefill {
    var mode: BuildMode? = null
    var id: String? = null
}

private const val WEB_SYS = "You are a senior web developer. Build the requested website as static files: " +
    "index.html plus optional style.css and script.js linked with relative paths (no external requests or CDNs, responsive, accessible, modern design). Extra pages such as about.html or contact.html are allowed and must link to each other with relative links. Draw illustrations and logos as inline SVG (no external images). " +
    "Respond with ONLY JSON, no markdown: {\"files\":[{\"path\":\"index.html\",\"content\":\"...\"}]}"

private const val APP_SYS = "You are a senior Android engineer. Generate a complete, buildable Android project: Kotlin 2.0.21, " +
    "Jetpack Compose + Material3, AGP 8.10.1, Gradle Kotlin DSL, compileSdk 36, targetSdk 36, minSdk 26, " +
    "plugins org.jetbrains.kotlin.android and org.jetbrains.kotlin.plugin.compose. Files: settings.gradle.kts, " +
    "build.gradle.kts, gradle.properties (android.useAndroidX=true), app/build.gradle.kts (release buildType must use " +
    "signingConfigs.getByName(\"debug\") so the APK installs), app/src/main/AndroidManifest.xml, Kotlin sources, " +
    "res files incl. strings.xml and themes.xml. Do NOT include gradlew or binary files. Request only the permissions the app needs. " +
    "Include an adaptive launcher icon as XML vector drawables (res/drawable/ic_launcher_foreground.xml, res/drawable/ic_launcher_background.xml, res/mipmap-anydpi/ic_launcher.xml) matching the app theme, and reference it in the manifest. " +
    "Keep it compact. Respond with ONLY JSON, no markdown: {\"files\":[{\"path\":\"...\",\"content\":\"...\"}]}"

class BuilderViewModel(app: Application) : AndroidViewModel(app) {
    val settings = SettingsRepo.get(app)
    val busy = MutableStateFlow(false)
    val status = MutableStateFlow("")
    val error = MutableStateFlow<String?>(null)
    val files = MutableStateFlow<List<GenFile>>(emptyList())
    val resultUrl = MutableStateFlow<String?>(null)
    val resultNote = MutableStateFlow("")
    val buildStatus = MutableStateFlow("")
    val projects = MutableStateFlow<List<SavedProject>>(emptyList())
    private var projectId: String? = null
    private var projectTitle = "Project"
    val canFix = MutableStateFlow(false)
    private var buildLog = ""
    private var lastOwner: String? = null
    private var lastRepo: String? = null
    private var job: Job? = null

    fun generate(mode: BuildMode, prompt: String, refine: Boolean = false) {
        if (busy.value || prompt.isBlank()) return
        val existing = if (refine) files.value else emptyList()
        val userText = if (existing.isEmpty()) prompt.trim() else {
            val arr = JSONArray()
            existing.forEach { arr.put(JSONObject().put("path", it.path).put("content", if (it.binary) "(binary image file)" else it.content)) }
            "Current project as JSON:\n" + JSONObject().put("files", arr).toString().take(60000) +
                "\n\nApply this change and return the COMPLETE updated project in the same JSON format (image files are kept automatically, do not include them):\n" + prompt.trim()
        }
        job = viewModelScope.launch {
            busy.value = true; error.value = null; resultUrl.value = null
            if (!refine) {
                files.value = emptyList(); projectId = null
                projectTitle = prompt.trim().take(40).ifBlank { "Project" }
            }
            status.value = "Generating with AI…"
            try {
                val s = settings.state.value
                val order = s.providerOrder()
                if (order.isEmpty()) { error.value = "Add an AI API key in Settings first."; return@launch }
                var last = "Generation failed"
                for (spec in order) {
                    try {
                        val text = runProvider(
                            getApplication<Application>(), spec, s,
                            if (mode == BuildMode.WEB) WEB_SYS else APP_SYS,
                            listOf(Turn("user", userText))
                        )
                        val parsed = parseFiles(text)
                        if (parsed.isEmpty()) throw LlmException("${spec.name}: no files returned")
                        val merged = parsed + existing.filter { b -> b.binary && parsed.none { it.path == b.path } }
                        files.value = merged
                        val pid = projectId ?: java.util.UUID.randomUUID().toString().also { projectId = it }
                        ProjectStore.save(getApplication<Application>(), pid, mode.name, projectTitle, merged)
                        loadProjects(mode)
                        return@launch
                    } catch (e: LlmException) {
                        last = e.message ?: last
                        if (!s.fallback) break
                    }
                }
                error.value = last
            } finally { busy.value = false; status.value = "" }
        }
    }

    /** Generates an AI image with your OpenAI/Gemini key, adds it to the site and asks the AI to place it in the page. */
    fun addImage(idea: String) {
        if (busy.value || files.value.isEmpty() || idea.isBlank()) return
        job = viewModelScope.launch {
            var path: String? = null
            busy.value = true; error.value = null; status.value = "Generating image..."
            try {
                val g = ImageGen.generate(settings.state.value, idea.trim())
                val n = files.value.count { it.binary } + 1
                val p = "images/ai-$n.${g.ext}"
                files.value = files.value + GenFile(p, g.b64, true)
                path = p
            } catch (e: LlmException) {
                error.value = e.message
            } finally {
                busy.value = false; status.value = ""
            }
            val p = path
            if (p != null) {
                generate(
                    BuildMode.WEB,
                    "Use the new image file $p in the page where it fits best (hero image or gallery) with a relative <img src=\"$p\" alt=\"...\"> tag. Image idea: " + idea.trim(),
                    refine = true
                )
            }
        }
    }

    fun loadProjects(mode: BuildMode) {
        projects.value = ProjectStore.list(getApplication<Application>(), mode.name)
    }

    fun openProject(mode: BuildMode, id: String) {
        files.value = ProjectStore.load(getApplication<Application>(), id)
        projectId = id
        projectTitle = projects.value.firstOrNull { it.id == id }?.title ?: "Project"
        resultUrl.value = null; error.value = null; buildStatus.value = ""; canFix.value = false
    }

    fun deleteProject(mode: BuildMode, id: String) {
        ProjectStore.delete(getApplication<Application>(), id)
        if (projectId == id) { projectId = null; files.value = emptyList() }
        loadProjects(mode)
    }

    fun exportUri(): android.net.Uri =
        ProjectStore.exportZip(getApplication<Application>(), projectTitle, files.value)

    /** Polls GitHub for up to 20 minutes and posts a notification when the build ends (works while the app process is alive). */
    private fun watchBuild(token: String, owner: String, repo: String) {
        viewModelScope.launch {
            try {
                val api = GitHubApi(token)
                val before = api.latestRun(owner, repo)
                repeat(60) {
                    delay(20_000)
                    val run = api.latestRun(owner, repo)
                    if (run != null && run.status == "completed" && (before == null || run.id != before.id || before.status != "completed")) {
                        val ok = run.conclusion == "success"
                        Notifier.notify(
                            getApplication<Application>(), 4242, if (ok) "Build finished" else "Build failed",
                            if (ok) "$repo: your APK is ready under Releases." else "$repo: open the app to auto-fix the errors."
                        )
                        return@launch
                    }
                }
            } catch (e: Exception) { /* best effort */ }
        }
    }

    fun checkBuild() {
        val o = lastOwner; val r = lastRepo
        val token = settings.state.value.githubToken
        if (o == null || r == null || token.isBlank() || busy.value) return
        job = viewModelScope.launch {
            busy.value = true; error.value = null
            try {
                val run = GitHubApi(token).latestRun(o, r)
                when {
                    run == null -> buildStatus.value = "No build found yet - try again in a minute"
                    run.status != "completed" -> { buildStatus.value = "Build is still running..."; canFix.value = false }
                    run.conclusion == "success" -> {
                        buildStatus.value = "Build succeeded. Download the APK from Releases."; canFix.value = false
                    }
                    else -> {
                        buildStatus.value = "Build failed"
                        buildLog = GitHubApi(token).failedLog(o, r, run.id)
                        canFix.value = true
                    }
                }
            } catch (e: GitHubException) {
                error.value = e.message
            } finally { busy.value = false }
        }
    }

    fun autoFix() {
        if (!canFix.value || busy.value) return
        canFix.value = false
        generate(BuildMode.APP, "The Gradle build failed with these errors. Fix the project so it compiles:\n" + buildLog, refine = true)
    }

    fun publish(mode: BuildMode, repoRaw: String, domain: String = "") {
        val token = settings.state.value.githubToken
        if (token.isBlank()) { error.value = "Add your GitHub token in Settings first."; return }
        val repo = repoRaw.lowercase().replace(Regex("[^a-z0-9-]"), "-").trim('-').take(60)
        if (repo.isEmpty() || files.value.isEmpty() || busy.value) return
        job = viewModelScope.launch {
            busy.value = true; error.value = null
            try {
                val api = GitHubApi(token)
                status.value = "Checking GitHub token…"
                val owner = api.login()
                lastOwner = owner; lastRepo = repo; buildStatus.value = ""; canFix.value = false
                status.value = "Creating $owner/$repo…"
                api.createRepo(repo)
                val toPush = files.value.toMutableList()
                if (mode == BuildMode.WEB && domain.isNotBlank()) toPush += GenFile("CNAME", domain.trim())
                if (mode == BuildMode.APP) {
                    val yml = getApplication<Application>().assets.open("android.yml").bufferedReader().readText()
                    toPush += GenFile(".github/workflows/android.yml", yml)
                }
                toPush.forEachIndexed { i, f ->
                    status.value = "Uploading ${i + 1}/${toPush.size}: ${f.path}"
                    api.putFile(owner, repo, f)
                }
                if (mode == BuildMode.WEB) {
                    api.enablePages(owner, repo)
                    resultUrl.value = "https://$owner.github.io/$repo/"
                    resultNote.value = if (domain.isBlank()) "Published. The site goes live in 1-2 minutes."
                        else "Published. Now add a DNS CNAME record for ${domain.trim()} pointing to $owner.github.io (can take up to a day)."
                } else {
                    status.value = "Starting build…"
                    delay(4000)
                    api.dispatchBuild(owner, repo)
                    watchBuild(token, owner, repo)
                    resultUrl.value = "https://github.com/$owner/$repo/releases"
                    resultNote.value = "Build started (about 5-8 min). Your APK will appear under Releases. For a Play Store build, add 4 repository secrets (KEYSTORE_B64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD): the next build then attaches a signed APK and AAB."
                }
            } catch (e: GitHubException) {
                error.value = e.message
            } finally { busy.value = false; status.value = "" }
        }
    }
}
