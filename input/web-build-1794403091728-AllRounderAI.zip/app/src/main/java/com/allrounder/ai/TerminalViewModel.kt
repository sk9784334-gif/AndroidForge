
package com.allrounder.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.allrounder.ai.data.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject

/** kind: 0 command, 1 output, 2 info, 3 AI says, 4 you asked */
data class TermLine(val kind: Int, val text: String)

object TerminalPrefill {
    var cmd: String = ""
    fun take(): String { val c = cmd; cmd = ""; return c }
}

private const val AGENT_SYS = "You are a terminal agent inside an Android app. Work out what the user really wants (do not assume fixed commands) " +
    "and decide the right commands for the backend below. Respond with ONLY JSON, no markdown: " +
    "{\"say\":\"short explanation in the user's language\",\"commands\":[\"cmd1\",\"cmd2\"],\"done\":false}. " +
    "Commands must be non-interactive (use -y flags). Never claim success before you see the command output. " +
    "When the task is finished set done true and commands []. Backend: "

class TerminalViewModel(app: Application) : AndroidViewModel(app) {
    val settings = SettingsRepo.get(app)
    val lines = MutableStateFlow(listOf(TermLine(2, "Terminal ready. Pick a backend, then type a command or ask in plain words.")))
    val busy = MutableStateFlow(false)
    val proposal = MutableStateFlow<List<String>>(emptyList())
    private var cwd: String? = null
    private val convo = ArrayList<Turn>()
    private var job: Job? = null

    private fun add(kind: Int, text: String) { lines.value = (lines.value + TermLine(kind, text)).takeLast(300) }
    private fun backend() = Backend.from(settings.state.value.termBackend)

    fun clear() { lines.value = emptyList(); convo.clear(); proposal.value = emptyList() }
    fun lastOutput(): String = lines.value.lastOrNull { it.kind == 1 }?.text.orEmpty()
    fun stop() { job?.cancel(); busy.value = false }

    fun submit(text: String, ai: Boolean) {
        if (busy.value || text.isBlank()) return
        job = viewModelScope.launch {
            busy.value = true
            try {
                if (ai) {
                    add(4, text.trim())
                    convo += Turn("user", text.trim())
                    step(0)
                } else {
                    runCommands(listOf(text.trim()), agent = false, depth = 0)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                add(2, "Error: " + (e.message ?: "failed"))
            } finally {
                busy.value = false
            }
        }
    }

    fun runProposal() {
        val cmds = proposal.value
        if (busy.value || cmds.isEmpty()) return
        job = viewModelScope.launch {
            busy.value = true
            try { runCommands(cmds, agent = true, depth = 1) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { add(2, "Error: " + (e.message ?: "failed")) }
            finally { busy.value = false }
        }
    }

    fun dismissProposal() { proposal.value = emptyList() }

    private suspend fun step(depth: Int) {
        val s = settings.state.value
        val order = s.providerOrder()
        if (order.isEmpty()) { add(2, "Add an AI provider in Settings first."); return }
        val system = AGENT_SYS + TerminalEngine.describe(backend()) + (cwd?.let { " Current directory: $it." } ?: "")
        var reply: String? = null
        var last = ""
        for (spec in order) {
            try {
                reply = runProvider(getApplication<Application>(), spec, s, system, convo.takeLast(12))
                break
            } catch (e: LlmException) {
                last = e.message ?: ""
                if (!s.fallback) break
            }
        }
        if (reply == null) { add(2, last.ifBlank { "AI request failed" }); return }
        convo += Turn("assistant", reply)
        var say = reply.trim()
        var cmds = emptyList<String>()
        try {
            val o = JSONObject(reply.substring(reply.indexOf('{'), reply.lastIndexOf('}') + 1))
            say = o.optString("say")
            val arr = o.optJSONArray("commands")
            if (arr != null) cmds = (0 until arr.length()).map { arr.getString(it) }.filter { it.isNotBlank() }
        } catch (e: Exception) { /* plain text answer */ }
        if (say.isNotBlank()) add(3, say)
        if (cmds.isEmpty()) return
        if (s.termAuto && depth < 4 && cmds.none { TerminalEngine.isRisky(it) }) {
            runCommands(cmds, agent = true, depth = depth + 1)
        } else {
            proposal.value = cmds
            if (cmds.any { TerminalEngine.isRisky(it) }) add(2, "Some commands change or delete things, so they need your tap to run.")
        }
    }

    private suspend fun runCommands(cmds: List<String>, agent: Boolean, depth: Int) {
        val s = settings.state.value
        val b = backend()
        proposal.value = emptyList()
        val batches = if (b == Backend.CLOUD) listOf(cmds.joinToString("\n")) else cmds
        val sb = StringBuilder()
        for (c in batches) {
            add(0, c)
            val out = try {
                val r = TerminalEngine.exec(getApplication<Application>(), b, c, cwd, s.githubToken)
                cwd = r.cwd ?: cwd
                r.output
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                "Error: " + (e.message ?: "failed")
            }
            add(1, out.ifBlank { "(no output)" })
            sb.append("$ ").append(c).append("\n").append(out).append("\n")
        }
        if (agent) {
            convo += Turn("user", "Command output:\n" + sb.toString().takeLast(6000))
            step(depth)
        }
    }
}
