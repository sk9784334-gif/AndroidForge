
package com.allrounder.ai

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import com.allrounder.ai.data.CrashLog
import com.allrounder.ai.ui.*

const val LOCK_AUTH = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContent {
            val vm: ChatViewModel = viewModel()
            val st by vm.settings.state.collectAsState()
            val dark = when (st.theme) {
                "dark" -> true
                "light" -> false
                else -> isSystemInDarkTheme()
            }
            DisposableEffect(dark) {
                val style = if (dark) SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                else SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                onDispose { }
            }
            AllRounderTheme(dark = dark, accent = accentFor(st.accent), fontScale = st.fontScale) {
                CompositionLocalProvider(LocalUiHi provides (st.uiLang == "hi")) {
                    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                        AppRoot(vm)
                    }
                }
            }
        }
    }
}

@Composable
private fun AppRoot(vm: ChatViewModel) {
    val st by vm.settings.state.collectAsState()
    val ctx = LocalContext.current
    var unlocked by rememberSaveable { mutableStateOf(false) }
    var screen by rememberSaveable { mutableStateOf("chat") }
    var crashDialog by remember { mutableStateOf(CrashLog.read(ctx) != null) }

    LaunchedEffect(Unit) {
        // Text shared into the app from another app's Share sheet becomes a draft message.
        val a = ctx as? Activity
        if (a != null && a.intent?.action == Intent.ACTION_SEND) {
            a.intent.getStringExtra(Intent.EXTRA_TEXT)?.let { vm.draft.value = it }
            a.intent.action = null
        }
        a?.intent?.getStringExtra("route")?.let { r ->
            screen = r
            a.intent.removeExtra("route")
        }
    }
    var stoppedAt by remember { mutableStateOf(0L) }
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { stoppedAt = System.currentTimeMillis() }
    LifecycleEventEffect(Lifecycle.Event.ON_START) {
        if (stoppedAt > 0L && System.currentTimeMillis() - stoppedAt >= st.lockTimeout * 1000L) unlocked = false
    }
    SideEffect {
        (ctx as? Activity)?.window?.let {
            if (st.appLock || st.blockShots) it.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
            else it.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }
    BackHandler(enabled = screen != "chat") { screen = if (screen == "privacy") "settings" else "chat" }

    if (st.appLock && !unlocked) {
        LockScreen(onUnlock = { unlocked = true })
        return
    }
    if (crashDialog && screen == "chat") AlertDialog(
        onDismissRequest = { crashDialog = false },
        title = { Text("App closed unexpectedly") },
        text = { Text("A crash report from last time was saved. View it so it can be fixed?") },
        confirmButton = { TextButton(onClick = { crashDialog = false; screen = "profile" }) { Text("View report") } },
        dismissButton = { TextButton(onClick = { crashDialog = false }) { Text("Later") } }
    )
    val back = { screen = "chat" }
    when (screen) {
        "settings" -> SettingsScreen(vm, onBack = back, onOpenPrivacy = { screen = "privacy" })
        "privacy" -> PrivacyScreen(onBack = { screen = "settings" })
        "web" -> BuilderScreen(BuildMode.WEB, onBack = back, onSettings = { screen = "settings" })
        "app" -> BuilderScreen(BuildMode.APP, onBack = back, onSettings = { screen = "settings" })
        "run" -> RunnerScreen(onBack = back, onSettings = { screen = "settings" })
        "terminal" -> TerminalScreen(
            onBack = back, onSettings = { screen = "settings" },
            onSendToChat = { vm.draft.value = it; screen = "chat" }
        )
        "plugins" -> PluginsScreen(vm, onBack = back)
        "scheduled" -> SchedulerScreen(onBack = back)
        "images" -> ImagesScreen(vm, onBack = back)
        "library" -> LibraryScreen(vm, onBack = back, onOpenChat = back)
        "projects" -> ProjectsScreen(onBack = back, onOpen = { screen = it })
        "search" -> SearchScreen(vm, onBack = back, onOpenChat = back)
        "profile" -> ProfileScreen(vm, onBack = back, onNavigate = { screen = it })
        else -> CompositionLocalProvider(
            LocalOpenRunner provides { lang, code ->
                RunnerPrefill.lang = lang
                RunnerPrefill.code = code
                screen = "run"
            },
            LocalOpenTerminal provides { cmd ->
                TerminalPrefill.cmd = cmd
                screen = "terminal"
            },
            LocalDownload provides { url -> vm.startDownload(url) }
        ) {
            ChatScreen(vm, onNavigate = { screen = it })
        }
    }
}

@Composable
private fun LockScreen(onUnlock: () -> Unit) {
    val ctx = LocalContext.current
    val attempt = {
        val act = ctx as? FragmentActivity
        if (act == null || BiometricManager.from(ctx).canAuthenticate(LOCK_AUTH) != BiometricManager.BIOMETRIC_SUCCESS) {
            onUnlock() // device lock was removed: don't trap the user out
        } else {
            val prompt = BiometricPrompt(act, ContextCompat.getMainExecutor(act),
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = onUnlock()
                })
            prompt.authenticate(
                BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Unlock AllRounder AI")
                    .setAllowedAuthenticators(LOCK_AUTH)
                    .build()
            )
        }
    }
    LaunchedEffect(Unit) { attempt() }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        LogoMark(72.dp)
        Spacer(Modifier.height(16.dp))
        Text("AllRounder AI is locked", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(16.dp))
        Button(onClick = { attempt() }) { Text("Unlock") }
    }
}
