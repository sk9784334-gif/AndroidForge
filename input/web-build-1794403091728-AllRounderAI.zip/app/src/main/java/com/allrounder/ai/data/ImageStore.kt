
package com.allrounder.ai.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import java.io.File
import java.util.UUID

/** Attached images are stored as files; messages keep only ids joined with | (avoids oversized DB rows). */
object ImageStore {
    private val ID = Regex("[A-Za-z0-9-]+")
    private fun dir(ctx: Context) = File(ctx.filesDir, "img").apply { mkdirs() }
    private fun file(ctx: Context, id: String): File? =
        if (ID.matches(id)) File(dir(ctx), "$id.jpg").takeIf { it.exists() } else null

    fun saveAll(ctx: Context, b64Joined: String): String =
        b64Joined.split("|").filter { it.isNotBlank() }.joinToString("|") { b64 ->
            val id = UUID.randomUUID().toString()
            File(dir(ctx), "$id.jpg").writeBytes(Base64.decode(b64, Base64.DEFAULT))
            id
        }

    fun b64All(ctx: Context, ids: String): String =
        ids.split("|").mapNotNull { id ->
            file(ctx, id)?.let { Base64.encodeToString(it.readBytes(), Base64.NO_WRAP) }
        }.joinToString("|")

    fun bitmap(ctx: Context, id: String, sample: Int = 1): Bitmap? = try {
        file(ctx, id)?.let { BitmapFactory.decodeFile(it.path, BitmapFactory.Options().apply { inSampleSize = sample }) }
    } catch (e: Throwable) {
        null
    }

    fun clear(ctx: Context) { dir(ctx).listFiles()?.forEach { it.delete() } }
}
