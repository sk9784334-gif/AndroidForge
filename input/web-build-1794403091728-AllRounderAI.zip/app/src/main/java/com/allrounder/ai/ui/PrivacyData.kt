package com.allrounder.ai.ui

/** Single source for the in-app privacy policy (the web page in assets is generated from the same text). */
const val PRIVACY_DATE = "Effective: November 2026"

val PRIVACY_SECTIONS = listOf(
    "Overview" to "AllRounder AI is a chat, website-builder, app-builder and code-runner app. The developer does not run any server for this app and does not collect, store, sell or share your personal data. Everything the app stores stays on your phone unless you choose to send it to a service described below.",
    "Data stored on your device" to "Your chats and messages (including images and files you attach), your settings, your API keys and tokens (encrypted with the Android Keystore), generated website and app projects, and an optional on-device AI model file. None of this is uploaded to the developer. It is removed when you delete chats, use Reset app, or uninstall the app.",
    "Data sent to services you choose" to "When you send a message, the text, any attached images or files, and the earlier messages needed for context are sent directly from your phone to the AI provider you configured: Google Gemini, OpenAI, Anthropic, Groq, OpenRouter, or a custom server address you entered. Those providers process the data under their own privacy policies. If you use only an on-device model, your data stays on your phone. If you turn on Web search, the text of your latest message is sent to Tavily. If you use the Web builder, App builder, Code runner or Publish page features, the generated files or code are sent to GitHub using your own token and are stored in repositories in your own GitHub account. If you use AI images, your image description is sent to OpenAI or Google (whichever key you added). If you use the SSH terminal, commands and their output travel only between your phone and your own server. Scheduled prompts are sent to your chosen AI provider at the set time.",
    "Keys and tokens" to "API keys and your GitHub token are stored encrypted on your device. Each key is sent only to the service it belongs to. Your GitHub token is sent only to api.github.com. You can remove any key in Settings or revoke it with the provider at any time.",
    "Permissions" to "The app uses the Internet permission to reach the services above. Photos and files are accessed only through the Android photo and file pickers and only for the items you select. Voice input uses your device's speech service. App lock uses your device's fingerprint, face or screen lock.",
    "No ads or tracking" to "The app contains no advertising, no analytics and no tracking tools.",
    "AI-generated content" to "Replies are produced by AI models and can be wrong, incomplete or inappropriate. Do not rely on them for medical, legal, financial or safety decisions. You can report a response with the Report option in the message menu.",
    "Children" to "This app is not directed to children under 13 and should not be used by them.",
    "Your choices" to "You can delete single messages, chats or all chats, export or restore a backup of your chats, turn features such as Web search off, and reset the whole app in Settings.",
    "Security" to "The app uses encrypted connections (HTTPS) for internet services, allows plain HTTP only to your own device (localhost), encrypts stored keys, and offers an optional app lock. No method of storage or transmission is completely secure.",
    "Changes to this policy" to "If this policy changes, the new version will be included in an app update and the date below will change.",
    "Contact" to "Questions or requests: sabsastabroker@gmail.com"
)
