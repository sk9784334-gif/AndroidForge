
package com.allrounder.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.allrounder.ai.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

enum class Lang(val label: String, val file: String, val template: String) {
    PYTHON("Python", "main.py", "print(\"Hello from Python\")"),
    JS("JavaScript", "main.js", "console.log(\"Hello from JavaScript\");"),
    SHELL("Shell", "main.sh", "echo \"Hello from Shell\""),
    GO("Go", "main.go", "package main\n\nimport \"fmt\"\n\nfunc main() {\n    fmt.Println(\"Hello from Go\")\n}"),
    RUST("Rust", "main.rs", "fn main() {\n    println!(\"Hello from Rust\");\n}"),
    CPP("C++", "main.cpp", "#include <iostream>\n\nint main() {\n    std::cout << \"Hello from C++\" << std::endl;\n    return 0;\n}"),
    JAVA("Java", "Main.java", "public class Main {\n    public static void main(String[] args) {\n        System.out.println(\"Hello from Java\");\n    }\n}")
}

/** Hand-off from a chat code block to the Code runner screen. */
object RunnerPrefill {
    var lang: Lang? = null
    var code: String = ""
    fun take(): Pair<Lang?, String> {
        val r = lang to code
        lang = null
        code = ""
        return r
    }
}

/** Runs code in a private repo of the user's own GitHub account (GitHub Actions sandbox), never on the phone. */
class RunnerViewModel(app: Application) : AndroidViewModel(app) {
    private val settings = SettingsRepo.get(app)
    val busy = MutableStateFlow(false)
    val status = MutableStateFlow("")
    val output = MutableStateFlow("")
    val error = MutableStateFlow<String?>(null)
    private var job: Job? = null

    fun run(lang: Lang, code: String, stdin: String = "") {
        val token = settings.state.value.githubToken
        if (token.isBlank()) { error.value = "Add your GitHub token in Settings first."; return }
        if (busy.value || code.isBlank()) return
        job = viewModelScope.launch {
            busy.value = true; error.value = null; output.value = ""
            try {
                output.value = CloudRunner.run(getApplication<Application>(), token, lang.file, code, stdin) { status.value = it }
                RunHistory.add(getApplication<Application>(), RunEntry(lang.name, code, output.value, System.currentTimeMillis()))
            } catch (e: GitHubException) {
                error.value = e.message
            } finally {
                busy.value = false; status.value = ""
            }
        }
    }
}
