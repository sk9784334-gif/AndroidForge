
package com.allrounder.ai.data

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Calendar
import java.util.concurrent.TimeUnit

data class ScheduledTask(val id: String, val prompt: String, val hour: Int, val minute: Int, val daily: Boolean)

object SchedStore {
    private fun file(ctx: Context) = File(ctx.filesDir, "scheduled.json")

    fun list(ctx: Context): List<ScheduledTask> = try {
        val a = JSONArray(file(ctx).takeIf { it.exists() }?.readText() ?: "[]")
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            ScheduledTask(o.getString("id"), o.getString("prompt"), o.getInt("hour"), o.getInt("minute"), o.optBoolean("daily", true))
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun save(ctx: Context, all: List<ScheduledTask>) {
        val a = JSONArray()
        all.forEach {
            a.put(JSONObject().put("id", it.id).put("prompt", it.prompt).put("hour", it.hour).put("minute", it.minute).put("daily", it.daily))
        }
        file(ctx).writeText(a.toString())
    }

    fun add(ctx: Context, t: ScheduledTask) = save(ctx, list(ctx) + t)
    fun remove(ctx: Context, id: String) = save(ctx, list(ctx).filter { it.id != id })
}

object Scheduler {
    fun nextDelayMs(hour: Int, minute: Int): Long {
        val now = Calendar.getInstance()
        val t = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 1)
        }
        return t.timeInMillis - now.timeInMillis
    }

    fun schedule(ctx: Context, t: ScheduledTask, delayMs: Long = nextDelayMs(t.hour, t.minute)) {
        val req = OneTimeWorkRequestBuilder<ScheduledWorker>()
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("id" to t.id))
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("sched_" + t.id, ExistingWorkPolicy.REPLACE, req)
    }

    fun cancel(ctx: Context, id: String) {
        WorkManager.getInstance(ctx).cancelUniqueWork("sched_$id")
    }
}

/** Runs a saved prompt in the background, saves the answer as a chat and notifies you. */
class ScheduledWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val id = inputData.getString("id") ?: return Result.failure()
        val ctx = applicationContext
        val task = SchedStore.list(ctx).firstOrNull { it.id == id } ?: return Result.success()
        try {
            val s = SettingsRepo.get(ctx).state.value
            val order = s.providerOrder()
            if (order.isEmpty()) {
                Notifier.notify(ctx, id.hashCode(), "Scheduled task", "Add an AI provider in Settings first.")
            } else {
                var reply: String? = null
                var last = "failed"
                for (spec in order) {
                    try {
                        reply = runProvider(ctx, spec, s, s.systemPrompt, listOf(Turn("user", task.prompt)))
                        break
                    } catch (e: LlmException) {
                        last = e.message ?: last
                        if (!s.fallback) break
                    }
                }
                if (reply != null) {
                    val dao = AppDb.get(ctx).dao()
                    val now = System.currentTimeMillis()
                    val chatId = dao.insertChat(ChatEntity(title = "\u23F0 " + task.prompt.take(40), updatedAt = now))
                    dao.insertMessage(MessageEntity(chatId = chatId, role = "user", content = task.prompt, provider = null, createdAt = now))
                    dao.insertMessage(MessageEntity(chatId = chatId, role = "assistant", content = reply, provider = "Scheduled", createdAt = now + 1))
                    Notifier.notify(ctx, id.hashCode(), task.prompt.take(40), reply)
                } else {
                    Notifier.notify(ctx, id.hashCode(), "Scheduled task failed", last)
                }
            }
        } catch (e: Exception) {
            Notifier.notify(ctx, id.hashCode(), "Scheduled task failed", e.message ?: "error")
        }
        if (task.daily) Scheduler.schedule(ctx, task) else SchedStore.remove(ctx, id)
        return Result.success()
    }
}
