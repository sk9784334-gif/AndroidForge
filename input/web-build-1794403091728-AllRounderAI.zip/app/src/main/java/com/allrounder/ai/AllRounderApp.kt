
package com.allrounder.ai

import android.app.Application
import com.allrounder.ai.data.CrashLog

class AllRounderApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
    }
}
