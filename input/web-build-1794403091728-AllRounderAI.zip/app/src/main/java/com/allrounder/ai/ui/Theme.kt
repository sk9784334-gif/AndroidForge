package com.allrounder.ai.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.graphics.Color

val BrandViolet = Color(0xFF6C5CE7)
val BrandCyan = Color(0xFF00B8D9)

private val Dark = darkColorScheme(
    primary = Color(0xFF8B7CFF),
    onPrimary = Color(0xFF11102B),
    primaryContainer = Color(0xFF2E2A6B),
    onPrimaryContainer = Color(0xFFE6E2FF),
    secondary = Color(0xFF38D0E8),
    onSecondary = Color(0xFF00252C),
    background = Color(0xFF0B1020),
    onBackground = Color(0xFFE8EAF6),
    surface = Color(0xFF0B1020),
    onSurface = Color(0xFFE8EAF6),
    surfaceVariant = Color(0xFF1B2340),
    onSurfaceVariant = Color(0xFFB4BAD6),
    surfaceContainer = Color(0xFF121830),
    surfaceContainerHigh = Color(0xFF182039),
    outline = Color(0xFF3A4468),
    outlineVariant = Color(0xFF283152),
    error = Color(0xFFFF6B7A),
    errorContainer = Color(0xFF4A1620),
    onErrorContainer = Color(0xFFFFD9DD)
)

private val Light = lightColorScheme(
    primary = Color(0xFF5B4BDB),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE6E2FF),
    onPrimaryContainer = Color(0xFF1B1550),
    secondary = Color(0xFF0097B8),
    onSecondary = Color.White,
    background = Color(0xFFF6F7FD),
    onBackground = Color(0xFF141833),
    surface = Color(0xFFF6F7FD),
    onSurface = Color(0xFF141833),
    surfaceVariant = Color(0xFFECEEFA),
    onSurfaceVariant = Color(0xFF545B7E),
    surfaceContainer = Color(0xFFFFFFFF),
    surfaceContainerHigh = Color(0xFFF0F1FB),
    outline = Color(0xFFB4BAD6),
    outlineVariant = Color(0xFFDADDF0),
    error = Color(0xFFBA1A2B),
    errorContainer = Color(0xFFFFDADD),
    onErrorContainer = Color(0xFF410009)
)

fun accentFor(name: String): Color? = when (name) {
    "cyan" -> Color(0xFF00B8D9)
    "green" -> Color(0xFF2EBD85)
    "orange" -> Color(0xFFFF8A3D)
    "pink" -> Color(0xFFE0559C)
    else -> null
}

@Composable
fun AllRounderTheme(
    dark: Boolean = isSystemInDarkTheme(),
    accent: Color? = null,
    fontScale: Float = 1f,
    content: @Composable () -> Unit
) {
    val base = if (dark) Dark else Light
    val scheme = if (accent != null) base.copy(
        primary = accent,
        onPrimary = if (dark) Color(0xFF11102B) else Color.White
    ) else base
    val d = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(d.density, d.fontScale * fontScale)) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
