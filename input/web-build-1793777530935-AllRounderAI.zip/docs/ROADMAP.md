# Roadmap and how to extend

## Done
Multi-provider chat + fallback, local server, on-device Gemma, Web builder (GitHub Pages), App builder (GitHub Actions APK),
change requests, build auto-fix, voice input, chat search/share/report, app lock, encrypted keys.

## Planned
- Image attach (Photo Picker needs no permission; needs DB migration + vision payloads per provider)
- Streaming replies (SSE per provider)
- Web search tool (needs a search API key)
- Multi-file web preview, project history

## How to add things
- **New AI provider**: add one `ProviderSpec(...)` line to `PROVIDERS` in `data/Llm.kt`. If it speaks the OpenAI chat format, nothing else is needed - the Settings card appears automatically.
- **New provider API format**: add a `ProviderType`, then a branch in `buildRequest` and `parse` in `Llm.kt`.
- **New screen**: add a `Screen` composable and a case in `AppRoot` (`MainActivity.kt`) plus a drawer item in `ChatScreen.kt`.
- **New builder target**: add a `BuildMode` and a system prompt in `BuilderViewModel.kt`.
