@file:OptIn(ExperimentalMaterial3Api::class)

package com.allrounder.ai.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.app.Activity
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.allrounder.ai.R
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import com.allrounder.ai.ChatViewModel
import com.allrounder.ai.data.MessageEntity
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(vm: ChatViewModel, onOpenSettings: () -> Unit, onNavigate: (String) -> Unit) {
    val messages by vm.messages.collectAsState()
    val chats by vm.chats.collectAsState()
    val loading by vm.loading.collectAsState()
    val error by vm.error.collectAsState()
    val currentId by vm.currentChatId.collectAsState()
    val settings by vm.settings.state.collectAsState()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current

    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    LogoMark(40.dp)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("AllRounder AI", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            "All your models, one chat",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Button(
                    onClick = { vm.newChat(); scope.launch { drawerState.close() } },
                    modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth()
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("New chat")
                }
                var query by remember { mutableStateOf("") }
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    placeholder = { Text("Search chats") },
                    singleLine = true,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp).fillMaxWidth()
                )
                Text(
                    "Recent",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 4.dp)
                )
                if (chats.isEmpty()) {
                    Text(
                        "No chats yet",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp).weight(1f)
                    )
                } else {
                    LazyColumn(Modifier.weight(1f)) {
                        items(chats.filter { it.title.contains(query, ignoreCase = true) }, key = { it.id }) { chat ->
                            NavigationDrawerItem(
                                label = { Text(chat.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                selected = chat.id == currentId,
                                onClick = { vm.openChat(chat.id); scope.launch { drawerState.close() } },
                                badge = {
                                    IconButton(onClick = { vm.deleteChat(chat.id) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete chat")
                                    }
                                },
                                modifier = Modifier.padding(horizontal = 12.dp)
                            )
                        }
                    }
                }
                HorizontalDivider()
                NavigationDrawerItem(
                    label = { Text("Web builder") },
                    icon = { Icon(Icons.Default.Create, contentDescription = null) },
                    selected = false,
                    onClick = { scope.launch { drawerState.close() }; onNavigate("web") },
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                )
                NavigationDrawerItem(
                    label = { Text("App builder") },
                    icon = { Icon(Icons.Default.Build, contentDescription = null) },
                    selected = false,
                    onClick = { scope.launch { drawerState.close() }; onNavigate("app") },
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                )
                NavigationDrawerItem(
                    label = { Text("Settings") },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                    selected = false,
                    onClick = { scope.launch { drawerState.close() }; onOpenSettings() },
                    modifier = Modifier.padding(12.dp)
                )
            }
        }
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LogoMark(28.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("AllRounder AI", fontWeight = FontWeight.SemiBold)
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Open menu")
                        }
                    },
                    actions = {
                        if (messages.isNotEmpty()) IconButton(onClick = { shareChat(ctx, messages) }) {
                            Icon(Icons.Default.Share, contentDescription = "Share chat")
                        }
                        IconButton(onClick = { vm.newChat() }) {
                            Icon(Icons.Default.Add, contentDescription = "New chat")
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background
                    )
                )
            }
        ) { pad ->
            Column(
                Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding()
            ) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    if (messages.isEmpty() && !loading) {
                        EmptyState(
                            hasKey = settings.hasKey,
                            onSuggestion = { vm.send(it) },
                            onSettings = onOpenSettings
                        )
                    } else {
                        MessageList(messages, loading)
                    }
                }
                error?.let {
                    ErrorBanner(
                        message = it,
                        canRetry = messages.isNotEmpty() && settings.hasKey,
                        onRetry = { vm.retry() },
                        onDismiss = { vm.error.value = null },
                        onSettings = onOpenSettings
                    )
                }
                InputBar(loading = loading, onSend = { vm.send(it) }, onStop = { vm.stop() })
                Text(
                    "AI can make mistakes. Check important information.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun MessageList(messages: List<MessageEntity>, loading: Boolean) {
    val state = rememberLazyListState()
    val total = messages.size + if (loading) 1 else 0
    LaunchedEffect(total) {
        if (total > 0) state.animateScrollToItem(total - 1)
    }
    LazyColumn(
        state = state,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(messages, key = { it.id }) { MessageBubble(it) }
        if (loading) item(key = "typing") { TypingBubble() }
    }
}

@Composable
private fun MessageBubble(msg: MessageEntity) {
    val isUser = msg.role == "user"
    val clipboard = LocalClipboardManager.current
    val ctx = LocalContext.current
    var reporting by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (isUser) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceVariant,
            contentColor = if (isUser) MaterialTheme.colorScheme.onPrimaryContainer
            else MaterialTheme.colorScheme.onSurface,
            shape = RoundedCornerShape(
                topStart = 20.dp, topEnd = 20.dp,
                bottomEnd = if (isUser) 4.dp else 20.dp,
                bottomStart = if (isUser) 20.dp else 4.dp
            ),
            modifier = Modifier.widthIn(max = 340.dp)
        ) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                SelectionContainer { RichText(msg.content) }
                if (!isUser) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            msg.provider.orEmpty(),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { clipboard.setText(AnnotatedString(msg.content)) }) {
                            Text("Copy", style = MaterialTheme.typography.labelMedium)
                        }
                        TextButton(onClick = { reporting = true }) {
                            Text("Report", style = MaterialTheme.typography.labelMedium)
                        }
                        if (reporting) AlertDialog(
                            onDismissRequest = { reporting = false },
                            title = { Text("Report this response") },
                            text = {
                                Column {
                                    listOf("Harmful or unsafe", "Inaccurate or misleading", "Hateful or sexual", "Other").forEach { reason ->
                                        TextButton(onClick = { reporting = false; sendReport(ctx, reason, msg.content) }) { Text(reason) }
                                    }
                                }
                            },
                            confirmButton = { TextButton(onClick = { reporting = false }) { Text("Cancel") } }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TypingBubble() {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(20.dp, 20.dp, 20.dp, 4.dp)
    ) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
            Spacer(Modifier.width(10.dp))
            Text("Thinking…", style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun RichText(text: String) {
    val codeBg = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
    val clip = LocalClipboardManager.current
    val parts = text.split("```")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        parts.forEachIndexed { index, part ->
            if (index % 2 == 1) {
                val code = part.substringAfter('\n', part).trimEnd()
                Surface(color = codeBg, shape = RoundedCornerShape(10.dp)) {
                    Column {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { clip.setText(AnnotatedString(code)) }) {
                                Text("Copy code", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        Box(Modifier.horizontalScrollCompat()) {
                            Text(
                                code,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(start = 10.dp, end = 10.dp, bottom = 10.dp)
                            )
                        }
                    }
                }
            } else if (part.isNotBlank()) {
                Text(inline(part.trim(), codeBg), style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}

@Composable
private fun Modifier.horizontalScrollCompat(): Modifier =
    this.then(Modifier.horizontalScroll(rememberScrollState()))

private fun inline(text: String, codeBg: Color): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < text.length) {
        if (text.startsWith("**", i)) {
            val e = text.indexOf("**", i + 2)
            if (e > 0) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(text.substring(i + 2, e)) }
                i = e + 2
                continue
            }
        } else if (text[i] == '`') {
            val e = text.indexOf('`', i + 1)
            if (e > 0) {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)) {
                    append(text.substring(i + 1, e))
                }
                i = e + 1
                continue
            }
        }
        append(text[i])
        i++
    }
}

@Composable
private fun EmptyState(hasKey: Boolean, onSuggestion: (String) -> Unit, onSettings: () -> Unit) {
    val suggestions = listOf(
        "Explain quantum computing in simple words",
        "Write a polite email asking for a deadline extension",
        "Give me a 3-day workout plan for beginners",
        "Help me debug a Kotlin coroutine issue"
    )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        LogoMark(80.dp)
        Spacer(Modifier.height(20.dp))
        Text("How can I help today?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(
            "If one AI model is busy or rate-limited, I automatically try the next one.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 12.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        if (!hasKey) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Add an API key to get started", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Your key stays encrypted on this device.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = onSettings) { Text("Open settings") }
                }
            }
        } else {
            suggestions.forEach {
                OutlinedButton(
                    onClick = { onSuggestion(it) },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) { Text(it, maxLines = 2, overflow = TextOverflow.Ellipsis) }
            }
        }
    }
}

@Composable
private fun ErrorBanner(
    message: String, canRetry: Boolean,
    onRetry: () -> Unit, onDismiss: () -> Unit, onSettings: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.errorContainer,
        contentColor = MaterialTheme.colorScheme.onErrorContainer,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(message, style = MaterialTheme.typography.bodyMedium, maxLines = 4, overflow = TextOverflow.Ellipsis)
            Row {
                if (canRetry) TextButton(onClick = onRetry) { Text("Retry") }
                TextButton(onClick = onSettings) { Text("Settings") }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onDismiss) { Text("Dismiss") }
            }
        }
    }
}

@Composable
private fun InputBar(loading: Boolean, onSend: (String) -> Unit, onStop: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val said = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && !said.isNullOrBlank()) text = (text + " " + said).trim()
    }
    Surface(color = MaterialTheme.colorScheme.background) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message AllRounder AI") },
                maxLines = 6,
                shape = RoundedCornerShape(24.dp),
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
            )
            IconButton(onClick = {
                try {
                    speech.launch(
                        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    )
                } catch (e: ActivityNotFoundException) { /* no speech service on this device */ }
            }) { Text("\uD83C\uDFA4") }
            Spacer(Modifier.width(4.dp))
            FilledIconButton(
                onClick = {
                    if (loading) onStop() else {
                        onSend(text)
                        text = ""
                    }
                },
                enabled = loading || text.isNotBlank(),
                modifier = Modifier.size(52.dp)
            ) {
                if (loading) Icon(Icons.Default.Close, contentDescription = "Stop")
                else Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
            }
        }
    }
}

private fun shareChat(ctx: Context, messages: List<MessageEntity>) {
    val text = messages.joinToString("\n\n") { (if (it.role == "user") "You: " else "AI: ") + it.content }
    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
    ctx.startActivity(Intent.createChooser(send, "Share chat"))
}

private fun sendReport(ctx: Context, reason: String, content: String) {
    val mail = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
        .putExtra(Intent.EXTRA_EMAIL, arrayOf(ctx.getString(R.string.support_email)))
        .putExtra(Intent.EXTRA_SUBJECT, "AI content report: $reason")
        .putExtra(Intent.EXTRA_TEXT, "Reason: $reason\n\nResponse:\n" + content.take(3000))
    try { ctx.startActivity(mail) } catch (e: ActivityNotFoundException) { /* no mail app installed */ }
}
