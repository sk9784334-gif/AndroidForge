package com.allrounder.ai.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

const val DEFAULT_SYSTEM = "You are an expert software engineer and helpful assistant. Help with any legitimate coding task: write, debug, refactor and explain code. Give complete, working code in fenced blocks, and keep explanations short."

data class SettingsState(
    val keys: Map<String, String>,
    val models: Map<String, String>,
    val preferred: String,
    val systemPrompt: String,
    val fallback: Boolean,
    val githubToken: String = "",
    val appLock: Boolean = false,
    val urls: Map<String, String> = emptyMap(),
    val modelPath: String = ""
) {
    val hasKey: Boolean get() = providerOrder().isNotEmpty()

    fun modelFor(spec: ProviderSpec): String =
        models[spec.id]?.takeIf { it.isNotBlank() } ?: spec.defaultModel

    fun providerOrder(): List<ProviderSpec> {
        val ready = PROVIDERS.filter {
            when {
                it.type == ProviderType.ONDEVICE -> modelPath.isNotBlank() && java.io.File(modelPath).exists()
                it.needsKey -> !keys[it.id].isNullOrBlank()
                else -> !urls[it.id].isNullOrBlank()
            }
        }
        val first = ready.firstOrNull { it.id == preferred }
        val rest = ready.filter { it !== first }
        return if (first != null) listOf(first) + rest else rest
    }
}

class SettingsRepo private constructor(context: Context) {
    companion object {
        @Volatile private var inst: SettingsRepo? = null
        fun get(c: Context): SettingsRepo = inst ?: synchronized(this) {
            inst ?: SettingsRepo(c.applicationContext).also { inst = it }
        }
    }

    private val prefs: SharedPreferences = open(context.applicationContext)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<SettingsState> = _state.asStateFlow()

    private fun open(ctx: Context): SharedPreferences {
        fun create(): SharedPreferences {
            val master = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            return EncryptedSharedPreferences.create(
                ctx, "secure_prefs", master,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }
        return try {
            create()
        } catch (e: Exception) {
            // Keystore got reset (e.g. restored device) - start clean instead of crashing.
            runCatching { ctx.deleteSharedPreferences("secure_prefs") }
            try { create() } catch (e2: Exception) { ctx.getSharedPreferences("fallback_prefs", Context.MODE_PRIVATE) }
        }
    }

    private fun load(): SettingsState = SettingsState(
        keys = PROVIDERS.associate { it.id to prefs.getString("key_${it.id}", "").orEmpty() },
        models = PROVIDERS.associate { it.id to prefs.getString("model_${it.id}", "").orEmpty() },
        preferred = prefs.getString("preferred", "gemini") ?: "gemini",
        systemPrompt = prefs.getString("system", DEFAULT_SYSTEM) ?: DEFAULT_SYSTEM,
        fallback = prefs.getBoolean("fallback", true),
        githubToken = prefs.getString("gh_token", "").orEmpty(),
        appLock = prefs.getBoolean("app_lock", false),
        urls = PROVIDERS.associate { it.id to prefs.getString("url_${it.id}", "").orEmpty() },
        modelPath = prefs.getString("model_path", "").orEmpty()
    )

    fun setKey(id: String, value: String) {
        val v = value.trim()
        prefs.edit().putString("key_$id", v).apply()
        _state.update { it.copy(keys = it.keys + (id to v)) }
    }

    fun setModel(id: String, value: String) {
        val v = value.trim()
        prefs.edit().putString("model_$id", v).apply()
        _state.update { it.copy(models = it.models + (id to v)) }
    }

    fun setPreferred(id: String) {
        prefs.edit().putString("preferred", id).apply()
        _state.update { it.copy(preferred = id) }
    }

    fun setSystemPrompt(value: String) {
        prefs.edit().putString("system", value).apply()
        _state.update { it.copy(systemPrompt = value) }
    }

    fun setGithubToken(value: String) {
        val v = value.trim()
        prefs.edit().putString("gh_token", v).apply()
        _state.update { it.copy(githubToken = v) }
    }

    fun setAppLock(value: Boolean) {
        prefs.edit().putBoolean("app_lock", value).apply()
        _state.update { it.copy(appLock = value) }
    }

    fun setUrl(id: String, value: String) {
        val v = value.trim()
        prefs.edit().putString("url_$id", v).apply()
        _state.update { it.copy(urls = it.urls + (id to v)) }
    }

    fun setModelPath(value: String) {
        prefs.edit().putString("model_path", value).apply()
        _state.update { it.copy(modelPath = value) }
    }

    fun setFallback(value: Boolean) {
        prefs.edit().putBoolean("fallback", value).apply()
        _state.update { it.copy(fallback = value) }
    }
}
