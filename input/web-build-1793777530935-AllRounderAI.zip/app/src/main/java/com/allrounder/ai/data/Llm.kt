package com.allrounder.ai.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class ProviderType { OPENAI_COMPAT, GEMINI, ANTHROPIC, ONDEVICE }

data class ProviderSpec(
    val id: String,
    val name: String,
    val type: ProviderType,
    val baseUrl: String,
    val defaultModel: String,
    val keyHint: String,
    val needsKey: Boolean = true
)

val PROVIDERS = listOf(
    ProviderSpec("gemini", "Google Gemini", ProviderType.GEMINI,
        "https://generativelanguage.googleapis.com/v1beta", "gemini-2.5-flash", "AIza..."),
    ProviderSpec("openai", "OpenAI", ProviderType.OPENAI_COMPAT,
        "https://api.openai.com/v1", "gpt-4o-mini", "sk-..."),
    ProviderSpec("anthropic", "Anthropic Claude", ProviderType.ANTHROPIC,
        "https://api.anthropic.com/v1", "claude-haiku-5-5", "sk-ant-..."),
    ProviderSpec("groq", "Groq", ProviderType.OPENAI_COMPAT,
        "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile", "gsk_..."),
    ProviderSpec("openrouter", "OpenRouter", ProviderType.OPENAI_COMPAT,
        "https://openrouter.ai/api/v1", "openai/gpt-4o-mini", "sk-or-..."),
    ProviderSpec("local", "Custom / local server (OpenAI-compatible)", ProviderType.OPENAI_COMPAT,
        "http://127.0.0.1:11434/v1", "qwen2.5-coder:7b", "", needsKey = false),
    ProviderSpec("ondevice", "On-device model (offline)", ProviderType.ONDEVICE,
        "", "", "", needsKey = false)
)

data class Turn(val role: String, val content: String)

class LlmException(message: String) : Exception(message)

object LlmClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .callTimeout(130, TimeUnit.SECONDS)
        .build()

    private val JSON_TYPE = "application/json; charset=utf-8".toMediaType()

    suspend fun complete(
        spec: ProviderSpec,
        apiKey: String,
        model: String,
        system: String,
        history: List<Turn>,
        baseUrl: String? = null
    ): String {
        val request = buildRequest(spec, apiKey, model, system, history, baseUrl)
        val call = http.newCall(request)
        val response = try {
            call.await()
        } catch (e: IOException) {
            throw LlmException("${spec.name}: network error (${e.message ?: "check your connection"})")
        }
        val (code, body) = withContext(Dispatchers.IO) {
            response.use { it.code to (it.body?.string() ?: "") }
        }
        if (code !in 200..299) throw LlmException(errorMessage(spec, code, body))
        val text = try {
            parse(spec.type, body)
        } catch (e: Exception) {
            throw LlmException("${spec.name}: unexpected response from server")
        }
        if (text.isBlank()) throw LlmException("${spec.name}: empty response")
        return text
    }

    private fun buildRequest(
        spec: ProviderSpec, key: String, model: String, system: String, history: List<Turn>, baseUrl: String?
    ): Request {
        val base = (baseUrl?.takeIf { it.isNotBlank() } ?: spec.baseUrl).trimEnd('/')
        return when (spec.type) {
            ProviderType.OPENAI_COMPAT -> {
                val msgs = JSONArray()
                if (system.isNotBlank()) msgs.put(JSONObject().put("role", "system").put("content", system))
                history.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.content)) }
                val body = JSONObject().put("model", model).put("messages", msgs)
                Request.Builder().url("$base/chat/completions")
                    .apply { if (key.isNotBlank()) header("Authorization", "Bearer $key") }
                    .post(body.toString().toRequestBody(JSON_TYPE)).build()
            }
            ProviderType.GEMINI -> {
                val contents = JSONArray()
                history.forEach {
                    val role = if (it.role == "assistant") "model" else "user"
                    contents.put(
                        JSONObject().put("role", role)
                            .put("parts", JSONArray().put(JSONObject().put("text", it.content)))
                    )
                }
                val body = JSONObject().put("contents", contents)
                if (system.isNotBlank()) {
                    body.put(
                        "systemInstruction",
                        JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
                    )
                }
                Request.Builder().url("$base/models/$model:generateContent")
                    .header("x-goog-api-key", key)
                    .post(body.toString().toRequestBody(JSON_TYPE)).build()
            }
            ProviderType.ONDEVICE -> throw LlmException("Not a network provider")
            ProviderType.ANTHROPIC -> {
                val msgs = JSONArray()
                history.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.content)) }
                val body = JSONObject().put("model", model).put("max_tokens", 8192).put("messages", msgs)
                if (system.isNotBlank()) body.put("system", system)
                Request.Builder().url("$base/messages")
                    .header("x-api-key", key)
                    .header("anthropic-version", "2023-06-01")
                    .post(body.toString().toRequestBody(JSON_TYPE)).build()
            }
        }
    }

    private fun parse(type: ProviderType, body: String): String {
        val json = JSONObject(body)
        return when (type) {
            ProviderType.OPENAI_COMPAT ->
                json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
            ProviderType.GEMINI -> {
                val parts = json.getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                buildString { for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text")) }
            }
            ProviderType.ONDEVICE -> ""
            ProviderType.ANTHROPIC -> {
                val blocks = json.getJSONArray("content")
                buildString {
                    for (i in 0 until blocks.length()) {
                        val b = blocks.getJSONObject(i)
                        if (b.optString("type") == "text") append(b.optString("text"))
                    }
                }
            }
        }.trim()
    }

    private fun errorMessage(spec: ProviderSpec, code: Int, body: String): String {
        val detail = runCatching { JSONObject(body).optJSONObject("error")?.optString("message") }
            .getOrNull()?.takeIf { it.isNotBlank() } ?: body.take(160)
        val prefix = when (code) {
            401, 403 -> "API key rejected"
            429 -> "Rate limit or quota reached"
            in 500..599 -> "Server error"
            else -> "Error $code"
        }
        return "${spec.name}: $prefix" + if (detail.isNotBlank()) " - $detail" else ""
    }
}

private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
    cont.invokeOnCancellation { cancel() }
    enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            if (cont.isActive) cont.resumeWithException(e)
        }

        override fun onResponse(call: Call, response: Response) {
            cont.resume(response)
        }
    })
}
