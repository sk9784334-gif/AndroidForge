
package com.allrounder.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.allrounder.ai.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

enum class BuildMode { WEB, APP }

private const val WEB_SYS = "You are a senior web developer. Build the requested website as ONE fully self-contained " +
    "index.html (inline CSS and JS, no external requests, responsive, accessible, modern design). " +
    "Respond with ONLY JSON, no markdown: {\"files\":[{\"path\":\"index.html\",\"content\":\"...\"}]}"

private const val APP_SYS = "You are a senior Android engineer. Generate a complete, buildable Android project: Kotlin 2.0.21, " +
    "Jetpack Compose + Material3, AGP 8.10.1, Gradle Kotlin DSL, compileSdk 36, targetSdk 36, minSdk 26, " +
    "plugins org.jetbrains.kotlin.android and org.jetbrains.kotlin.plugin.compose. Files: settings.gradle.kts, " +
    "build.gradle.kts, gradle.properties (android.useAndroidX=true), app/build.gradle.kts (release buildType must use " +
    "signingConfigs.getByName(\"debug\") so the APK installs), app/src/main/AndroidManifest.xml, Kotlin sources, " +
    "res files incl. strings.xml and themes.xml. Do NOT include gradlew or binary files. Request only the permissions the app needs. " +
    "Keep it compact. Respond with ONLY JSON, no markdown: {\"files\":[{\"path\":\"...\",\"content\":\"...\"}]}"

class BuilderViewModel(app: Application) : AndroidViewModel(app) {
    val settings = SettingsRepo.get(app)
    val busy = MutableStateFlow(false)
    val status = MutableStateFlow("")
    val error = MutableStateFlow<String?>(null)
    val files = MutableStateFlow<List<GenFile>>(emptyList())
    val resultUrl = MutableStateFlow<String?>(null)
    val resultNote = MutableStateFlow("")
    val buildStatus = MutableStateFlow("")
    val canFix = MutableStateFlow(false)
    private var buildLog = ""
    private var lastOwner: String? = null
    private var lastRepo: String? = null
    private var job: Job? = null

    fun generate(mode: BuildMode, prompt: String, refine: Boolean = false) {
        if (busy.value || prompt.isBlank()) return
        val existing = if (refine) files.value else emptyList()
        val userText = if (existing.isEmpty()) prompt.trim() else {
            val arr = JSONArray()
            existing.forEach { arr.put(JSONObject().put("path", it.path).put("content", it.content)) }
            "Current project as JSON:\n" + JSONObject().put("files", arr).toString().take(60000) +
                "\n\nApply this change and return the COMPLETE updated project in the same JSON format:\n" + prompt.trim()
        }
        job = viewModelScope.launch {
            busy.value = true; error.value = null; resultUrl.value = null
            if (!refine) files.value = emptyList()
            status.value = "Generating with AI…"
            try {
                val s = settings.state.value
                val order = s.providerOrder()
                if (order.isEmpty()) { error.value = "Add an AI API key in Settings first."; return@launch }
                var last = "Generation failed"
                for (spec in order) {
                    try {
                        val text = runProvider(
                            getApplication(), spec, s,
                            if (mode == BuildMode.WEB) WEB_SYS else APP_SYS,
                            listOf(Turn("user", userText))
                        )
                        val parsed = parseFiles(text)
                        if (parsed.isEmpty()) throw LlmException("${spec.name}: no files returned")
                        files.value = parsed
                        return@launch
                    } catch (e: LlmException) {
                        last = e.message ?: last
                        if (!s.fallback) break
                    }
                }
                error.value = last
            } finally { busy.value = false; status.value = "" }
        }
    }

    fun checkBuild() {
        val o = lastOwner; val r = lastRepo
        val token = settings.state.value.githubToken
        if (o == null || r == null || token.isBlank() || busy.value) return
        job = viewModelScope.launch {
            busy.value = true; error.value = null
            try {
                val run = GitHubApi(token).latestRun(o, r)
                when {
                    run == null -> buildStatus.value = "No build found yet - try again in a minute"
                    run.status != "completed" -> { buildStatus.value = "Build is still running..."; canFix.value = false }
                    run.conclusion == "success" -> {
                        buildStatus.value = "Build succeeded. Download the APK from Releases."; canFix.value = false
                    }
                    else -> {
                        buildStatus.value = "Build failed"
                        buildLog = GitHubApi(token).failedLog(o, r, run.id)
                        canFix.value = true
                    }
                }
            } catch (e: GitHubException) {
                error.value = e.message
            } finally { busy.value = false }
        }
    }

    fun autoFix() {
        if (!canFix.value || busy.value) return
        canFix.value = false
        generate(BuildMode.APP, "The Gradle build failed with these errors. Fix the project so it compiles:\n" + buildLog, refine = true)
    }

    fun publish(mode: BuildMode, repoRaw: String) {
        val token = settings.state.value.githubToken
        if (token.isBlank()) { error.value = "Add your GitHub token in Settings first."; return }
        val repo = repoRaw.lowercase().replace(Regex("[^a-z0-9-]"), "-").trim('-').take(60)
        if (repo.isEmpty() || files.value.isEmpty() || busy.value) return
        job = viewModelScope.launch {
            busy.value = true; error.value = null
            try {
                val api = GitHubApi(token)
                status.value = "Checking GitHub token…"
                val owner = api.login()
                lastOwner = owner; lastRepo = repo; buildStatus.value = ""; canFix.value = false
                status.value = "Creating $owner/$repo…"
                api.createRepo(repo)
                val toPush = files.value.toMutableList()
                if (mode == BuildMode.APP) {
                    val yml = getApplication<Application>().assets.open("android.yml").bufferedReader().readText()
                    toPush += GenFile(".github/workflows/android.yml", yml)
                }
                toPush.forEachIndexed { i, f ->
                    status.value = "Uploading ${i + 1}/${toPush.size}: ${f.path}"
                    api.putFile(owner, repo, f)
                }
                if (mode == BuildMode.WEB) {
                    api.enablePages(owner, repo)
                    resultUrl.value = "https://$owner.github.io/$repo/"
                    resultNote.value = "Published. The site goes live in 1-2 minutes."
                } else {
                    status.value = "Starting build…"
                    delay(4000)
                    api.dispatchBuild(owner, repo)
                    resultUrl.value = "https://github.com/$owner/$repo/releases"
                    resultNote.value = "Build started (about 5-8 min). Your APK will appear under Releases."
                }
            } catch (e: GitHubException) {
                error.value = e.message
            } finally { busy.value = false; status.value = "" }
        }
    }
}
