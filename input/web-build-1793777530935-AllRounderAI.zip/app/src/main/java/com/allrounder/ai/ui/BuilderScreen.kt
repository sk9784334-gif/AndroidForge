
@file:OptIn(ExperimentalMaterial3Api::class)

package com.allrounder.ai.ui

import android.annotation.SuppressLint
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.viewmodel.compose.viewModel
import com.allrounder.ai.BuildMode
import com.allrounder.ai.BuilderViewModel
import java.io.ByteArrayInputStream

@Composable
fun BuilderScreen(mode: BuildMode, onBack: () -> Unit, onSettings: () -> Unit) {
    val vm: BuilderViewModel = viewModel(key = mode.name)
    val busy by vm.busy.collectAsState()
    val files by vm.files.collectAsState()
    val error by vm.error.collectAsState()
    val status by vm.status.collectAsState()
    val url by vm.resultUrl.collectAsState()
    val note by vm.resultNote.collectAsState()
    val buildStatus by vm.buildStatus.collectAsState()
    val canFix by vm.canFix.collectAsState()
    val isWeb = mode == BuildMode.WEB
    var prompt by rememberSaveable { mutableStateOf("") }
    var repo by rememberSaveable { mutableStateOf(if (isWeb) "my-website" else "my-android-app") }
    var preview by remember { mutableStateOf(false) }
    val uri = LocalUriHandler.current

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(if (isWeb) "Web builder" else "App builder") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    if (isWeb) "Describe a website. AI builds it, you preview it, then host it free on your own GitHub Pages."
                    else "Describe an Android app. AI writes the project, your GitHub builds the APK for you.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = prompt, onValueChange = { prompt = it },
                    label = { Text("What should it be?") },
                    modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 8
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { vm.generate(mode, prompt) },
                    enabled = !busy && prompt.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Generate") }
            }
            if (busy) item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(status)
                }
            }
            error?.let { msg ->
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        contentColor = MaterialTheme.colorScheme.onErrorContainer,
                        shape = MaterialTheme.shapes.medium
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(msg)
                            TextButton(onClick = onSettings) { Text("Open settings") }
                        }
                    }
                }
            }
            if (files.isNotEmpty()) {
                item { Text("${files.size} files ready", fontWeight = FontWeight.SemiBold) }
                item {
                    var change by rememberSaveable { mutableStateOf("") }
                    OutlinedTextField(
                        value = change, onValueChange = { change = it },
                        label = { Text("Change request (optional)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { vm.generate(mode, change, refine = true); change = "" },
                        enabled = !busy && change.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Apply changes") }
                }
                items(files, key = { it.path }) {
                    Text(it.path, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
                }
                if (isWeb) item {
                    OutlinedButton(onClick = { preview = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Preview (sandboxed)")
                    }
                }
                item {
                    OutlinedTextField(
                        value = repo, onValueChange = { repo = it },
                        label = { Text("GitHub repository name") },
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { vm.publish(mode, repo) },
                        enabled = !busy && repo.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (isWeb) "Publish to GitHub Pages" else "Push & build APK on GitHub") }
                }
            }
            url?.let { link ->
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                        Column(Modifier.padding(16.dp)) {
                            Text(note)
                            Spacer(Modifier.height(4.dp))
                            Text(link, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = { uri.openUri(link) }) { Text("Open") }
                            if (!isWeb) {
                                Spacer(Modifier.height(8.dp))
                                OutlinedButton(onClick = { vm.checkBuild() }, enabled = !busy) { Text("Check build status") }
                                if (buildStatus.isNotEmpty()) Text(buildStatus, style = MaterialTheme.typography.bodySmall)
                                if (canFix) {
                                    Spacer(Modifier.height(8.dp))
                                    Button(onClick = { vm.autoFix() }, enabled = !busy) { Text("Auto-fix with AI") }
                                    Text(
                                        "After the fix, tap Push & build again.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (preview) {
        val html = files.firstOrNull { it.path == "index.html" }?.content ?: "<p>No index.html</p>"
        Dialog(onDismissRequest = { preview = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(Modifier.fillMaxSize()) {
                Column(Modifier.statusBarsPadding().navigationBarsPadding()) {
                    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Preview", Modifier.weight(1f).padding(start = 8.dp), fontWeight = FontWeight.SemiBold)
                        TextButton(onClick = { preview = false }) { Text("Close") }
                    }
                    SandboxedWebView(html, Modifier.weight(1f).fillMaxWidth())
                }
            }
        }
    }
}

/** Preview only: JS allowed for the generated page, but no file/content access and every network request is blocked. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun SandboxedWebView(html: String, modifier: Modifier) {
    AndroidView(modifier = modifier, factory = { ctx ->
        WebView(ctx).apply {
            settings.javaScriptEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.domStorageEnabled = false
            settings.setGeolocationEnabled(false)
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val u = request?.url?.toString().orEmpty()
                    return if (u.startsWith("data:") || u == "about:blank") null
                    else WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?) = true
            }
            loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
        }
    }, onRelease = { it.destroy() })
}
