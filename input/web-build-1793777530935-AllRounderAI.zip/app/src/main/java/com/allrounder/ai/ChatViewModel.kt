package com.allrounder.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.allrounder.ai.data.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    val settings = SettingsRepo.get(app)

    val currentChatId = MutableStateFlow<Long?>(null)
    val loading = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)

    val chats: StateFlow<List<ChatEntity>> = dao.chats()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val messages: StateFlow<List<MessageEntity>> = currentChatId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.messages(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var job: Job? = null

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || loading.value) return
        job = viewModelScope.launch {
            val now = System.currentTimeMillis()
            var id = currentChatId.value
            if (id == null) {
                id = dao.insertChat(ChatEntity(title = t.take(48), updatedAt = now))
                currentChatId.value = id
            }
            dao.insertMessage(MessageEntity(chatId = id, role = "user", content = t, provider = null, createdAt = now))
            dao.touch(id, now)
            generate(id)
        }
    }

    fun retry() {
        val id = currentChatId.value ?: return
        if (loading.value) return
        job = viewModelScope.launch { generate(id) }
    }

    fun stop() {
        job?.cancel()
    }

    private suspend fun generate(chatId: Long) {
        error.value = null
        loading.value = true
        try {
            val s = settings.state.value
            val order = s.providerOrder()
            if (order.isEmpty()) {
                error.value = "Add an API key in Settings to start chatting."
                return
            }
            val history = dao.messagesOnce(chatId).map { Turn(it.role, it.content) }
            var last = "Request failed"
            for (spec in order) {
                try {
                    val reply = runProvider(getApplication(), spec, s, s.systemPrompt, history)
                    val now = System.currentTimeMillis()
                    dao.insertMessage(
                        MessageEntity(chatId = chatId, role = "assistant", content = reply, provider = spec.name, createdAt = now)
                    )
                    dao.touch(chatId, now)
                    return
                } catch (e: LlmException) {
                    last = e.message ?: last
                    if (!s.fallback) break
                }
            }
            error.value = last
        } finally {
            loading.value = false
        }
    }

    fun newChat() {
        job?.cancel()
        currentChatId.value = null
        error.value = null
    }

    fun openChat(id: Long) {
        job?.cancel()
        currentChatId.value = id
        error.value = null
    }

    fun deleteChat(id: Long) {
        viewModelScope.launch {
            if (currentChatId.value == id) newChat()
            dao.deleteChat(id)
        }
    }

    fun deleteAll() {
        viewModelScope.launch {
            newChat()
            dao.deleteAll()
        }
    }
}
