# Build report — AllRound AI v2.3.4

## Environment

- Android SDK: `/root/asdk`, compile SDK 36, build-tools 36.0.0
- JDK 17, Gradle wrapper 8.11.1
- ARM64/musl host; Android's x86-64 AAPT2 required the local QEMU wrapper `/root/x86wrap/aapt2`.

## Verification

Command:

```
./gradlew --no-daemon --max-workers=1 -Dorg.gradle.jvmargs=-Xmx1500m \
  -Pandroid.aapt2FromMavenOverride=/root/x86wrap/aapt2 assembleDebug testDebugUnitTest
```

Result: `BUILD SUCCESSFUL`; the current existing unit suite passed (3 model-catalog tests). This confirms compilation, packaging and those unit tests, not device-level testing of every integration.

The debug APK is generated locally for verification. Per the user's request, only the source ZIP is delivered, not the APK.

## Source update

The AllRound AI identity remains `com.allrounder.ai`. The attached legacy project was inspected. Its old upstream repository/release links are not carried into the current project docs; working provider, model and service endpoints remain because those are needed for operation. Its standalone LICENSE file is not included, per the user's instruction.

The attached project is a separate Android app architecture with its own application entry point, storage and native Linux runtime. Its source cannot be added as a pile of files and truthfully described as integrated/working; this release contains the existing AllRound AI app and its polished UI/model-management changes.

## Deliverable

`AllRoundAI-v2.3.4-source.zip`: modified source, excluding build outputs, machine-specific Gradle/SDK configuration and the attached project's standalone LICENSE file. The user's previously requested signing key remains included.
