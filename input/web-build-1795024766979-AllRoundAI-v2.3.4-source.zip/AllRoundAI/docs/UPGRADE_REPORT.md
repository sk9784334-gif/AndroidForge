# AllRounder AI — Upgrade Report (v2.3.2)

## 1. What was analysed

The supplied ZIP (`AllRounderAI.zip`) was extracted and inspected in full: Gradle/Kotlin
build files, `AndroidManifest.xml`, 6,700+ lines of Kotlin (Compose UI, Room database,
OkHttp API clients, MediaPipe on-device inference, Termux/SSH/cloud terminal bridges,
GitHub integration, plugin system, image/backup utilities) plus resources and docs.

The app was already a mature implementation (87 documented features, version 2.2.3).
It was **upgraded in place** — the application id `com.allrounder.ai`, name, branding,
theme, navigation and all existing features were preserved.

## 2. Upgrades implemented in this pass

| # | Requested capability | What now exists | Files |
|---|---|---|---|
| 1 | Hugging Face provider | Added "Hugging Face Inference" as an OpenAI-compatible provider using the HF router (`https://router.huggingface.co/v1`), with the requested default model `Qwen/Qwen2.5-3B-Instruct`. Keys are stored in the existing encrypted store. | `data/Llm.kt` |
| 2 | API key validation / connection test | Each network provider card now has **Test connection**, which sends a tiny real request (no fake status). Errors are shown inline; keys are never logged. | `data/Llm.kt`, `ui/SettingsScreen.kt` |
| 3 | Model discovery | Each network provider card has **Models**, which calls the provider's `/models` endpoint (OpenAI-compatible, Gemini and Anthropic shapes) and lets you pick a discovered model with one tap. | `data/Llm.kt`, `ui/SettingsScreen.kt` |
| 4 | Two command-approval modes (mandatory) | The Terminal now has explicit **Auto approve / Manual approve** mode chips. Auto mode still refuses destructive commands. | `ui/TerminalScreen.kt` |
| 5 | Command allowlist + permitted folders | New settings: comma-separated allowed command programs and permitted folders for the "this phone" backend. Auto mode only auto-runs commands that satisfy both; anything else falls back to manual approval. | `data/Settings.kt`, `TerminalViewModel.kt`, `ui/SettingsScreen.kt` |
| 6 | Edit command before approval | Each proposed command can be edited in place before Approve/Reject. | `TerminalViewModel.kt`, `ui/TerminalScreen.kt` |
| 7 | Local AI Server section | A real in-app OpenAI-compatible HTTP server: `GET /v1/models`, `POST /v1/chat/completions`, backed by the assistant's configured providers/on-device model. Configurable port, optional LAN access (off by default, with warning), status, connection test and live logs. | `data/LocalServer.kt`, `ui/SettingsScreen.kt` |
| 8 | Version bump | `versionCode 19`, `versionName 2.3.2`. | `app/build.gradle.kts` |

All credentials continue to use `EncryptedSharedPreferences` (AES-256). No key is written
to logs or source.

### 2b. Hardening + small model round (same version)

| Requested | What now exists | Files |
|---|---|---|
| Lock the app down | App lock is **on by default**, re-locks the moment you leave the app, and `FLAG_SECURE` (no screenshots / recents previews) is now always applied. Root/custom-firmware and attached-debugger checks show a blocking "device not trusted" screen. | `data/Settings.kt`, `data/DeviceGuard.kt`, `MainActivity.kt` |
| Local server cannot be abused | Every `/v1/*` call now needs a fresh per-start bearer token; browser (`Origin`) requests are rejected; CORS `*` removed; `no-store` + `nosniff` headers added. Token is shown in Settings. | `data/LocalServer.kt`, `ui/SettingsScreen.kt` |
| Small on-device model, auto choice | `ModelCatalog` offers Gemma 3 270M (~289 MB) and Gemma 3 1B (~528 MB) with known-good direct `.task` links and picks one from the phone's RAM and free storage. | `data/ModelCatalog.kt`, `ui/SettingsScreen.kt` |
| One-click download + import | **Download & use (one tap)** downloads the chosen/Recommended model, validates it, makes it primary; **Import model file** keeps the SAF picker for a file you already have. | `ChatViewModel.kt`, `ui/SettingsScreen.kt` |
| No answer brakes in this app | Removed the refusal-priming word "legitimate" from the default system prompt; raised Anthropic output cap 8192 → 16384 and on-device cap 2048 → 4096; doubled on-device context/history limits. | `data/Settings.kt`, `data/Llm.kt`, `data/OnDevice.kt` |

**Honest limit:** a client app cannot switch off a cloud provider's own safety refusals. If
Gemini/OpenAI/Anthropic refuse a request, that decision is made on their servers; only the
app's own wording and caps were removed here. Smaller on-device models have fewer built-in
refusals, which is why the catalog is included — but no jailbreak is claimed.

## 3. Existing features preserved (non-exhaustive)

Multi-provider chat with automatic fallback (Gemini, OpenAI, Anthropic, Groq, OpenRouter,
custom/local OpenAI-compatible endpoint, on-device MediaPipe model), streaming, vision/PDF
attach, web & Android app builders with GitHub Actions builds, GitHub publishing, terminal
with 4 backends (device / Termux / SSH / GitHub cloud) and AI agent, plugins, scheduled
prompts, hands-free voice conversation (speech recognition + TTS), web search (Tavily),
chat search, backups, app lock, themes, widget, Quick Settings tile, Hindi UI and much more.

## 4. Features that need credentials or permissions from you

- **AI providers** — your own API keys (Gemini/OpenAI/Anthropic/Groq/OpenRouter/Hugging Face/Tavily).
- **Hugging Face gated models** — a HF access token with the right repo access.
- **Termux bridge** — Termux installed from F-Droid, `RUN_COMMAND` permission granted, and
  `allow-external-apps=true` set in `~/.termux/termux.properties`.
- **GitHub publishing / APK builds / cloud shell** — a GitHub Personal Access Token (repo, workflow).
- **SSH backend** — host, user and password of your own machine.
- **Voice** — an installed speech-recognition service and TTS engine; mic permission at use time.
- **Notifications / scheduled prompts** — POST_NOTIFICATIONS permission (Android 13+).

## 5. Limitations — honestly stated (not faked)

1. **GGUF / llama.cpp native inference is NOT integrated.** The existing on-device runtime is
   MediaPipe `LlmInference`, which only loads `.task` (Gemma-family) models; `.gguf` files are
   explicitly rejected because they crash its native loader. Adding real llama.cpp JNI inference
   for `Qwen2.5-3B-Instruct-Q4_K_M.gguf` requires compiling the llama.cpp native library with the
   Android NDK/CMake for arm64-v8a and a JNI bridge — a separate native-toolchain effort that
   cannot be honestly delivered as a Gradle-only change here. The HF provider and the local
   server give working access to that model through cloud/HF inference or an external
   llama.cpp-compatible server (e.g. in Termux) pointed at the app's custom-endpoint field;
   the app does **not** claim to run the GGUF file itself.
2. **Local AI Server lifetime** — it is a coroutine scoped to the app process. While the app is
   open it works; Android may kill it in the background. A foreground service with a persistent
   notification would be needed for reliable background hosting. LAN access is off by default
   and now requires a bearer token; browser-origin requests are rejected.
3. **Wake word** — no always-on hotword engine was added. Android one-shot `RecognizerIntent`
   cannot provide a reliable background wake word; a custom hotword/accessibility implementation
   would be required. Voice input, TTS and continuous hands-free conversation already work.
4. **Android automation via Accessibility Service** — no new accessibility service was added;
   the app uses supported Intents, share, camera, file pickers and the Termux bridge it already had.
   Claiming protected-system control would be false.
5. **Full hardware QA** — API connections, GGUF runtime, Termux bridge, voice and APK generation
   depend on your keys, Termux setup and target device (Realme GT Master Edition). These are
   exercised through the in-app self-test and the new Test/Models buttons, but cannot be fully
   verified without those credentials/device.

## 6. Installation

1. Install the APK on the phone (tap Install, then confirm; Android may show Play Protect).
2. Open **Settings → AI providers**, add a key, tap **Test connection**, optionally tap **Models**
   and pick a model, then set your **Primary** provider.
3. For terminal tasks: install Termux (F-Droid), grant the `RUN_COMMAND` permission from the
   Terminal screen and set `allow-external-apps=true` in Termux.
4. For local hosting: **Settings → Local AI server → Start**, copy the shown bearer token, and
   point another app at `http://127.0.0.1:8080/v1` with `Authorization: Bearer <token>`.

## 7. v2.3.2 follow-up

- The chat home now includes a separate, direct-launch card for each major feature. The drawer
  also lists providers, local models, chat search, builders, terminal, plugins, library,
  scheduled tasks, security settings and profile while a conversation is open.
- Local model download/import has a 3 GB ceiling, validates a TFLite signature before replacing
  the active model, stages each operation in a unique temporary file, and cleans old managed
  model files after a successful replacement. Model removal closes the native runtime first.
- A dedicated **Models & downloads** page exposes the existing recommended model, download and
  import controls directly from the home feature grid.
- The reference photo mentioned in the chat was not available in the workspace or screen view;
  this update follows the original app's violet/cyan AllRounder AI identity.
- `assembleDebug` and the existing `testDebugUnitTest` suite succeeded with the local AAPT2
  emulation override. Runtime tests needing API credentials, gated Hugging Face access, Termux,
  or a target-device installation remain dependent on those accounts/device permissions.
