# Design and source update — AllRound AI 2.3.4

- Preserved the AllRound AI name, package ID and violet-to-cyan visual identity.
- Polished the live chat, profile, settings, feature cards and app icon.
- Added a direct home grid for the existing feature sections and a dedicated local-model management screen.
- Hardened local model download and import with staging files, format validation, size limits and safe replacement behavior.
- The source ZIP does not include the reference project's standalone LICENSE file, at the user's request.
- Old upstream project links are excluded from the current project documentation. Functional provider, model and service endpoints remain in code so their features continue to work.
- No APK is attached, per the user's preference.
