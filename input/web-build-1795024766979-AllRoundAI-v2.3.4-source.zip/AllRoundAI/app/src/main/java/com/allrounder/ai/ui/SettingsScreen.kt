@file:OptIn(ExperimentalMaterial3Api::class)

package com.allrounder.ai.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import com.allrounder.ai.data.ProviderType
import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.biometric.BiometricManager
import com.allrounder.ai.LOCK_AUTH
import com.allrounder.ai.R
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.allrounder.ai.ChatViewModel
import com.allrounder.ai.data.LlmClient
import com.allrounder.ai.data.LocalServer
import com.allrounder.ai.data.ModelCatalog
import com.allrounder.ai.data.PROVIDERS
import com.allrounder.ai.data.ProviderSpec
import com.allrounder.ai.data.SettingsState

@Composable
fun SettingsScreen(vm: ChatViewModel, onBack: () -> Unit, onOpenPrivacy: () -> Unit) {
    val st by vm.settings.state.collectAsState()
    var confirmDelete by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0.0"
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(tr("Settings"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
            )
        }
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(tr("AI providers"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Add a key for any provider. The primary one is used first; the others are automatic backups.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            items(PROVIDERS.filter { it.type != ProviderType.ONDEVICE }, key = { it.id }) { spec -> ProviderCard(spec, st, vm) }
            item { OnDeviceCard(st, vm) }
            item { LocalServerCard(vm) }
            item { CommandApprovalCard(st, vm) }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Auto fallback", fontWeight = FontWeight.SemiBold)
                            Text(
                                "Try the next provider if one fails or hits a limit.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(checked = st.fallback, onCheckedChange = { vm.settings.setFallback(it) })
                    }
                }
            }
            item {
                var token by remember { mutableStateOf(st.githubToken) }
                var showTok by remember { mutableStateOf(false) }
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("GitHub hosting", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Needed to publish websites (GitHub Pages) and build APKs (GitHub Actions). Create a classic token " +
                                "with only the repo and workflow scopes. It is sent only to api.github.com. Revoke it any time.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = token,
                            onValueChange = { token = it; vm.settings.setGithubToken(it) },
                            label = { Text("GitHub token") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            visualTransformation = if (showTok) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            trailingIcon = { TextButton(onClick = { showTok = !showTok }) { Text(if (showTok) "Hide" else "Show") } }
                        )
                    }
                }
            }
            item {
                var prompt by remember { mutableStateOf(st.systemPrompt) }
                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it; vm.settings.setSystemPrompt(it) },
                    label = { Text("System prompt") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    maxLines = 6
                )
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Privacy", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "API keys are stored encrypted on this device. Your messages are sent directly " +
                                "from your phone to the provider you choose - there is no AllRounder server in between. " +
                                "Chats are saved only on this device.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            item { AppearanceCard(st, vm) }
            item { GenerationCard(st, vm) }
            item { ImageModelsCard(st, vm) }
            item { PromptsCard(st, vm) }
            item { BackupCard(vm) }
            item { PrivacyCard(vm, onOpenPrivacy) }
            item {
                var tk by remember { mutableStateOf(st.tavilyKey) }
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Web search", fontWeight = FontWeight.SemiBold)
                                Text(
                                    "Adds fresh web results to your questions. Your question text is sent to Tavily (needs a Tavily API key).",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(checked = st.webSearch, onCheckedChange = { vm.settings.setWebSearch(it) })
                        }
                        OutlinedTextField(
                            value = tk,
                            onValueChange = { tk = it; vm.settings.setTavilyKey(it) },
                            label = { Text("Tavily API key") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                        )
                    }
                }
            }
            item {
                var lockMsg by remember { mutableStateOf("") }
                val uri = LocalUriHandler.current
                val policy = ctx.getString(R.string.privacy_url)
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("App lock", fontWeight = FontWeight.SemiBold)
                                Text(
                                    "On by default: fingerprint, face or screen lock needed to open, and it re-locks as soon as you leave the app. Screenshots and previews are always blocked.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(checked = st.appLock, onCheckedChange = { on ->
                                if (!on) { vm.settings.setAppLock(false); lockMsg = "" }
                                else if (BiometricManager.from(ctx).canAuthenticate(LOCK_AUTH) == BiometricManager.BIOMETRIC_SUCCESS) {
                                    vm.settings.setAppLock(true); lockMsg = ""
                                } else lockMsg = "Set a screen lock or fingerprint on your phone first."
                            })
                        }
                        if (lockMsg.isNotEmpty()) Text(lockMsg, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        if (!policy.contains("CHANGE_ME")) TextButton(onClick = { uri.openUri(policy) }) { Text(tr("Privacy policy")) }
                    }
                }
            }
            item { ResetCard(vm) }
            item {
                OutlinedButton(
                    onClick = { confirmDelete = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) { Text(tr("Delete all chats")) }
            }
            item {
                Text(
                    "AllRounder AI  v$version",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete all chats?") },
            text = { Text("This permanently removes every conversation from this device.") },
            confirmButton = {
                TextButton(onClick = { vm.deleteAll(); confirmDelete = false }) { Text(tr("Delete")) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(tr("Cancel")) } }
        )
    }
}

@Composable
fun ModelsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val st by vm.settings.state.collectAsState()
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Models & downloads", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
            )
        }
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Choose a model that fits this phone, download it, or import a supported local model file.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OnDeviceCard(st, vm)
        }
    }
}

@Composable
private fun ProviderCard(spec: ProviderSpec, st: SettingsState, vm: ChatViewModel) {
    var key by remember(spec.id) { mutableStateOf(st.keys[spec.id].orEmpty()) }
    var url by remember(spec.id) { mutableStateOf(st.urls[spec.id].orEmpty()) }
    var model by remember(spec.id) { mutableStateOf(st.models[spec.id]?.takeIf { it.isNotBlank() } ?: spec.defaultModel) }
    var show by remember { mutableStateOf(false) }
    var status by remember(spec.id) { mutableStateOf("") }
    var discovered by remember(spec.id) { mutableStateOf<List<String>>(emptyList()) }
    val scope = rememberCoroutineScope()
    val isPrimary = st.preferred == spec.id
    val active = if (spec.needsKey) key.isNotBlank() else url.isNotBlank()
    val network = spec.type != ProviderType.ONDEVICE

    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                    Text(spec.name.take(1), Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(10.dp))
                Text(
                    spec.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                if (active) {
                    FilterChip(
                        selected = isPrimary,
                        onClick = { vm.settings.setPreferred(spec.id) },
                        label = { Text(if (isPrimary) "Primary" else "Make primary") }
                    )
                }
            }
            OutlinedTextField(
                value = key,
                onValueChange = { key = it; vm.settings.setKey(spec.id, it) },
                label = { Text(if (spec.needsKey) "API key" else "API key (optional)") },
                placeholder = { Text(spec.keyHint) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = { TextButton(onClick = { show = !show }) { Text(if (show) "Hide" else "Show") } }
            )
            if (!spec.needsKey) {
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it; vm.settings.setUrl(spec.id, it) },
                    label = { Text("Server URL (empty = off)") },
                    placeholder = { Text(spec.baseUrl) },
                    supportingText = { Text("Any OpenAI-compatible server. Plain http works only for 127.0.0.1 / localhost; other hosts need https.") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            OutlinedTextField(
                value = model,
                onValueChange = { model = it; vm.settings.setModel(spec.id, it) },
                label = { Text("Model") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            if (network) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = {
                        status = "Testing..."
                        scope.launch {
                            status = try {
                                "Connected · " + LlmClient.testConnection(spec, key, model, url)
                            } catch (e: Exception) { e.message ?: "Failed" }
                        }
                    }) { Text("Test connection") }
                    TextButton(onClick = {
                        status = "Finding models..."
                        scope.launch {
                            try {
                                discovered = LlmClient.discoverModels(spec, key, url)
                                status = discovered.size.toString() + " models found"
                            } catch (e: Exception) { status = e.message ?: "Failed" }
                        }
                    }) { Text("Models") }
                }
                if (status.isNotEmpty()) Text(
                    status, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
    if (discovered.isNotEmpty()) AlertDialog(
        onDismissRequest = { discovered = emptyList() },
        title = { Text("Models · ${spec.name}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                discovered.forEach { m ->
                    Text(m, modifier = Modifier
                        .fillMaxWidth()
                        .clickable { model = m; vm.settings.setModel(spec.id, m); discovered = emptyList() }
                        .padding(vertical = 8.dp))
                }
            }
        },
        confirmButton = { TextButton(onClick = { discovered = emptyList() }) { Text(tr("Close")) } }
    )
}

@Composable
internal fun OnDeviceCard(st: SettingsState, vm: ChatViewModel) {
    val ctx = LocalContext.current
    val importStatus by vm.modelStatus.collectAsState()
    val dlStatus by vm.downloadStatus.collectAsState()
    var url by remember { mutableStateOf("") }
    var hf by remember { mutableStateOf(st.hfToken) }
    var picked by remember { mutableStateOf(ModelCatalog.recommend(ctx).id) }
    val option = ModelCatalog.all.first { it.id == picked }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importModel(uri)
    }
    val has = st.modelPath.isNotBlank()
    val importing = importStatus.startsWith("Importing")
    val downloading = dlStatus.startsWith("Download")
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "On-device model (offline)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                if (has) FilterChip(
                    selected = st.preferred == "ondevice",
                    onClick = { vm.settings.setPreferred("ondevice") },
                    label = { Text(if (st.preferred == "ondevice") "Primary" else "Make primary") }
                )
            }
            Text(
                "Runs fully offline. Pick a model, tap once to download and it becomes primary. " +
                    "Or import a MediaPipe .task file you already have.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                ModelCatalog.reason(ctx) + " Recommended: " + ModelCatalog.recommend(ctx).label,
                style = MaterialTheme.typography.bodySmall
            )
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModelCatalog.all.forEach {
                    FilterChip(selected = picked == it.id, onClick = { picked = it.id },
                        label = { Text(it.label.substringBefore(" (")) })
                }
            }
            Text(option.note, style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(
                onClick = {
                    if (option.needsToken && st.hfToken.isBlank())
                        vm.downloadStatus.value = "Add your free Hugging Face token below first (this model is gated)."
                    else vm.startDownload(option.url)
                },
                enabled = !downloading
            ) { Text(if (downloading) "Downloading..." else "Download & use (one tap)") }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !importing) {
                    Text(if (has) "Replace model" else "Import model file")
                }
                if (has) TextButton(onClick = { vm.removeLocalModel() }, enabled = !importing) {
                    Text(tr("Remove"))
                }
            }
            if (importStatus.isNotEmpty()) Text(importStatus, style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(
                value = hf, onValueChange = { hf = it; vm.settings.setHfToken(it) },
                label = { Text("Hugging Face token (free, for gated models)") },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
            )
            OutlinedTextField(
                value = url, onValueChange = { url = it },
                label = { Text("Or paste any other model link (https)") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            TextButton(onClick = { vm.startDownload(url) }, enabled = url.isNotBlank()) { Text("Download link") }
            if (dlStatus.isNotEmpty()) Text(dlStatus, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun LocalServerCard(vm: ChatViewModel) {
    val running by LocalServer.running.collectAsState()
    val endpoint by LocalServer.endpoint.collectAsState()
    val token by LocalServer.token.collectAsState()
    val logs by LocalServer.logs.collectAsState()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var port by remember { mutableStateOf("8080") }
    var lan by remember { mutableStateOf(false) }
    var probe by remember { mutableStateOf("") }
    SettingsCard("Local AI server") {
        Text(
            "Exposes this app's configured models as an OpenAI-compatible API on the phone: GET /v1/models and " +
                "POST /v1/chat/completions. It runs while the app is open; Android may stop it in the background.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = port, onValueChange = { port = it.filter { c -> c.isDigit() }.take(5) },
                label = { Text("Port") }, singleLine = true, modifier = Modifier.width(110.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Text("LAN access", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                Switch(checked = lan, onCheckedChange = { lan = it }, enabled = !running)
            }
        }
        if (lan) Text(
            "Only on a trusted Wi-Fi. Every call needs the bearer token below, and browser pages are blocked.",
            color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { LocalServer.start(ctx, vm.settings, port.toIntOrNull() ?: 8080, lan) }, enabled = !running) { Text("Start") }
            OutlinedButton(onClick = { LocalServer.stop() }, enabled = running) { Text("Stop") }
            TextButton(onClick = { scope.launch { probe = LocalServer.probe(endpoint) } }, enabled = running) { Text("Test") }
        }
        Text("Endpoint: $endpoint", style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
        if (token.isNotBlank()) SelectionContainer {
            Text("Bearer token: $token", style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
        }
        Text("Clients must send Authorization: Bearer <token>. The token changes on every start.",
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (probe.isNotEmpty()) Text(probe, style = MaterialTheme.typography.bodySmall)
        if (logs.isNotEmpty()) {
            Text("Logs", style = MaterialTheme.typography.labelLarge)
            SelectionContainer {
                Text(logs.takeLast(12).joinToString("\n"), fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = { LocalServer.clearLogs() }) { Text("Clear logs") }
        }
    }
}

@Composable
private fun CommandApprovalCard(st: SettingsState, vm: ChatViewModel) = SettingsCard("Command approval (Termux)") {
    Text(
        "Auto-approve runs only commands whose program is listed here; leave empty to allow any non-destructive command. " +
            "Destructive commands always need your tap. Permitted folders confine 'this phone' commands.",
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    var allow by remember { mutableStateOf(st.termAllowlist) }
    OutlinedTextField(
        value = allow, onValueChange = { allow = it; vm.settings.setTermAllowlist(it) },
        label = { Text("Allowed commands (comma separated)") },
        placeholder = { Text("ls, cat, echo, mkdir, cp, git, python3, pip, pkg") },
        minLines = 2, modifier = Modifier.fillMaxWidth()
    )
    var folders by remember { mutableStateOf(st.termFolders) }
    OutlinedTextField(
        value = folders, onValueChange = { folders = it; vm.settings.setTermFolders(it) },
        label = { Text("Permitted folders on this phone (one per line)") },
        placeholder = { Text("/storage/emulated/0/Documents") },
        minLines = 2, modifier = Modifier.fillMaxWidth()
    )
}

@Composable
internal fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.size(width = 4.dp, height = 20.dp).background(MaterialTheme.colorScheme.primary, RoundedCornerShape(4.dp)))
                Text(tr(title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            content()
        }
    }
}

@Composable
internal fun AppearanceCard(st: SettingsState, vm: ChatViewModel) = SettingsCard("Appearance") {
    Text("Theme", style = MaterialTheme.typography.labelLarge)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("system" to "System", "light" to "Light", "dark" to "Dark").forEach { (k, l) ->
            FilterChip(selected = st.theme == k, onClick = { vm.settings.setTheme(k) }, label = { Text(l) })
        }
    }
    Text("Text size", style = MaterialTheme.typography.labelLarge)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(0.85f to "S", 1f to "M", 1.15f to "L", 1.3f to "XL").forEach { (v, l) ->
            FilterChip(selected = st.fontScale == v, onClick = { vm.settings.setFontScale(v) }, label = { Text(l) })
        }
    }
    Text("Accent colour", style = MaterialTheme.typography.labelLarge)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("violet", "cyan", "green", "orange", "pink").forEach { a ->
            FilterChip(
                selected = st.accent == a,
                onClick = { vm.settings.setAccent(a) },
                label = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Box(Modifier.size(12.dp).background(accentFor(a) ?: BrandViolet, CircleShape))
                        Text(a.replaceFirstChar { it.uppercase() })
                    }
                }
            )
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Block screenshots", fontWeight = FontWeight.SemiBold)
            Text(
                "Hides the app in recent apps and blocks screen capture.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = st.blockShots, onCheckedChange = { vm.settings.setBlockShots(it) })
    }
}

@Composable
private fun GenerationCard(st: SettingsState, vm: ChatViewModel) = SettingsCard("Replies") {
    var lang by remember { mutableStateOf(st.replyLang) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Custom creativity (temperature)", fontWeight = FontWeight.SemiBold)
            Text(
                "Off = each provider's default. Some newer models only accept their default.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(
            checked = st.temperature >= 0f,
            onCheckedChange = { vm.settings.setTemperature(if (it) 0.7f else -1f) }
        )
    }
    if (st.temperature >= 0f) {
        Slider(value = st.temperature, onValueChange = { vm.settings.setTemperature(it) }, valueRange = 0f..1.5f)
        Text(String.format("%.2f", st.temperature), style = MaterialTheme.typography.bodySmall)
    }
    Text("Answer length", style = MaterialTheme.typography.labelLarge)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("short" to "Short", "normal" to "Normal", "detailed" to "Detailed").forEach { (k, l) ->
            FilterChip(selected = st.lengthPreset == k, onClick = { vm.settings.setLengthPreset(k) }, label = { Text(l) })
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Auto-name new chats with AI", Modifier.weight(1f))
        Switch(checked = st.autoTitle, onCheckedChange = { vm.settings.setAutoTitle(it) })
    }
    OutlinedTextField(
        value = lang,
        onValueChange = { lang = it; vm.settings.setReplyLang(it) },
        label = { Text("Reply language (e.g. Hinglish, Hindi, English)") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun PromptsCard(st: SettingsState, vm: ChatViewModel) = SettingsCard("Prompt library") {
    var newP by remember { mutableStateOf("") }
    Text(
        "Saved prompts show up under the sparkle button in the message box.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    st.prompts.forEachIndexed { i, p ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(p, Modifier.weight(1f), maxLines = 2)
            TextButton(onClick = { vm.settings.setPrompts(st.prompts.filterIndexed { j, _ -> j != i }) }) { Text(tr("Delete")) }
        }
    }
    OutlinedTextField(
        value = newP, onValueChange = { newP = it },
        label = { Text("New prompt") }, modifier = Modifier.fillMaxWidth()
    )
    Button(onClick = {
        if (newP.isNotBlank()) { vm.settings.setPrompts(st.prompts + newP.trim()); newP = "" }
    }) { Text("Add prompt") }
}

@Composable
private fun BackupCard(vm: ChatViewModel) = SettingsCard("Backup") {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            msg = try { "Restored " + vm.importBackup(uri, pass) + " chats" } catch (e: Exception) { "Restore failed: wrong passphrase or not a valid backup file" }
        }
    }
    Text(
        "Exports chat text only (no images, keys or tokens) as a plain JSON file. Keep it private.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    OutlinedTextField(
        value = pass, onValueChange = { pass = it },
        label = { Text("Passphrase (optional, encrypts the backup)") },
        singleLine = true, modifier = Modifier.fillMaxWidth(),
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = {
            scope.launch {
                try {
                    val u = vm.exportBackup(pass)
                    val send = Intent(Intent.ACTION_SEND).setType(if (pass.isBlank()) "application/json" else "application/octet-stream")
                        .putExtra(Intent.EXTRA_STREAM, u)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    ctx.startActivity(Intent.createChooser(send, "Save backup"))
                } catch (e: Exception) {
                    msg = "Export failed"
                }
            }
        }) { Text("Export chats") }
        OutlinedButton(onClick = { picker.launch(arrayOf("application/json", "*/*")) }) { Text("Restore") }
    }
    if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall)
}

@Composable
private fun PrivacyCard(vm: ChatViewModel, onOpenPrivacy: () -> Unit) = SettingsCard("Privacy policy") {
    val status by vm.policyStatus.collectAsState()
    Text(
        "Read the policy built into this app. Play Console also needs a public URL: Publish page puts the same policy " +
            "on your own GitHub Pages (needs the GitHub token above).",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = onOpenPrivacy) { Text("Read policy") }
        OutlinedButton(onClick = { vm.publishPolicy() }) { Text("Publish page") }
    }
    if (status.isNotEmpty()) SelectionContainer { Text(status, style = MaterialTheme.typography.bodySmall) }
}

@Composable
private fun ResetCard(vm: ChatViewModel) {
    var confirm by remember { mutableStateOf(false) }
    OutlinedButton(
        onClick = { confirm = true },
        modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
    ) { Text("Reset app (keys, settings, chats)") }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Reset everything?") },
        text = { Text("Deletes all chats, API keys, tokens and settings on this device. This cannot be undone.") },
        confirmButton = {
            TextButton(onClick = { vm.settings.resetAll(); vm.deleteAll(); confirm = false }) { Text("Reset") }
        },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text(tr("Cancel")) } }
    )
}

@Composable
private fun ImageModelsCard(st: SettingsState, vm: ChatViewModel) = SettingsCard("AI images (Web builder)") {
    var openai by remember { mutableStateOf(st.models["img_openai"].orEmpty()) }
    var gemini by remember { mutableStateOf(st.models["img_gemini"].orEmpty()) }
    Text(
        "Uses your OpenAI key if present, otherwise your Gemini key. Billed by the provider; some image models need a paid plan. " +
            "Leave empty for the defaults (gpt-image-1 / gemini-2.5-flash-image).",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    OutlinedTextField(
        value = openai, onValueChange = { openai = it; vm.settings.setModel("img_openai", it) },
        label = { Text("OpenAI image model") }, singleLine = true, modifier = Modifier.fillMaxWidth()
    )
    OutlinedTextField(
        value = gemini, onValueChange = { gemini = it; vm.settings.setModel("img_gemini", it) },
        label = { Text("Gemini image model") }, singleLine = true, modifier = Modifier.fillMaxWidth()
    )
}
