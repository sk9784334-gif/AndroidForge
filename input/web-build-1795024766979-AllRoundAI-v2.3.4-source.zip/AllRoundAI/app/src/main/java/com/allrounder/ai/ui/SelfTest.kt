
@file:OptIn(ExperimentalMaterial3Api::class)

package com.allrounder.ai.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.provider.MediaStore
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.util.Base64
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.allrounder.ai.data.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.ByteArrayOutputStream
import java.io.File

data class TestResult(val name: String, val ok: Boolean, val detail: String)

private suspend fun runSelfTests(ctx: Context, onResult: (TestResult) -> Unit) {
    suspend fun t(name: String, block: suspend () -> String) {
        val r = try {
            TestResult(name, true, withTimeout(40_000) { block() })
        } catch (e: TimeoutCancellationException) {
            TestResult(name, false, "timed out")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            TestResult(name, false, e.javaClass.simpleName + ": " + (e.message ?: ""))
        }
        onResult(r)
    }
    val repo = SettingsRepo.get(ctx)
    val s = repo.state.value
    val pm = ctx.packageManager

    t("Database") { "OK, " + AppDb.get(ctx).dao().allChats().size + " chats stored" }
    t("Encrypted settings") { if (repo.secure) "OK" else error("Encrypted storage unavailable on this phone; using a plain fallback") }
    t("Internet") {
        withContext(Dispatchers.IO) {
            OkHttpClient().newCall(Request.Builder().url("https://api.github.com/zen").build()).execute().use { "reachable (HTTP " + it.code + ")" }
        }
    }
    t("AI provider") {
        val spec = s.providerOrder().firstOrNull() ?: error("No provider with an API key or server URL yet (Settings)")
        val r = runProvider(ctx, spec, s, "Reply with the single word OK.", listOf(Turn("user", "ping")))
        spec.name + " answered: " + r.take(40)
    }
    t("GitHub token") {
        if (s.githubToken.isBlank()) error("No GitHub token (needed for builders, cloud shell, privacy page)")
        "logged in as " + GitHubApi(s.githubToken).login()
    }
    t("Terminal: this phone") {
        val r = TerminalEngine.exec(ctx, Backend.DEVICE, "echo hello", null, "")
        if (!r.output.contains("hello")) error("unexpected output: " + r.output.take(80))
        "OK (limited shell, no python)"
    }
    t("Terminal: Termux") {
        try { pm.getPackageInfo("com.termux", 0) } catch (e: Exception) { error("Termux not installed (optional)") }
        if (ctx.checkSelfPermission(TerminalEngine.TERMUX_PERMISSION) != PackageManager.PERMISSION_GRANTED) {
            error("installed, but permission not granted yet (Terminal screen > Grant)")
        }
        "installed and permitted"
    }
    t("Images (attach/save)") {
        val bmp = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
        val bos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, bos)
        val ids = ImageStore.saveAll(ctx, Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP))
        if (ImageStore.b64All(ctx, ids).isBlank() || ImageStore.bitmap(ctx, ids) == null) error("could not read the saved image back")
        "OK"
    }
    t("Photo picker") { if (ActivityResultContracts.PickVisualMedia.isPhotoPickerAvailable(ctx)) "available" else error("not available on this phone") }
    t("Camera app") { if (pm.queryIntentActivities(Intent(MediaStore.ACTION_IMAGE_CAPTURE), 0).isNotEmpty()) "found" else error("no camera app found") }
    t("Speech input") { if (pm.queryIntentActivities(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH), 0).isNotEmpty()) "found" else error("no speech service (install Google app)") }
    t("Text-to-speech") {
        if (pm.queryIntentServices(Intent(TextToSpeech.Engine.INTENT_ACTION_TTS_SERVICE), 0).isNotEmpty()) "engine found" else error("no TTS engine installed")
    }
    t("Notifications") {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            error("permission not granted (needed for scheduled prompts and build alerts)") else "OK"
    }
    t("Storage") { "free: " + (ctx.filesDir.usableSpace / 1048576) + " MB" }
    t("Memory") {
        val am = ctx.getSystemService(android.app.ActivityManager::class.java)
        val mi = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        "total " + (mi.totalMem / 1048576) + " MB, free " + (mi.availMem / 1048576) + " MB"
    }
    t("On-device model") {
        if (s.modelPath.isBlank()) error("no model imported (optional)")
        val f = File(s.modelPath)
        if (!f.exists()) error("model file missing")
        if (!OnDeviceLlm.looksValid(s.modelPath)) error("wrong format: not a MediaPipe .task file")
        OnDeviceLlm.memoryProblem(ctx, s.modelPath)?.let { error(it) }
        "OK, " + (f.length() / 1048576) + " MB"
    }
    t("Last crash") { CrashLog.read(ctx)?.lineSequence()?.firstOrNull { it.startsWith("java") || it.contains("Exception") }?.let { error(it) } ?: "none recorded" }
}

@Composable
fun SelfTestScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    var results by remember { mutableStateOf<List<TestResult>>(emptyList()) }
    var running by remember { mutableStateOf(false) }
    val report = results.joinToString("\n") { (if (it.ok) "[OK] " else "[FAIL] ") + it.name + ": " + it.detail }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Self-test", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = MaterialTheme.colorScheme.primary) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
            )
        }
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad),
            contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Text(
                    "Checks every feature on this phone and shows exactly which one fails and why. Send me a screenshot or the copied report.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        enabled = !running,
                        onClick = {
                            running = true
                            results = emptyList()
                            scope.launch {
                                try { runSelfTests(ctx) { results = results + it } } finally { running = false }
                            }
                        }
                    ) { Text(if (running) "Running..." else "Run self-test") }
                    OutlinedButton(enabled = results.isNotEmpty(), onClick = { clip.setText(AnnotatedString(report)) }) { Text("Copy report") }
                }
            }
            items(results) { r ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(12.dp)) {
                        Text((if (r.ok) "\u2705 " else "\u274C ") + r.name, fontWeight = FontWeight.SemiBold)
                        Text(r.detail, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
