package com.allrounder.ai.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

val BrandViolet = Color(0xFF6348E8)
val BrandCyan = Color(0xFF14B8CF)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

private val Dark = darkColorScheme(
    primary = Color(0xFFA89BFF),
    onPrimary = Color(0xFF21164E),
    primaryContainer = Color(0xFF342667),
    onPrimaryContainer = Color(0xFFEAE5FF),
    secondary = Color(0xFF63D9E8),
    onSecondary = Color(0xFF00363E),
    background = Color(0xFF0C1020),
    onBackground = Color(0xFFF2F0FF),
    surface = Color(0xFF101528),
    onSurface = Color(0xFFF2F0FF),
    surfaceVariant = Color(0xFF1D2541),
    onSurfaceVariant = Color(0xFFC4C5E0),
    surfaceContainer = Color(0xFF151B31),
    surfaceContainerHigh = Color(0xFF202844),
    outline = Color(0xFF596181),
    outlineVariant = Color(0xFF343D5D),
    error = Color(0xFFFF6B7A),
    errorContainer = Color(0xFF4A1620),
    onErrorContainer = Color(0xFFFFD9DD)
)

private val Light = lightColorScheme(
    primary = Color(0xFF5B43D6),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE6E2FF),
    onPrimaryContainer = Color(0xFF1B1550),
    secondary = Color(0xFF007F98),
    onSecondary = Color.White,
    background = Color(0xFFF6F4FF),
    onBackground = Color(0xFF211B38),
    surface = Color(0xFFFCFBFF),
    onSurface = Color(0xFF211B38),
    surfaceVariant = Color(0xFFECE9F8),
    onSurfaceVariant = Color(0xFF5A5570),
    surfaceContainer = Color(0xFFFFFFFF),
    surfaceContainerHigh = Color(0xFFEAE6FF),
    outline = Color(0xFFAAA2C5),
    outlineVariant = Color(0xFFD9D3EB),
    error = Color(0xFFBA1A2B),
    errorContainer = Color(0xFFFFDADD),
    onErrorContainer = Color(0xFF410009)
)

fun accentFor(name: String): Color? = when (name) {
    "cyan" -> Color(0xFF007F98)
    "green" -> Color(0xFF007D59)
    "orange" -> Color(0xFFB34F0B)
    "pink" -> Color(0xFFB52D78)
    else -> null
}

@Composable
fun AllRounderTheme(
    dark: Boolean = isSystemInDarkTheme(),
    accent: Color? = null,
    fontScale: Float = 1f,
    content: @Composable () -> Unit
) {
    val base = if (dark) Dark else Light
    val scheme = if (accent != null) base.copy(
        primary = accent,
        onPrimary = if (dark) Color(0xFF11102B) else Color.White
    ) else base
    val d = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(d.density, d.fontScale * fontScale)) {
        MaterialTheme(colorScheme = scheme, shapes = AppShapes, content = content)
    }
}
