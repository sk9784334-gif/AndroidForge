package com.allrounder.ai.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * A small OpenAI-compatible HTTP server that runs inside the app. It exposes the models this
 * assistant already has (API providers or the on-device model) on localhost, so other apps on the
 * phone can use them. It never opens to the network unless the user explicitly allows LAN access.
 */
object LocalServer {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var socket: ServerSocket? = null

    val running = kotlinx.coroutines.flow.MutableStateFlow(false)
    val endpoint = kotlinx.coroutines.flow.MutableStateFlow("http://127.0.0.1:8080/v1")
    val logs = kotlinx.coroutines.flow.MutableStateFlow<List<String>>(emptyList())

    private val probeHttp = OkHttpClient.Builder().callTimeout(5, TimeUnit.SECONDS).build()

    private fun log(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        logs.value = (logs.value + "[$t] $msg").takeLast(200)
    }

    fun clearLogs() { logs.value = emptyList() }

    fun start(ctx: Context, repo: SettingsRepo, port: Int, lan: Boolean) {
        if (running.value) return
        endpoint.value = "http://127.0.0.1:$port/v1"
        job = scope.launch {
            try {
                val host = if (lan) "0.0.0.0" else "127.0.0.1"
                socket = ServerSocket().apply {
                    reuseAddress = true
                    bind(InetSocketAddress(host, port))
                }
                running.value = true
                log("Listening on $host:$port" + if (lan) " (LAN access enabled)" else "")
                while (isActive) {
                    val client = try { socket!!.accept() } catch (e: Exception) { break }
                    launch { handle(client, ctx, repo) }
                }
            } catch (e: Exception) {
                log("Could not start: ${e.message}")
                running.value = false
            } finally {
                running.value = false
                log("Stopped")
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        runCatching { socket?.close() }
        socket = null
        running.value = false
    }

    /** Quick check that the endpoint responds. Returns a human-readable result. */
    suspend fun probe(base: String): String = withContext(Dispatchers.IO) {
        try {
            val url = base.trimEnd('/').removeSuffix("/v1") + "/v1/models"
            val req = Request.Builder().url(url).get().build()
            probeHttp.newCall(req).execute().use { r ->
                val body = r.body?.string().orEmpty()
                if (r.isSuccessful) {
                    val n = runCatching { JSONObject(body).optJSONArray("data")?.length() ?: 0 }.getOrDefault(0)
                    "OK · $n model(s) exposed"
                } else "HTTP ${r.code}"
            }
        } catch (e: Exception) { "Unreachable: ${e.message}" }
    }

    private suspend fun handle(client: java.net.Socket, ctx: Context, repo: SettingsRepo) {
        try {
            val reader = BufferedReader(InputStreamReader(client.getInputStream(), Charsets.UTF_8))
            val requestLine = reader.readLine() ?: return
            val parts = requestLine.split(" ")
            val method = parts.getOrNull(0) ?: return
            val path = parts.getOrNull(1) ?: return
            var length = 0
            while (true) {
                val header = reader.readLine() ?: break
                if (header.isEmpty()) break
                if (header.startsWith("Content-Length:", ignoreCase = true)) {
                    length = header.substringAfter(':').trim().toIntOrNull() ?: 0
                }
            }
            val body = if (length > 0) {
                val buf = CharArray(length)
                var off = 0
                while (off < length) {
                    val n = reader.read(buf, off, length - off)
                    if (n < 0) break
                    off += n
                }
                String(buf, 0, off)
            } else ""

            when {
                path.startsWith("/v1/models") && method == "GET" -> {
                    val s = repo.state.value
                    val arr = JSONArray()
                    s.providerOrder().forEach { spec ->
                        val id = s.models[spec.id].takeIf { !it.isNullOrBlank() }
                            ?: if (spec.type == com.allrounder.ai.data.ProviderType.ONDEVICE) "on-device" else spec.defaultModel
                        arr.put(JSONObject().put("id", id).put("object", "model").put("owned_by", spec.id))
                    }
                    send(client, 200, JSONObject().put("object", "list").put("data", arr).toString())
                    log("GET /v1/models")
                }
                path.startsWith("/v1/chat/completions") && method == "POST" -> {
                    val json = JSONObject(body)
                    val requested = json.optString("model")
                    val messages = json.optJSONArray("messages")
                    val history = mutableListOf<Turn>()
                    var system = ""
                    if (messages != null) for (i in 0 until messages.length()) {
                        val m = messages.getJSONObject(i)
                        when (m.optString("role")) {
                            "system" -> system = m.optString("content")
                            "assistant" -> history += Turn("assistant", m.optString("content"))
                            "user" -> history += Turn("user", m.optString("content"))
                        }
                    }
                    val s = repo.state.value
                    val spec = s.providerOrder().firstOrNull { requested.isBlank() || it.id == requested || s.modelFor(it) == requested }
                        ?: s.providerOrder().firstOrNull()
                        ?: throw LlmException("No AI provider is configured")
                    val answer = runProvider(ctx, spec, s, system, history)
                    val out = JSONObject()
                        .put("id", "chatcmpl-" + UUID.randomUUID())
                        .put("object", "chat.completion")
                        .put("created", System.currentTimeMillis() / 1000)
                        .put("model", requested.ifBlank { s.modelFor(spec) })
                        .put("choices", JSONArray().put(
                            JSONObject().put("index", 0)
                                .put("message", JSONObject().put("role", "assistant").put("content", answer))
                                .put("finish_reason", "stop")))
                    send(client, 200, out.toString())
                    log("POST /v1/chat/completions via ${spec.name} (${answer.length} chars)")
                }
                else -> send(client, 404, JSONObject().put("error", JSONObject().put("message", "not found")).toString())
            }
        } catch (e: Exception) {
            log("Request error: ${e.message}")
            runCatching { send(client, 500, JSONObject().put("error", JSONObject().put("message", e.message ?: "error")).toString()) }
        } finally {
            runCatching { client.close() }
        }
    }

    private fun send(client: java.net.Socket, code: Int, body: String) {
        val reason = if (code == 200) "OK" else if (code == 404) "Not Found" else "Error"
        val bytes = body.toByteArray(Charsets.UTF_8)
        val head = "HTTP/1.1 $code $reason\r\nContent-Type: application/json; charset=utf-8\r\n" +
            "Content-Length: ${bytes.size}\r\nConnection: close\r\nAccess-Control-Allow-Origin: *\r\n\r\n"
        client.getOutputStream().write(head.toByteArray(Charsets.UTF_8))
        client.getOutputStream().write(bytes)
        client.getOutputStream().flush()
    }
}
