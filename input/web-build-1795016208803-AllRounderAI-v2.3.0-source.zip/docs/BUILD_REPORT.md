# Build report — AllRounder AI v2.3.0

## Environment prepared

- Android SDK command-line tools installed at `/root/asdk`
- `platforms;android-36`, `build-tools;36.0.0`, `platform-tools` installed
- Licenses accepted
- JDK 17 (Alpine OpenJDK), Gradle 8.11.1 via the project wrapper
- `local.properties` points to `/root/asdk` (excluded from the source ZIP)

## Build commands

```
./gradlew assembleDebug --no-daemon      # validation build
./gradlew assembleRelease --no-daemon    # final deliverable APK
```

R8 minification is opt-in in this project (`-Pminify=true`) because MediaPipe, JSch and Tink
use reflection; the default release build keeps them intact.

## Source changes in this upgrade

- `app/src/main/java/com/allrounder/ai/data/Llm.kt` — Hugging Face provider,
  `discoverModels()`, `testConnection()`.
- `app/src/main/java/com/allrounder/ai/data/Settings.kt` — persisted Termux allowlist and
  permitted folders; version bumped in `app/build.gradle.kts` (17 / 2.3.0).
- `app/src/main/java/com/allrounder/ai/TerminalViewModel.kt` — allowlist/folder enforcement
  in auto mode, editable proposals.
- `app/src/main/java/com/allrounder/ai/ui/TerminalScreen.kt` — Auto/Manual mode chips,
  dangerous-command warning, edit-before-approve UI.
- `app/src/main/java/com/allrounder/ai/data/LocalServer.kt` — new in-app OpenAI-compatible
  HTTP server (localhost by default, optional LAN).
- `app/src/main/java/com/allrounder/ai/ui/SettingsScreen.kt` — Test/Models buttons, local
  server card, command-approval card.
- `docs/UPGRADE_REPORT.md` — feature map and honest limitations.

## Verification status

See `UPGRADE_REPORT.md` §5 for what cannot be verified without your API keys, Termux setup
and target device. Compile/build status is recorded in the final chat message and in the
`APK_SHA256.txt` file next to the deliverable APK.

## Deliverables

- `AllRounderAI-v2.3.0.apk` — installable APK (signed with the debug key because no
  `keystore.properties` was supplied; provide one for a Play release-signed build).
- `AllRounderAI-v2.3.0-source.zip` — complete modified source (build outputs and local
  machine paths excluded).
