package com.allrounder.ai.data

import android.app.ActivityManager
import android.content.Context

/** A small, curated set of on-device models with known-good direct links. */
data class ModelOption(
    val id: String,
    val label: String,
    val url: String,
    val sizeMb: Int,
    val minRamGb: Int,
    val note: String
) {
    val needsToken: Boolean get() = url.contains("huggingface.co")
}

object ModelCatalog {
    val all = listOf(
        ModelOption(
            "gemma-3-270m", "Gemma 3 270M (smallest, ~289 MB)",
            "https://huggingface.co/litert-community/gemma-3-270m-it/resolve/main/gemma3-270m-it-q8.task",
            289, 3, "Gated: needs a free Hugging Face token and one-time license acceptance."
        ),
        ModelOption(
            "gemma-3-1b", "Gemma 3 1B (better answers, ~528 MB)",
            "https://huggingface.co/litert-community/Gemma3-1B-IT/resolve/main/Gemma3-1B-IT_multi-prefill-seq_q4_ekv2048.task",
            528, 6, "Gated: needs a free Hugging Face token and one-time license acceptance."
        )
    )

    private fun ramGb(ctx: Context): Int {
        val info = ActivityManager.MemoryInfo()
        ctx.getSystemService(ActivityManager::class.java)?.getMemoryInfo(info)
        return (info.totalMem / (1024L * 1024 * 1024)).toInt()
    }

    private fun freeMb(ctx: Context): Long = ctx.filesDir.getUsableSpace() / (1024 * 1024)

    /** Best model that fits this much RAM and free storage; smallest as a fallback. */
    fun choose(ramGb: Int, freeMb: Long): ModelOption =
        all.filter { it.minRamGb <= ramGb && it.sizeMb + 300L <= freeMb }
            .maxByOrNull { it.sizeMb } ?: all.first()

    /** Best model this phone can actually run and store. */
    fun recommend(ctx: Context): ModelOption = choose(ramGb(ctx), freeMb(ctx))

    fun reason(ctx: Context): String = "This phone: ~${ramGb(ctx)} GB RAM, ${freeMb(ctx) / 1024} GB free storage."
}
