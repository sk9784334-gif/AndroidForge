package com.allrounder.ai.data

import android.os.Build
import android.os.Debug
import java.io.File

/**
 * Cheap tamper signals for the "locked down" mode. These raise the bar for casual meddling;
 * they are not a sandbox and cannot stop a determined owner of the device.
 */
object DeviceGuard {
    private val suPaths = listOf(
        "/system/app/Superuser.apk", "/system/bin/su", "/system/xbin/su",
        "/sbin/su", "/data/local/xbin/su", "/data/local/su", "/su/bin/su"
    )

    fun isRooted(): Boolean = suPaths.any { File(it).exists() } || Build.TAGS.contains("test-keys", true)
    fun debuggerAttached(): Boolean = Debug.isDebuggerConnected()
    fun isLockedDown(): Boolean = isRooted() || debuggerAttached()

    fun reasons(): String = buildList {
        if (isRooted()) add("root / custom firmware detected")
        if (debuggerAttached()) add("a debugger is attached")
    }.joinToString("; ")
}
