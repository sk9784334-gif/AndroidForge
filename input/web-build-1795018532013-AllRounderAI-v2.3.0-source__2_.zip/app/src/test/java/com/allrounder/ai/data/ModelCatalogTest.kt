package com.allrounder.ai.data

import org.junit.Assert.assertEquals
import org.junit.Test

class ModelCatalogTest {
    @Test
    fun `low ram falls back to smallest`() {
        assertEquals("gemma-3-270m", ModelCatalog.choose(2, 1000).id)
    }

    @Test
    fun `bigger phone gets the bigger model`() {
        assertEquals("gemma-3-1b", ModelCatalog.choose(8, 4096).id)
    }

    @Test
    fun `low storage falls back to smallest`() {
        assertEquals("gemma-3-270m", ModelCatalog.choose(12, 100).id)
    }
}
