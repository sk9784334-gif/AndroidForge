# Security review — AllRounder AI v2.3.0 (hardened)

Code-level review of what the shipped source actually does. No device penetration test was run.

## What is done well

- **Secrets at rest** — provider keys, HF token, GitHub token, Tavily key and SSH password live in
  `EncryptedSharedPreferences` (AES256-SIV keys, AES256-GCM values) behind an Android Keystore
  `MasterKey`. `allowBackup=false` and `dataExtractionRules` exclude all data domains, so keys
  cannot be pulled through Android backup/device transfer.
- **No secret logging** — grep finds no `Log.*` / `println` of any key or token. `CrashLog` stores
  only stack traces. `GitHub.kt` hard-codes `api.github.com`.
- **Transport** — `network_security_config.xml` forbids cleartext globally; plain HTTP is allowed
  only to `127.0.0.1`/`localhost`. Downloads are https-only and the HF Bearer header is sent only
  to `huggingface.co` / its subdomains.
- **Lockdown (stronger now)** — app lock defaults to ON, re-locks immediately when the app goes
  to the background, and `FLAG_SECURE` is always applied (no screenshots, no recents previews).
  Biometric or device credential is required; if the phone has no lock configured, the app
  unlocks instead of trapping the user out. A root/custom-firmware or attached-debugger check
  shows a blocking "device not trusted" screen before anything else.
- **Local server (hardened now)** — a fresh bearer token is generated at every start and required
  on every `/v1/*` call. Requests carrying an `Origin` header (browser pages) are rejected with
  403, the wildcard CORS header is gone, and responses are `no-store` + `nosniff`. LAN mode is
  still off by default; the token is displayed in Settings and can be copied into clients.
- **Backups** — `BackupCrypto` uses AES-256-GCM with PBKDF2-HMAC-SHA256 (120,000 iterations,
  random salt and IV).
- **Least privilege** — manifest asks only INTERNET, Termux RUN_COMMAND, ACCESS_NETWORK_STATE and
  POST_NOTIFICATIONS. Widget receiver and FileProvider are `exported=false`; FileProvider paths
  restricted to `cache/exports`.
- **Terminal guard** — destructive verbs need an explicit tap even in Auto mode; Auto mode also
  requires an allowlisted program, permitted folders and a 4-step cap. Proposals are editable.

## Remaining weaknesses (unchanged, stated plainly)

1. **Keystore-reset fallback is plaintext.** If Android Keystore is wiped (device restore, ROM
   bug), `SettingsRepo` deletes `secure_prefs` and falls back to `fallback_prefs`. Keys then live
   unencrypted on-device. This is an availability trade-off, not hardening.
2. **Tamper checks are signals, not a sandbox.** Root detection via known paths / `Build.TAGS`
   and `Debug.isDebuggerConnected()` can be bypassed by a determined owner. They are meant to
   stop casual meddling, not to defend against a rooted device owner.
3. **Command guard is a regex, not isolation.** Unusual destructive commands may pass it; the
   on-device backend is a normal Android sandbox, but Termux/SSH/CLOUD run with their account's
   full rights.
4. **No certificate pinning.** HTTPS is enforced, but a device with a user CA installed can still
   intercept provider traffic.
5. **Provider-side refusals are outside the app.** Removing app wording/caps cannot make
   Gemini/OpenAI/Anthropic stop their own safety refusals.

## Verdict

Strong baseline for a personal assistant: encrypted secrets, no secret logging, HTTPS-only,
always-on screenshot/lock protection, tamper warning, authenticated local API, encrypted backups
and two layers of terminal approval. Do not treat the root check as a security boundary, and keep
LAN mode off unless you need it.
