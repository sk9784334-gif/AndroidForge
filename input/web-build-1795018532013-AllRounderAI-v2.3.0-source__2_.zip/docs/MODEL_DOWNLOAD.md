# On-device model — one tap, or import your own

## What you get

Settings → **On-device model (offline)** shows a short catalog and a recommendation computed
from your phone's total RAM and free storage:

| Model | Size | Needs | When recommended |
|---|---|---|---|
| Gemma 3 270M (`gemma3-270m-it-q8.task`) | ~289 MB | Free Hugging Face token | Phones with ~3 GB+ RAM |
| Gemma 3 1B (`Gemma3-1B-IT_multi-prefill-seq_q4_ekv2048.task`) | ~528 MB | Free Hugging Face token | Phones with ~6 GB+ RAM and enough free storage |

Both are MediaPipe `.task` models and load through the app's existing `LlmInference` engine.
`.gguf` and `.litertlm` files are **not** supported by that engine and are rejected with a clear
message — no fake "loaded" state.

## Download in one tap

1. (Once) Create a free Hugging Face account, accept the model's license on its HF page, and
   create a read token. Paste it into **Hugging Face token** in the same card. It is stored in
   the same encrypted preferences as your API keys.
2. Pick a model (the app pre-selects the recommended one) and tap **Download & use (one tap)**.

The app downloads with the token as a Bearer header only on `huggingface.co`, checks that the
file is a real `.task` archive, saves it in app-private storage, and makes it the primary
provider. If the token is missing or access was not granted, it says so instead of pretending
the download worked.

You can also paste any other direct `https://` link to a `.task` file and tap **Download link**.

## Import a file you already have

Tap **Import model file**, choose a `.task` file from your files. The app copies it into
app-private storage, validates the format, deletes an invalid file, and sets it as primary.

## Why there is no "uncensored" switch

The default system prompt no longer contains the refusal-priming word "legitimate", and the
app's own output caps were raised. What the app **cannot** do is disable safety decisions made
inside Gemini/OpenAI/Anthropic/Gemma — those run on the provider's servers or in the model
weights. A smaller local model generally refuses less, but nothing here is a jailbreak.
