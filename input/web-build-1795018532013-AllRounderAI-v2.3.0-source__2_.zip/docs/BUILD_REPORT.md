# Build report — AllRounder AI v2.3.0

## Environment prepared

- Android SDK command-line tools installed at `/root/asdk`
- `platforms;android-36`, `build-tools;36.0.0`, `platform-tools` installed
- Licenses accepted
- JDK 17 (Alpine OpenJDK), Gradle 8.11.1 via the project wrapper
- `local.properties` points to `/root/asdk` (excluded from the source ZIP)

## Build commands

```
./gradlew assembleDebug --no-daemon      # deliverable APK (BUILD SUCCESSFUL)
./gradlew assembleRelease --no-daemon    # reached processReleaseResources, then the
                                         # build died with no error (resource limits);
                                         # the debug APK is the delivered artifact
```

This environment is ARM64/musl while the Android build tools are x86-64 glibc binaries,
so QEMU emulation was required for aapt2 and friends. Build settings used locally are
NOT shipped: the delivered `gradle.properties` is restored to the project's original
values. On a normal x86-64 Linux/macOS/Windows machine the project builds with the
stock wrapper and no emulation.

R8 minification is opt-in in this project (`-Pminify=true`) because MediaPipe, JSch and Tink
use reflection; the default release build keeps them intact.

## Source changes in this upgrade

- `app/src/main/java/com/allrounder/ai/data/Llm.kt` — Hugging Face provider,
  `discoverModels()`, `testConnection()`.
- `app/src/main/java/com/allrounder/ai/data/Settings.kt` — persisted Termux allowlist and
  permitted folders; version bumped in `app/build.gradle.kts` (17 / 2.3.0).
- `app/src/main/java/com/allrounder/ai/TerminalViewModel.kt` — allowlist/folder enforcement
  in auto mode, editable proposals.
- `app/src/main/java/com/allrounder/ai/ui/TerminalScreen.kt` — Auto/Manual mode chips,
  dangerous-command warning, edit-before-approve UI.
- `app/src/main/java/com/allrounder/ai/data/LocalServer.kt` — new in-app OpenAI-compatible
  HTTP server (localhost by default, optional LAN).
- `app/src/main/java/com/allrounder/ai/ui/SettingsScreen.kt` — Test/Models buttons, local
  server card, command-approval card.
- `docs/UPGRADE_REPORT.md` — feature map and honest limitations.

## Verification status

- Kotlin compilation and resource processing: PASS. `assembleDebug` completed successfully.
- `assembleRelease` did not finish here: the process was killed during
  `processReleaseResources` with no error message (this constrained ARM64 emulator).
  Retry on your own machine, or use the delivered debug APK, which contains the same code.
- Runtime verification of API providers, local server, Termux bridge and voice needs your
  keys, Termux setup and a target device — see `UPGRADE_REPORT.md` §5.

## Deliverables

- `AllRounderAI-v2.3.0.apk` — installable debug-signed APK (40 MB, sha256 in
  `APK_SHA256.txt`). No `keystore.properties` was supplied, so a Play release-signed build
  needs your own keystore.
- `AllRounderAI-v2.3.0-source.zip` — complete modified source (102 files; build outputs,
  `local.properties` and local machine paths excluded).
